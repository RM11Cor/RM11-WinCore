from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parent
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
assert manifest.tag == 'manifest'
java = (root / 'app/src/main/java/com/rm11/wincore/MainActivity.java').read_text()
catalog = (root / 'app/src/main/java/com/rm11/wincore/LauncherCatalog.java').read_text()
native = (root / 'app/src/main/cpp/VulkanProbe.cpp').read_text()
for term in ('steam', 'ubisoft', 'ea', 'rockstar'):
    assert f'new Launcher("{term}"' in catalog
assert 'ACTION_OPEN_DOCUMENT' in java and 'ACTION_CREATE_DOCUMENT' in java
assert 'RuntimeGateway.currentStatusArabic()' in java
assert 'vkEnumeratePhysicalDevices' in native
assert 'ACCESS_ALL_FILES' not in str(manifest.attrib)
print('PASS: project files, manifest, official launcher IDs, Vulkan native probe and report actions present')

ready = (root / 'app/src/main/java/com/rm11/wincore/RuntimeReadiness.java').read_text()
assert 'RuntimeReadiness.inspect' in java
assert 'NOT INTEGRATED' in ready and 'NX809J' in ready
assert 'vkGetPhysicalDeviceFeatures2' in native
print('PASS: V0.2 preflight and Vulkan feature bits are present')

# V0.3 source checks: read-only PE header, private workspace, native Android subprocess.
pe=(root/'app/src/main/java/com/rm11/wincore/PeInspector.java').read_text()
boot=(root/'app/src/main/java/com/rm11/wincore/RuntimeBootstrap.java').read_text()
assert 'MAX_HEADER = 1024 * 1024' in pe and "case 0x8664" in pe
assert 'process.waitFor(8, TimeUnit.SECONDS)' in boot and 'correctDevice()' in boot
assert 'rm11-runtime' in boot and 'wine-prefix-placeholder' in boot
assert 'new Thread' in java and 'PeInspector.inspect' in java
assert 'versionName = "0.8.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: inherited V0.3 workspace, bounded PE inspection and native subprocess checks')

# V0.4: streaming bundle audit with bounded data and no process execution.
bundle=(root/'app/src/main/java/com/rm11/wincore/EngineBundleVerifier.java').read_text()
assert 'MAX_TOTAL' in bundle and 'MessageDigest.getInstance("SHA-256")' in bundle
assert 'ZipInputStream' in bundle and 'RuntimeBootstrap.correctDevice()' in bundle
assert 'EngineBundleVerifier.verify' in java and 'VERIFY_ENGINE_BUNDLE' in java
assert 'NOT READY' in bundle and 'does NOT' not in bundle  # status does not claim executable Wine
print('PASS: V0.4 read-only streaming runtime bundle audit and device restrictions')

# V0.5: static graphics API hints and balanced *suggestions*, no claim of runnable Windows games.
import subprocess
import tempfile
assert 'WindowsExecutableAnalyzer.analyze' in java
assert 'SmartGameProfile.recommend' in java
assert 'GAME_PROFILE_PICK' in java and 'GAME_PROFILE_EXPORT' in java
assert 'no EXE execution' in (root/'app/src/main/java/com/rm11/wincore/SmartGameProfile.java').read_text()
print('PASS: V0.5 read-only EXE advisor UI and explicit no-execution status')
with tempfile.TemporaryDirectory(prefix='rm11-tests-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                    str(src/'WindowsExecutableAnalyzer.java'),
                    str(src/'SmartGameProfile.java'),
                    str(root/'tests/CompatibilityAnalysisTest.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'CompatibilityAnalysisTest'], check=True)

# V0.6-A native ELF metadata audit, never execute components.
elf=(root/'app/src/main/java/com/rm11/wincore/ElfRuntimeInspector.java').read_text()
assert 'ELF_RUNTIME_PICK' in java and 'ElfRuntimeInspector.analyze' in java
assert 'MAX_PREFIX = 256 * 1024' in elf and 'DT_NEEDED' in elf
assert 'Nothing installed, loaded, or executed' in elf
with tempfile.TemporaryDirectory(prefix='rm11-elf-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                    str(src/'ElfRuntimeInspector.java'),
                    str(root/'tests/ElfRuntimeInspectorTest.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'ElfRuntimeInspectorTest'], check=True)
print('PASS: V0.6-A bounded ARM64 ELF loader and library audit; no executable engine')

# V0.7: test a *packaged* Android ARM64 JNI library and host linker path.
# This is not a test of Windows emulation or third-party binary execution.
bridge_cpp=(root/'app/src/main/cpp/RuntimeNativeBridge.cpp').read_text()
bridge_java=(root/'app/src/main/java/com/rm11/wincore/NativeRuntimeBridge.java').read_text()
cmake=(root/'app/src/main/cpp/CMakeLists.txt').read_text()
assert 'Java_com_rm11_wincore_NativeRuntimeBridge_nativeSelfTest' in bridge_cpp
assert 'dlopen("libc.so"' in bridge_cpp and 'dlsym(libc, "getpid")' in bridge_cpp
assert 'RuntimeNativeBridge.cpp' in cmake and ' dl)' in cmake
assert 'NativeRuntimeBridge.inspect()' in java and 'NativeRuntimeBridge' in bridge_java
assert 'System.loadLibrary("rm11probe")' in bridge_java
assert '[NOT INTEGRATED]' in bridge_cpp and 'versionName = "0.8.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: V0.7 JNI Android/Bionic host smoke test wired to UI; no Wine/Box64 claims')


# V0.8: a real second NDK .so module, dlopen/dlsym C ABI handshake.
# This proves Android intra-APK native integration, NOT Box64/Wine execution.
import shutil
adapter = (root/'app/src/main/cpp/RuntimePluginAdapter.cpp').read_text()
contract = (root/'app/src/main/cpp/RuntimeAdapterContract.h').read_text()
assert 'add_library(rm11runtime_adapter SHARED RuntimePluginAdapter.cpp)' in cmake
assert 'dlopen("librm11runtime_adapter.so"' in bridge_cpp
assert 'RM11_ADAPTER_ABI_VERSION' in bridge_cpp and 'dlsym(module' in bridge_cpp
assert 'NativeRuntimeBridge.inspectAdapter()' in java
assert 'versionCode = 8' in (root/'app/build.gradle.kts').read_text()
assert 'RM11_ADAPTER_ABI_VERSION 1u' in contract
assert 'rm11_adapter_self_test' in adapter
assert '[NOT INTEGRATED]' in bridge_cpp
compiler = shutil.which('g++')
if compiler:
    with tempfile.TemporaryDirectory(prefix='rm11-adapter-') as tmp:
        cpp = root/'app/src/main/cpp'
        shared = Path(tmp)/'librm11runtime_adapter.so'
        exe = Path(tmp)/'adapter-contract-test'
        subprocess.run([compiler,'-std=c++17','-Wall','-Wextra','-Werror','-fPIC',
                        '-shared',str(cpp/'RuntimePluginAdapter.cpp'),'-o',str(shared)],check=True)
        subprocess.run([compiler,'-std=c++17','-Wall','-Wextra','-Werror',
                        '-I',str(cpp),str(root/'tests/NativeAdapterContractTest.cpp'),
                        '-ldl','-o',str(exe)],check=True)
        subprocess.run([str(exe),str(shared)],check=True)
else:
    print('WARN: g++ not available; native dynamic module test omitted')
print('PASS: V0.8 native adapter module, interface and Java binding wired')
