"""Post-build APK audit for RM11's two first-party ARM64 libraries."""
import sys
from pathlib import Path
from zipfile import ZipFile

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 tools/verify_native_apk.py app-debug.apk")
apk = Path(sys.argv[1])
expected = {
    'lib/arm64-v8a/librm11probe.so',
    'lib/arm64-v8a/librm11runtime_adapter.so',
}
with ZipFile(apk) as archive:
    entries = set(archive.namelist())
    absent = expected - entries
    if absent:
        raise SystemExit("FAIL missing packaged native libs: " + ', '.join(sorted(absent)))
print('PASS: ARM64 JNI host and independent adapter packaged in APK')
