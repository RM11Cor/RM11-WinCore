# Notes v9.1

البيانات الموثّقة من تقرير v8 الأصلي: Version 22، metadata sizes 20813 و20589، وWindows BuildTarget 19، وTypeTree=1 وtype_count=7 في عينات CAB الثلاث. أول Class IDs الملاحظة بالترتيب: 33،33،43. هذا دليل على وصولنا إلى Metadata الأصلية ولا يثبت توافق Android.

المحلّل الجديد يفك أول metadata بحجم أقصى 256KiB من CAB عبر وحدات UnityFS المضغوطة، ويقرأ type table وserialized TypeTree blob (32 bytes لكل عقدة في v22) ثم object table (24 bytes لكل مدخلة بعد محاذاة 4). يرفض أي مؤشرات بيانات تتجاوز مجال SerializedFile. يعرض sample لحد أقصى 16 نوعاً و8 كائنات. إذا ظهرت صيغة أوسع من v22 فالحالة `UNSUPPORTED_SERIALIZED_VERSION` ولا يتم التخمين.

الاختبارات الاصطناعية لا تعادل اختبار تحميل محرك Unity. نحتاج تقرير الهاتف على نفس GameAssembly ذي البصمة `3ae06c2e783f8e9aeabfe991b820df6b2eb3f760f2789710471dba6e477d4a8c`.
