/* CarX Native Foundation v14: bounded Mesh buffer byte extraction via TypeTree object walk, exact PathIDs.
 * Neither an Android Unity player nor a proof of Android AssetBundle compatibility.
 * Independently authored using public UnityFS format documentation. */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#define MAX_INFO_COMPRESSED (2u*1024u*1024u)
#define MAX_INFO_UNCOMPRESSED (8u*1024u*1024u)
#define MAX_SAMPLE_BLOCK (1024u*1024u)
#define MAX_BLOCK_COUNT 131072u
#define MAX_DIRECTORY_COUNT 8192u
#define MAX_CAB_PREFIX 64u
#define MAX_CAB_METADATA (256u*1024u)
#define MAX_SERIALIZED_TYPES 2048u
#define MAX_SERIALIZED_OBJECTS 65536u
#define MAX_TYPETREE_NODES 32768u
#define MAX_TYPETREE_CAPTURE 22u
#define MAX_TYPETREE_NAME 48u
#define MAX_MESH_FIELD_MATCHES 48u
#define MAX_V14_REPORT_MESHES 2u

typedef struct {char* buf; size_t cap, used; bool overflow;} Builder;
static void append(Builder* b,const char* fmt,...){
  if(b->overflow)return;
  if(b->used>=b->cap){b->overflow=true;return;}
  va_list va; va_start(va,fmt);
  int n=vsnprintf(b->buf+b->used,b->cap-b->used,fmt,va);
  va_end(va);
  if(n<0 || (size_t)n>=b->cap-b->used){b->overflow=true;return;}
  b->used+=(size_t)n;
}
static void append_escaped(Builder* b,const uint8_t* p,size_t n){
  append(b,"\"");
  for(size_t i=0;i<n;i++){
    unsigned c=p[i];
    if(c=='"'||c=='\\')append(b,"\\%c",(char)c);
    else if(c>=32&&c<127)append(b,"%c",(char)c);
    else append(b,"\\u%04x",c);
  }
  append(b,"\"");
}
static uint32_t be32(const uint8_t* p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint16_t be16(const uint8_t* p){return (uint16_t)(((uint16_t)p[0]<<8)|p[1]);}
static uint64_t be64(const uint8_t* p){return ((uint64_t)be32(p)<<32)|be32(p+4);}
static bool sum64(uint64_t a,uint64_t b,uint64_t* out){if(a>UINT64_MAX-b)return false;*out=a+b;return true;}
static bool align16(uint64_t n,uint64_t* out){if(n>UINT64_MAX-15)return false;*out=(n+15)&~UINT64_C(15);return true;}
static bool exact_read(int fd,uint64_t offset,void* buf,size_t count,uint64_t file_bytes){
  if(offset>file_bytes || count>file_bytes-offset || offset>(uint64_t)INT64_MAX)return false;
  size_t done=0;
  while(done<count){
    if(offset+done>(uint64_t)INT64_MAX)return false;
    ssize_t n=pread(fd,(uint8_t*)buf+done,count-done,(off_t)(offset+done));
    if(n<0 && errno==EINTR)continue;
    if(n<=0)return false;
    done+=(size_t)n;
  }
  return true;
}
static bool cstring(const uint8_t* data,size_t length,size_t* cursor,const uint8_t** string,size_t* bytes,size_t max){
  if(*cursor>=length)return false;
  size_t pos=*cursor;
  while(pos<length && pos-*cursor<max && data[pos]!=0)pos++;
  if(pos>=length || data[pos]!=0)return false;
  *string=data+*cursor; *bytes=pos-*cursor; *cursor=pos+1;
  return true;
}
/* Raw LZ4 block decoder (not frame format), allows overlapping backreferences. */
static bool lz4_decode(const uint8_t* in,size_t in_size,uint8_t* out,size_t out_size){
  size_t i=0,o=0;
  while(i<in_size){
    uint8_t token=in[i++];
    size_t literal=(token>>4)&15u;
    if(literal==15){uint8_t extension;do{if(i>=in_size || literal>out_size)return false;extension=in[i++];if(literal>SIZE_MAX-extension)return false;literal+=extension;}while(extension==255);}
    if(literal>in_size-i || literal>out_size-o)return false;
    memcpy(out+o,in+i,literal); i+=literal; o+=literal;
    if(i==in_size)return o==out_size;
    if(in_size-i<2)return false;
    size_t offset=(size_t)in[i]|((size_t)in[i+1]<<8);i+=2;
    if(offset==0 || offset>o)return false;
    size_t length=(token&15u);
    if(length==15){uint8_t extension;do{if(i>=in_size || length>out_size)return false;extension=in[i++];if(length>SIZE_MAX-extension)return false;length+=extension;}while(extension==255);}
    if(length>SIZE_MAX-4)return false;
    length+=4;
    if(length>out_size-o)return false;
    for(size_t k=0;k<length;k++)out[o+k]=out[o+k-offset];
    o+=length;
  }
  return o==out_size;
}
static bool uncompress_block(unsigned kind,const uint8_t* in,size_t in_size,uint8_t* out,size_t out_size){
  if(kind==0){if(in_size!=out_size)return false;memcpy(out,in,in_size);return true;}
  if(kind==2||kind==3)return lz4_decode(in,in_size,out,out_size);
  return false;
}
/* Reads up to 64 bytes of ONE actual CAB node from the virtual concatenated
 * UnityFS block stream. No whole CAB allocations; decompresses ONLY intersecting
 * chunks and caps each temporary allocation at 1 MiB. All offsets validated. */
static bool cab_virtual_prefix(int fd,uint64_t file_bytes,
    const uint8_t* info,size_t block_pos,uint32_t block_count,
    uint64_t content_offset,uint64_t node_offset,uint8_t* dst,size_t wanted){
  uint64_t virtual_cursor=0,physical_cursor=content_offset;
  size_t copied=0;
  for(uint32_t j=0;j<block_count&&copied<wanted;j++){
    const uint8_t* d=info+block_pos+(size_t)j*10u;
    uint32_t u=be32(d),c=be32(d+4),f=be16(d+8);
    uint64_t next_v=0,next_p=0;
    if(!sum64(virtual_cursor,u,&next_v)||!sum64(physical_cursor,c,&next_p))return false;
    if(next_p>file_bytes)return false;
    if(node_offset+copied<next_v && node_offset+copied>=virtual_cursor){
      if(u>MAX_SAMPLE_BLOCK||c>MAX_SAMPLE_BLOCK || u==0||c==0)return false;
      unsigned kind=f&63u;
      if(kind!=0 && kind!=2 && kind!=3)return false;
      uint8_t *compressed=(uint8_t*)malloc(c),*decoded=(uint8_t*)malloc(u);
      if(!compressed||!decoded){free(compressed);free(decoded);return false;}
      bool ok=exact_read(fd,physical_cursor,compressed,c,file_bytes) &&
          uncompress_block(kind,compressed,c,decoded,u);
      if(ok){
        size_t start=(size_t)(node_offset+copied-virtual_cursor);
        size_t n=(size_t)u-start;
        if(n>wanted-copied)n=wanted-copied;
        memcpy(dst+copied,decoded+start,n);copied+=n;
      }
      free(compressed);free(decoded);
      if(!ok)return false;
    }
    virtual_cursor=next_v;physical_cursor=next_p;
  }
  return copied==wanted;
}
static void print_cab_prefix(Builder* outb,const uint8_t* p,size_t n){
  append(outb,"{\"bytes\":%zu,\"hex\":\"",n);
  for(size_t i=0;i<n;i++)append(outb,"%02x",p[i]);
  append(outb,"\",\"classification\":");
  if(n<20){append(outb,"\"HEADER_TOO_SHORT\"}");return;}
  uint32_t m=be32(p),fs=be32(p+4),v=be32(p+8),ds=be32(p+12);
  unsigned endian=p[16];
  bool ok=v>=5&&v<=40&&endian<=1&&m>=20&&m<=UINT32_C(268435456)&&
          fs>=m&&ds>=m&&ds<=fs;
  if(v>=22 && n>=48){
    uint32_t m2=be32(p+20);
    uint64_t fs2=be64(p+24),ds2=be64(p+32);
    ok=ok||((m2>=20&&m2<=UINT32_C(268435456)) && fs2>=m2 && ds2>=m2 && ds2<=fs2 && endian<=1);
  }
  append(outb,"\"%s\",\"be_header_fields\":{\"metadata_size\":%u,\"file_size32\":%u,\"version\":%u,\"data_offset32\":%u,\"endianness\":%u}",ok?"CANDIDATE_SERIALIZED_FILE_HEADER":"NOT_STANDARD_SERIALIZED_FILE_HEADER",m,fs,v,ds,endian);
  if(v>=22&&n>=48){
    append(outb,",\"v22_extended_be\":{\"metadata_size\":%u,\"file_size64\":%" PRIu64 ",\"data_offset64\":%" PRIu64 "}",be32(p+20),be64(p+24),be64(p+32));
  }
  append(outb,"}");
}
/* Unity SerializedFile format v22 metadata decoder.
 * All metadata parsing is bounded to the declared header length and never reads
 * object data; this is NOT a Unity Player nor asset transcoding. */
typedef struct {const uint8_t* data; size_t size, pos; unsigned little;} MetaReader;
static uint16_t mr16(MetaReader* r){
  const uint8_t* q=r->data+r->pos;
  uint16_t v=r->little?(uint16_t)((uint16_t)q[0]|((uint16_t)q[1]<<8)):be16(q);
  r->pos+=2;return v;
}
static uint32_t mr32(MetaReader* r){
  const uint8_t* q=r->data+r->pos;
  uint32_t v=r->little?((uint32_t)q[0]|((uint32_t)q[1]<<8)|((uint32_t)q[2]<<16)|((uint32_t)q[3]<<24)):be32(q);
  r->pos+=4;return v;
}
static uint64_t mr64(MetaReader* r){
  uint64_t a=mr32(r),b=mr32(r);return r->little?(a|(b<<32)):((a<<32)|b);
}
static bool mr_has(const MetaReader* r,size_t n){return r->pos<=r->size && n<=r->size-r->pos;}
static bool mr_skip(MetaReader* r,size_t n){if(!mr_has(r,n))return false;r->pos+=n;return true;}
static bool mr_str(MetaReader* r,size_t max,const uint8_t** ptr,size_t* slen){
  return cstring(r->data,r->size,&r->pos,ptr,slen,max);
}
static void meta_error(Builder* b,const char* reason){append(b,"{\"status\":\"METADATA_PARSE_INCOMPLETE\",\"reason\":\"%s\",\"game_rendered\":false}",reason);}
typedef struct {uint64_t path_id, byte_start;uint32_t byte_size;int32_t class_id;} CarxObjectSample;
static uint32_t le32_safe(const uint8_t* p){return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);}
/* Read the physical v22 TypeTree node table without assuming Unity's COMMON
 * string table is embedded in the bundle. A top-bit string offset refers to
 * Unity's external common-string table; leave it unresolved, do NOT guess. */
typedef struct {
  int32_t class_id;
  uint32_t node_count,local_string_bytes;
  uint64_t struct_hash;
  struct {uint8_t level; uint8_t type_flags;int32_t byte_size;
          uint32_t type_offset,name_offset;char type[49],name[49];} sample[MAX_TYPETREE_CAPTURE];
  uint32_t sampled;
  const uint8_t *raw_nodes,*raw_strings; bool raw_little;
  struct {uint32_t index, parent_index;uint8_t level;int32_t byte_size;
          uint32_t type_common_offset;char field[49],type[49];} mesh_matches[MAX_MESH_FIELD_MATCHES];
  uint32_t mesh_match_count, mesh_match_overflow;
} CarxTypeTreeSummary;
static uint64_t fnv64_bytes(const uint8_t* p,size_t n){
  uint64_t h=UINT64_C(14695981039346656037);
  for(size_t i=0;i<n;i++){h^=p[i];h*=UINT64_C(1099511628211);}return h;
}
static bool read_local_name(const uint8_t* strings,uint32_t string_bytes,uint32_t off,char out[49]){
  out[0]=0;
  if(off&UINT32_C(0x80000000))return false;
  if(off>=string_bytes)return false;
  size_t len=0;
  while(off+len<string_bytes && len<MAX_TYPETREE_NAME && strings[off+len] != 0){
    uint8_t ch=strings[off+len];
    if(ch<32 || ch>126)return false;
    out[len]=(char)ch;len++;
  }
  if(off+len>=string_bytes || strings[off+len]!=0 || len==0)return false;
  out[len]=0;return true;
}
/* Named geometry fields are verified against the LOCAL TypeTree string buffer.
 * Missing common-string fields stay unresolved. Never treat a schema node offset
 * as a byte offset into a serialized Mesh object. */
static bool mesh_geometry_field(const char* n){
  static const char* const names[]={
    "m_SubMeshes", "m_IndexFormat", "m_IndexBuffer", "m_VertexData",
    "m_VertexCount", "m_Channels", "m_Streams", "m_DataSize", "m_Data",
    "m_StreamData", "m_CompressedMesh", "m_Shapes", "m_MeshCompression",
    "m_IsReadable", "m_KeepVertices", "m_KeepIndices", "m_BindPose",
    "m_BoneNameHashes", "m_RootBoneNameHash", "m_LocalAABB",
    "m_MeshUsageFlags", "m_CollisionMesh", "m_BonesAABB",
    "m_VariableBoneCountWeights", "m_VertexDataArray", "m_IndexData"
  };
  if(!n || !n[0])return false;
  for(size_t i=0;i<sizeof(names)/sizeof(names[0]);i++)if(!strcmp(n,names[i]))return true;
  return false;
}
static bool collect_type_tree(const uint8_t* data,size_t len,bool little,uint32_t count,uint32_t strings_len,
                              CarxTypeTreeSummary* t){
  uint64_t node_bytes=(uint64_t)count*32u;
  if(node_bytes>len || strings_len>len-node_bytes)return false;
  const uint8_t* strings=data+(size_t)node_bytes;
  t->node_count=count;t->local_string_bytes=strings_len;
  t->raw_nodes=data;t->raw_strings=strings;t->raw_little=little;
  t->struct_hash=fnv64_bytes(data,(size_t)node_bytes+strings_len);
  uint32_t parents[256]={0};
  bool parent_seen[256]={0};
  for(uint32_t j=0;j<count;j++){
    const uint8_t* e=data+(size_t)j*32u;
    uint32_t type_off=little?le32_safe(e+4):be32(e+4);
    uint32_t name_off=little?le32_safe(e+8):be32(e+8);
    uint32_t size_u=little?le32_safe(e+12):be32(e+12);
    uint8_t level=e[2];
    if(level>0 && (j==0 || !parent_seen[level-1] || parents[level-1]>=j))return false;
    if(level>0 && j>0 && t->class_id==43){
      char field[49]={0},type[49]={0};
      read_local_name(strings,strings_len,name_off,field);
      if(mesh_geometry_field(field)){
        if(t->mesh_match_count<MAX_MESH_FIELD_MATCHES){
          unsigned k=t->mesh_match_count++;
          t->mesh_matches[k].index=j;
          t->mesh_matches[k].parent_index=parents[level-1];
          t->mesh_matches[k].level=level;
          t->mesh_matches[k].byte_size=(int32_t)size_u;
          t->mesh_matches[k].type_common_offset=(type_off&UINT32_C(0x80000000))?(type_off&UINT32_C(0x7fffffff)):UINT32_MAX;
          read_local_name(strings,strings_len,type_off,type);
          memcpy(t->mesh_matches[k].field,field,sizeof field);
          memcpy(t->mesh_matches[k].type,type,sizeof type);
        }else t->mesh_match_overflow++;
      }
    }
    parents[level]=j; parent_seen[level]=true;
    for(unsigned depth=(unsigned)level+1u;depth<256u;depth++)parent_seen[depth]=false;
    /* Preserve a breadth sample instead of assuming its fields are all local. */
    if(j<MAX_TYPETREE_CAPTURE){
      unsigned idx=t->sampled++;
      t->sample[idx].level=e[2];t->sample[idx].type_flags=e[3];
      t->sample[idx].byte_size=(int32_t)size_u;
      t->sample[idx].type_offset=type_off;t->sample[idx].name_offset=name_off;
      read_local_name(strings,strings_len,type_off,t->sample[idx].type);
      read_local_name(strings,strings_len,name_off,t->sample[idx].name);
    }
  }
  return true;
}
static void report_tree(Builder* b,const CarxTypeTreeSummary* t){
  append(b,"{\"class_id\":%d,\"node_count\":%u,\"string_buffer_bytes\":%u,\"structural_fingerprint_fnv64\":\"%016" PRIx64 "\",\"sample_nodes\":[",
    t->class_id,t->node_count,t->local_string_bytes,t->struct_hash);
  for(uint32_t i=0;i<t->sampled;i++){
    if(i)append(b,",");
    append(b,"{\"level\":%u,\"byte_size\":%d,\"type\":",
       t->sample[i].level,t->sample[i].byte_size);
    if(t->sample[i].type[0])append_escaped(b,(const uint8_t*)t->sample[i].type,strlen(t->sample[i].type));
    else append(b,"null");
    append(b,",\"field\":");
    if(t->sample[i].name[0])append_escaped(b,(const uint8_t*)t->sample[i].name,strlen(t->sample[i].name));
    else append(b,"null");
    /* Important: common-string offsets are references into a BUILT-IN table,
       not offsets into local string buffer. */
    append(b,",\"type_common_offset\":");
    if(t->sample[i].type_offset&UINT32_C(0x80000000))append(b,"%u",t->sample[i].type_offset&UINT32_C(0x7fffffff));
    else append(b,"null");
    append(b,",\"field_common_offset\":");
    if(t->sample[i].name_offset&UINT32_C(0x80000000))append(b,"%u",t->sample[i].name_offset&UINT32_C(0x7fffffff));
    else append(b,"null");
    append(b,"}");
  }
  append(b,"],\"mesh_geometry_field_locator\":{");
  append(b,"\"scope\":\"ALL_TYPETREE_NODES_LOCAL_STRINGS_ONLY\",\"searched_nodes\":%u,"
           "\"matches\":[",t->node_count);
  for(uint32_t i=0;i<t->mesh_match_count;i++){
    if(i)append(b,",");
    append(b,"{\"node_index\":%u,\"parent_index\":%u,\"level\":%u,\"byte_size\":%d,\"field\":",
      t->mesh_matches[i].index,t->mesh_matches[i].parent_index,t->mesh_matches[i].level,t->mesh_matches[i].byte_size);
    append_escaped(b,(const uint8_t*)t->mesh_matches[i].field,strlen(t->mesh_matches[i].field));
    append(b,",\"type\":");
    if(t->mesh_matches[i].type[0])append_escaped(b,(const uint8_t*)t->mesh_matches[i].type,strlen(t->mesh_matches[i].type));
    else append(b,"null");
    append(b,",\"type_common_offset\":");
    if(t->mesh_matches[i].type_common_offset==UINT32_MAX)append(b,"null");
    else append(b,"%u",t->mesh_matches[i].type_common_offset);
    append(b,"}");
  }
  append(b,"],\"match_count\":%u,\"match_cap_overflow\":%u,"
           "\"serialized_object_offsets_proven\":false,"
           "\"index_buffer_extracted\":false,\"vertex_buffer_extracted\":false}}",
         t->mesh_match_count,t->mesh_match_overflow);
}
/* Bounded decoder: m_Name (u32 length, bytes, align 4), m_SubMeshes count,
 * first 48-byte SubMesh record. Never accepts a guessed geometry layout as a
 * completed vertex/index buffer. The Unity v22 TypeTree must corroborate the
 * 48-byte SubMesh layout for a strong structural validation. */
static bool type_tree_confirms_submesh(const CarxTypeTreeSummary* t){
  if(!t || t->class_id!=43)return false;
  bool type=false, first=false, count=false, topology=false, base=false, firstv=false, vertex=false;
  for(uint32_t i=0;i<t->sampled;i++){
    const char* n=t->sample[i].name;
    if(!strcmp(t->sample[i].type,"SubMesh") && t->sample[i].byte_size==48)type=true;
    if(!strcmp(n,"firstByte"))first=true;
    if(!strcmp(n,"indexCount"))count=true;
    if(!strcmp(n,"topology"))topology=true;
    if(!strcmp(n,"baseVertex"))base=true;
    if(!strcmp(n,"firstVertex"))firstv=true;
    if(!strcmp(n,"vertexCount"))vertex=true;
  }
  return type&&first&&count&&topology&&base&&firstv&&vertex;
}
static void mesh_submesh_summary(Builder* b,const uint8_t* p,size_t n,uint32_t object_bytes,
                                 bool type_tree_verified){
  append(b,",\"submesh_probe\":{");
  if(n<8 || object_bytes<8){append(b,"\"status\":\"INSUFFICIENT_PREFIX\"}");return;}
  uint32_t name_len=le32_safe(p);
  if(name_len==0 || name_len>48u || (uint64_t)name_len+4u>n){
    append(b,"\"status\":\"NAME_LAYOUT_UNSUPPORTED\"}");return;
  }
  size_t after_name=(4u+(size_t)name_len+3u)&~(size_t)3u;
  if(after_name>n || n-after_name<4u || after_name+4u>object_bytes){
    append(b,"\"status\":\"COUNT_UNAVAILABLE\"}");return;
  }
  uint32_t count=le32_safe(p+after_name);
  if(count==0 || count>256){append(b,"\"status\":\"SUBMESH_COUNT_UNSUPPORTED\",\"submesh_count\":%u}",count);return;}
  size_t first=after_name+4u;
  if(first>n || n-first<48u || object_bytes-first<48u){
    append(b,"\"status\":\"FIRST_SUBMESH_NOT_IN_PREFIX\",\"submesh_count\":%u}",count);return;
  }
  uint32_t fb=le32_safe(p+first), indexes=le32_safe(p+first+4u);
  uint32_t topology=le32_safe(p+first+8u), base=le32_safe(p+first+12u);
  uint32_t first_vertex=le32_safe(p+first+16u), vertices=le32_safe(p+first+20u);
  /* Do not infer validity of index byte offsets or vertex streams yet. */
  bool triangles=(topology==0 && indexes%3u==0 && indexes>0 && vertices>0);
  append(b,"\"status\":\"FIRST_SUBMESH_HEADER_READ\",\"submesh_count\":%u,"
           "\"typetree_48_byte_layout_confirmed\":%s,\"first_byte\":%u,\"index_count\":%u,"
           "\"topology\":%u,\"base_vertex\":%u,\"first_vertex\":%u,\"vertex_count\":%u,"
           "\"triangle_count_candidate\":",count,type_tree_verified?"true":"false",fb,indexes,topology,base,first_vertex,vertices);
  if(triangles)append(b,"%u",indexes/3u);else append(b,"null");
  append(b,",\"vertex_buffer_extracted\":false,\"index_buffer_extracted\":false,\"android_asset_compatibility_proven\":false}");
}
#include "mesh_geometry_v14.inc"
static void inspect_serialized_v22(Builder* b,const uint8_t* p,size_t n,uint64_t cab_node_bytes,
    int fd,uint64_t file_bytes,const uint8_t* info,size_t block_table_pos,uint32_t block_count,
    uint64_t content_offset,uint64_t first_node_offset){
  if(n<48){meta_error(b,"incomplete header");return;}
  uint32_t version=be32(p+8),msize=be32(p+20);
  uint64_t fsize=be64(p+24),data_offset=be64(p+32);
  if(version!=22){append(b,"{\"status\":\"UNSUPPORTED_SERIALIZED_VERSION\",\"format_version\":%u}",version);return;}
  if(p[16]>1 || msize<15 || msize>MAX_CAB_METADATA || fsize>cab_node_bytes || fsize<data_offset ||
     data_offset<48u+(uint64_t)msize || 48u+(uint64_t)msize>n){
    meta_error(b,"v22 header or metadata size invalid");return;
  }
  MetaReader r={p,n,48,p[16]==0};
  const uint8_t *unity_ver=NULL;size_t ulen=0;
  if(!mr_str(&r,96,&unity_ver,&ulen)||!mr_has(&r,9)){meta_error(b,"missing Unity metadata prefix");return;}
  uint32_t target=mr32(&r);
  unsigned typetree=r.data[r.pos++];
  uint32_t nt=mr32(&r);
  if(typetree>1||nt>MAX_SERIALIZED_TYPES){meta_error(b,"invalid type tree flag or type count");return;}
  int32_t types[MAX_SERIALIZED_TYPES]={0};
  CarxTypeTreeSummary trees[12]={0};uint32_t tree_samples=0;
  unsigned sample_count=nt<16?nt:16;
  for(uint32_t i=0;i<nt;i++){
    if(!mr_has(&r,7+16)){meta_error(b,"short serialized type record");return;}
    int32_t class_id=(int32_t)mr32(&r);
    types[i]=class_id;
    unsigned stripped=r.data[r.pos++];
    (void)mr16(&r); /* script_type_index */
    if(stripped>1){meta_error(b,"invalid stripped-type flag");return;}
    if(class_id==114&&!mr_skip(&r,16)){meta_error(b,"short MonoBehaviour script id");return;}
    if(!mr_skip(&r,16)){meta_error(b,"short old type hash");return;}
    if(typetree){
      if(!mr_has(&r,8)){meta_error(b,"short type-tree header");return;}
      uint32_t node_count=mr32(&r),string_bytes=mr32(&r);
      if(node_count>MAX_TYPETREE_NODES || string_bytes>MAX_CAB_METADATA ||
         node_count>(SIZE_MAX-string_bytes)/32u || !mr_has(&r,(size_t)node_count*32u+string_bytes)){
        meta_error(b,"type-tree nodes or strings out of bounds");return;
      }
      if(tree_samples<12u && (class_id==43 || class_id==21 || class_id==1 || class_id==33)){
        CarxTypeTreeSummary* tree=&trees[tree_samples];
        tree->class_id=class_id;
        if(!collect_type_tree(r.data+r.pos,r.size-r.pos,r.little,node_count,string_bytes,tree)){
          meta_error(b,"unable to parse type-tree nodes");return;
        }
        tree_samples++;
      }
      if(!mr_skip(&r,(size_t)node_count*32u+string_bytes)){
        meta_error(b,"unable to skip type-tree buffer");return;
      }
    }
    if(!mr_has(&r,4)){meta_error(b,"missing type dependencies");return;}
    uint32_t dependencies=mr32(&r);
    if(dependencies>MAX_SERIALIZED_TYPES || !mr_skip(&r,(size_t)dependencies*4u)){
      meta_error(b,"type dependencies out of bounds");return;
    }
  }
  if(!mr_has(&r,4)){meta_error(b,"missing object count");return;}
  uint32_t nobjects=mr32(&r);
  if(nobjects>MAX_SERIALIZED_OBJECTS){meta_error(b,"object count exceeds safety limit");return;}
  int32_t sample_object_types[8]={0}; uint32_t sample_objects=nobjects<8?nobjects:8;
  uint32_t object_type_counts[MAX_SERIALIZED_TYPES]={0};
  CarxObjectSample samples[10]={0};unsigned sample_count_payload=0;
  bool found_mesh=false,found_material=false;
  for(uint32_t i=0;i<nobjects;i++){
    size_t aligned=(r.pos+3u)&~(size_t)3u;
    if(aligned<r.pos||aligned>r.size){meta_error(b,"object table alignment out of bounds");return;}
    r.pos=aligned;
    if(!mr_has(&r,24)){meta_error(b,"short v22 object index entry");return;}
    uint64_t path_id=mr64(&r);
    uint64_t byte_start=mr64(&r);
    uint32_t byte_size=mr32(&r),type_index=mr32(&r);
    if(type_index>=nt || byte_start>fsize-data_offset || byte_size>fsize-data_offset-byte_start){
      meta_error(b,"object type index or data region out of bounds");return;
    }
    int32_t class_id=types[type_index];
    object_type_counts[type_index]++;
    if(i<sample_objects)sample_object_types[i]=class_id;
    bool wanted=((i<8) || (class_id==43&&!found_mesh) || (class_id==21&&!found_material));
    if(class_id==43)found_mesh=true;
    if(class_id==21)found_material=true;
    if(wanted && sample_count_payload<10){
      samples[sample_count_payload++]=(CarxObjectSample){path_id,byte_start,byte_size,class_id};
    }
  }
  append(b,"{\"status\":\"PASS_V22_METADATA_OBJECT_INDEX\",\"format_version\":22,\"metadata_size\":%u,\"file_size\":%" PRIu64 ",\"data_offset\":%" PRIu64 ",\"endianness\":\"%s\",\"unity_version\":",msize,fsize,data_offset,r.little?"little":"big");
  append_escaped(b,unity_ver,ulen);
  append(b,",\"build_target\":%u,\"build_target_name\":\"%s\",\"type_tree_enabled\":%s,\"type_count\":%u,\"class_id_sample\":[",target,target==19?"StandaloneWindows64":"OTHER_OR_UNKNOWN",typetree?"true":"false",nt);
  for(unsigned i=0;i<sample_count;i++){if(i)append(b,",");append(b,"%d",types[i]);}
  append(b,"],\"type_tree_inspection\":{\"status\":\"PASS_BOUNDED_TYPETREE_NODES\",\"common_strings\":\"UNRESOLVED_EXTERNAL_TABLE_OFFSETS\",\"types\":[");
  for(uint32_t i=0;i<tree_samples;i++){if(i)append(b,",");report_tree(b,&trees[i]);}
  append(b,"]},\"object_count\":%u,\"object_class_id_sample\":[",nobjects);
  for(unsigned i=0;i<sample_objects;i++){if(i)append(b,",");append(b,"%d",sample_object_types[i]);}
  append(b,"],\"object_type_histogram\":[");
  bool first_hist=true;
  for(uint32_t i=0;i<nt;i++){
    if(object_type_counts[i]==0)continue;
    if(!first_hist)append(b,",");
    first_hist=false;
    append(b,"{\"class_id\":%d,\"count\":%u}",types[i],object_type_counts[i]);
  }
  append(b,"],\"actual_object_data_samples\":[");
  unsigned v14_mesh_probes=0;
  for(unsigned i=0;i<sample_count_payload;i++){
    if(i)append(b,",");
    CarxObjectSample* o=&samples[i];
    append(b,"{\"path_id\":\"%" PRIu64 "\",\"class_id\":%d,\"byte_start\":%" PRIu64 ",\"byte_size\":%u,",
       o->path_id,o->class_id,o->byte_start,o->byte_size);
    size_t wanted=o->byte_size<64u?(size_t)o->byte_size:64u;
    uint8_t bytes[64]={0};
    uint64_t absolute_node_offset=first_node_offset + data_offset + o->byte_start;
    if(wanted>0 && cab_virtual_prefix(fd,file_bytes,info,block_table_pos,block_count,
                   content_offset,absolute_node_offset,bytes,wanted)){
      append(b,"\"read_ok\":true,\"prefix_bytes\":%zu,\"hex_prefix\":\"",wanted);
      for(size_t k=0;k<wanted;k++)append(b,"%02x",bytes[k]);
      append(b,"\"");
      if(o->class_id==43 && v14_mesh_probes<MAX_V14_REPORT_MESHES){
        v14_mesh_probes++;
        const CarxTypeTreeSummary* mesh_tree=NULL;
        for(uint32_t ti=0;ti<tree_samples;ti++)if(trees[ti].class_id==43){mesh_tree=&trees[ti];break;}
        if(o->byte_size>MAX_V14_MESH_BYTES){
          append(b,",\"geometry_buffer_probe\":{\"status\":\"OBJECT_SIZE_OUT_OF_PROBE_CAP\",\"index_buffer_extracted\":false,\"vertex_buffer_extracted\":false}");
        }else if(o->byte_size>0){
          uint8_t* whole=(uint8_t*)malloc(o->byte_size);
          if(!r.little){
            append(b,",\"geometry_buffer_probe\":{\"status\":\"NON_LITTLE_ENDIAN_OBJECT_UNSUPPORTED\",\"index_buffer_extracted\":false,\"vertex_buffer_extracted\":false}");
          }else if(whole && cab_virtual_prefix(fd,file_bytes,info,block_table_pos,block_count,
                               content_offset,absolute_node_offset,whole,o->byte_size)){
            v14_mesh_buffer_report(b,mesh_tree,whole,o->byte_size);
          }else append(b,",\"geometry_buffer_probe\":{\"status\":\"OBJECT_BYTE_READ_FAILED\",\"index_buffer_extracted\":false,\"vertex_buffer_extracted\":false}");
          free(whole);
        }
      }
      if(o->class_id==43){
        bool verified=false;
        for(uint32_t ti=0;ti<tree_samples;ti++){
          if(type_tree_confirms_submesh(&trees[ti])){verified=true;break;}
        }
        mesh_submesh_summary(b,bytes,wanted,o->byte_size,verified);
      }
      if((o->class_id==43 || o->class_id==21) && wanted>=4){
        uint32_t slen=le32_safe(bytes);
        if(slen>=1&&slen<=wanted-4 && slen<=48){
          bool printable=true;
          for(uint32_t k=0;k<slen;k++)if(bytes[k+4]<32 || bytes[k+4]>126)printable=false;
          if(printable){
            append(b,",\"candidate_name\":");
            append_escaped(b,bytes+4,slen);
          }
        }
      }
    }else if(wanted==0)append(b,"\"read_ok\":true,\"prefix_bytes\":0,\"hex_prefix\":\"\"");
    else append(b,"\"read_ok\":false,\"reason\":\"bounded object data read failed\"");
    append(b,"}");
  }
  append(b,"],\"object_payloads_read_only\":true,\"android_asset_compatibility_proven\":false,\"game_rendered\":false}");
}
static void make_failure(char* out,size_t cap,const char* status,const char* reason){
  if(cap==0)return;
  snprintf(out,cap,"{\"schema\":\"carx.unityfs.bounded-directory.v6\",\"status\":\"%s\",\"reason\":\"%s\",\"game_rendered\":false,\"android_asset_compatibility_proven\":false}",status,reason);
}
void carx_inspect_unityfs_fd(int fd,uint64_t file_size,char* out,size_t cap){
  if(!out||cap<1024)return;
  out[0]=0;
  if(fd<0||file_size<64){make_failure(out,cap,"INVALID_INPUT","file too small or invalid fd");return;}
  uint8_t header[512];size_t hlen=file_size<sizeof header?(size_t)file_size:sizeof header;
  if(!exact_read(fd,0,header,hlen,file_size)){make_failure(out,cap,"READ_FAILED","cannot seek to header");return;}
  if(memcmp(header,"UnityFS\0",8)!=0){make_failure(out,cap,"NOT_UNITYFS","signature mismatch");return;}
  uint32_t version=be32(header+8);
  if(version<6||version>8){make_failure(out,cap,"UNSUPPORTED_VERSION","only UnityFS 6-8");return;}
  size_t p=12;const uint8_t *player,*engine;size_t playerlen=0,enginelen=0;
  if(!cstring(header,hlen,&p,&player,&playerlen,96)||!cstring(header,hlen,&p,&engine,&enginelen,96)||hlen-p<20){
    make_failure(out,cap,"BAD_HEADER","invalid UnityFS strings or dimensions");return;
  }
  uint64_t declared=be64(header+p);p+=8;
  uint32_t csize=be32(header+p);p+=4;
  uint32_t usize=be32(header+p);p+=4;
  uint32_t flags=be32(header+p);p+=4;
  if(declared<64||declared>file_size || csize==0 || csize>MAX_INFO_COMPRESSED || usize<20 || usize>MAX_INFO_UNCOMPRESSED){
    make_failure(out,cap,"INVALID_BOUNDS","invalid bundle length or metadata size cap");return;
  }
  if((flags&0x1400u)!=0){make_failure(out,cap,"SPECIAL_FLAGS_UNSUPPORTED","nonstandard or encryption flags");return;}
  unsigned info_kind=flags&63u;
  if(info_kind!=0&&info_kind!=2&&info_kind!=3){make_failure(out,cap,"UNSUPPORTED_COMPRESSION","metadata requires unsupported compression");return;}
  uint64_t aligned_header=0;
  if(!align16((uint64_t)p,&aligned_header)){make_failure(out,cap,"INVALID_HEADER","alignment overflow");return;}
  bool at_end=(flags&0x80u)!=0;
  uint64_t info_offset=at_end?declared-csize:aligned_header;
  uint64_t data_offset=at_end?aligned_header:0;
  if(!at_end&&!sum64(info_offset,csize,&data_offset)){
    make_failure(out,cap,"INVALID_BOUNDS","info offset overflow");return;
  }
  if((flags&0x200u)!=0){
    uint64_t a=0;if(!align16(data_offset,&a)){make_failure(out,cap,"INVALID_BOUNDS","data align overflow");return;}data_offset=a;
  }
  if((at_end && csize>declared) || info_offset>declared || csize>declared-info_offset || data_offset>declared || (at_end&&data_offset>info_offset)){
    make_failure(out,cap,"INVALID_BOUNDS","metadata or content out of file");return;
  }
  uint8_t* cinfo=(uint8_t*)malloc(csize),*info=(uint8_t*)malloc(usize);
  if(!cinfo||!info){free(cinfo);free(info);make_failure(out,cap,"OOM","metadata allocation");return;}
  if(!exact_read(fd,info_offset,cinfo,csize,file_size)||!uncompress_block(info_kind,cinfo,csize,info,usize)){
    free(cinfo);free(info);make_failure(out,cap,"BLOCK_INFO_DECODE_FAILED","bad compressed metadata or unsupported protection");return;
  }
  free(cinfo);
  size_t cur=16;
  if(usize-cur<4){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","missing block count");return;}
  uint32_t block_count=be32(info+cur);cur+=4;
  if(block_count==0||block_count>MAX_BLOCK_COUNT||(size_t)block_count>(usize-cur)/10){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","invalid block table count");return;
  }
  size_t block_table_pos=cur;
  uint64_t stored_total=0,virtual_total=0;
  uint32_t first_u=0,first_c=0,first_flags=0;
  for(uint32_t i=0;i<block_count;i++){
    uint32_t u=be32(info+cur),c=be32(info+cur+4);uint16_t f=be16(info+cur+8);cur+=10;
    if(i==0){first_u=u;first_c=c;first_flags=f;}
    if(c==0||u==0||!sum64(stored_total,c,&stored_total)||!sum64(virtual_total,u,&virtual_total)){
      free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","zero or oversized chunk");return;
    }
  }
  uint64_t data_end=at_end?info_offset:declared;
  if(data_offset>data_end || stored_total>data_end-data_offset){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","chunk range beyond file data");return;
  }
  if(usize-cur<4){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","missing node count");return;}
  uint32_t node_count=be32(info+cur);cur+=4;
  if(node_count>MAX_DIRECTORY_COUNT||(size_t)node_count>(usize-cur)/21){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","invalid directory count");return;
  }
  Builder outb={out,cap,0,false};
  append(&outb,"{\"schema\":\"carx.unityfs.bounded-directory.v6\",\"status\":\"PASS_UNITYFS_DIRECTORY_DECODED\",\"format_version\":%u,\"player_version\":",version);
  append_escaped(&outb,player,playerlen);
  append(&outb,",\"engine_version\":");append_escaped(&outb,engine,enginelen);
  append(&outb,",\"bundle_bytes\":%" PRIu64 ",\"declared_bytes\":%" PRIu64 ",\"flags\":%u,\"block_info_at_end\":%s,\"info_compression\":%u,\"block_count\":%u,\"virtual_data_bytes\":%" PRIu64 ",\"node_count\":%u,\"nodes_sample\":[",file_size,declared,flags,at_end?"true":"false",info_kind,block_count,virtual_total,node_count);
  bool valid=true;
  uint64_t first_node_offset=0,first_node_bytes=0;
  for(uint32_t i=0;i<node_count;i++){
    if(usize-cur<20){valid=false;break;}
    uint64_t virtual_offset=be64(info+cur),length=be64(info+cur+8);
    uint32_t node_flags=be32(info+cur+16);cur+=20;
    if(i==0){first_node_offset=virtual_offset;first_node_bytes=length;}
    const uint8_t* name;size_t name_len;
    if(!cstring(info,usize,&cur,&name,&name_len,256)||virtual_offset>virtual_total||length>virtual_total-virtual_offset){valid=false;break;}
    if(i<8){if(i)append(&outb,",");append(&outb,"{\"name\":");append_escaped(&outb,name,name_len);
      append(&outb,",\"offset\":%" PRIu64 ",\"length\":%" PRIu64 ",\"flags\":%u}",virtual_offset,length,node_flags);}
  }
  if(!valid||outb.overflow){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","node bounds or output cap");return;}
  append(&outb,"],\"first_block\":{");
  if(first_c<=MAX_SAMPLE_BLOCK&&first_u<=MAX_SAMPLE_BLOCK&&((first_flags&63u)==0||(first_flags&63u)==2||(first_flags&63u)==3)){
    uint8_t* cin=(uint8_t*)malloc(first_c),*decoded=(uint8_t*)malloc(first_u);
    if(cin&&decoded&&exact_read(fd,data_offset,cin,first_c,file_size)&&uncompress_block(first_flags&63u,cin,first_c,decoded,first_u)){
      uint64_t hash=UINT64_C(14695981039346656037);
      for(uint32_t i=0;i<first_u;i++){hash^=decoded[i];hash*=UINT64_C(1099511628211);}
      append(&outb,"\"decoded\":true,\"bytes\":%u,\"compression\":%u,\"fnv64\":\"%016" PRIx64 "\"",first_u,first_flags&63u,hash);
      if(first_u>=20){
        uint32_t metadata_size=be32(decoded+0),embedded_file_size=be32(decoded+4),serialized_version=be32(decoded+8),data_start=be32(decoded+12);
        bool plausible=metadata_size>=16 && serialized_version>=5 && serialized_version<=50 && data_start>=metadata_size && embedded_file_size>=data_start;
        append(&outb,",\"possible_serialized_file_header\":%s",plausible?"true":"false");
        if(plausible)append(&outb,",\"serialized_file_version\":%u",serialized_version);
      }
    } else append(&outb,"\"decoded\":false,\"reason\":\"first block read/decompress failed\"");
    free(cin);free(decoded);
  }else append(&outb,"\"decoded\":false,\"reason\":\"first block exceeds cap or unsupported compression\"");
  append(&outb,"},\"cab_virtual_prefix\":");
  if(node_count==0){append(&outb,"{\"status\":\"NO_NODES\"}");}
  else {
    uint8_t bytes[MAX_CAB_PREFIX]={0};
    size_t wanted=first_node_bytes<MAX_CAB_PREFIX?(size_t)first_node_bytes:MAX_CAB_PREFIX;
    if(wanted>0&&cab_virtual_prefix(fd,file_size,info,block_table_pos,block_count,data_offset,first_node_offset,bytes,wanted)){
      append(&outb,"{\"status\":\"CAB_PREFIX_READ\",\"first_node_offset\":%" PRIu64 ",\"serialized_file\":",first_node_offset);
      print_cab_prefix(&outb,bytes,wanted);append(&outb,"}");
    }else append(&outb,"{\"status\":\"CAB_PREFIX_UNAVAILABLE\",\"reason\":\"bounded decoder cannot read selected node\"}");
  }
  append(&outb,",\"serialized_metadata_v22\":");
  if(node_count==0||first_node_bytes<48){meta_error(&outb,"no serialized CAB node");}
  else {
    uint8_t v22head[48];
    if(!cab_virtual_prefix(fd,file_size,info,block_table_pos,block_count,data_offset,first_node_offset,v22head,sizeof v22head)){
      meta_error(&outb,"cannot read CAB header");
    }else{
      uint32_t m=be32(v22head+20),v=be32(v22head+8);
      if(v!=22){append(&outb,"{\"status\":\"UNSUPPORTED_SERIALIZED_VERSION\",\"format_version\":%u}",v);}
      else if(m>MAX_CAB_METADATA || m<15 || (uint64_t)m+48u>first_node_bytes){
        meta_error(&outb,"declared metadata exceeds bounded probe");
      }else{
        size_t total=(size_t)m+48u;
        uint8_t* metadata=(uint8_t*)malloc(total);
        if(metadata && cab_virtual_prefix(fd,file_size,info,block_table_pos,block_count,data_offset,first_node_offset,metadata,total)){
          inspect_serialized_v22(&outb,metadata,total,first_node_bytes,
              fd,file_size,info,block_table_pos,block_count,data_offset,first_node_offset);
        }else meta_error(&outb,"could not decode bounded CAB metadata");
        free(metadata);
      }
    }
  }
  append(&outb,",\"read_only\":true,\"android_asset_compatibility_proven\":false,\"unity_integrated\":false,\"game_rendered\":false}");
  free(info);
  if(outb.overflow)make_failure(out,cap,"OUTPUT_TOO_LARGE","output capacity exhausted");
}
