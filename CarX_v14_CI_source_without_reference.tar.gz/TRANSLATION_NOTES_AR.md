المرحلة v14 لا تُرحّل جميع دوال GameAssembly.dll. إنجازات AOT القديمة
تظل مقارنات جزئية محدودة (1024 متجه) ولا تعادل تشغيل Unity/IL2CPP.

القارئ الجديد لا يترجم رسومات DirectX ولا يحول AssetBundle Windows تلقائياً
إلى AssetBundle Android. إثبات التوافق يتطلب اختبار تشغـيل فعلي.
