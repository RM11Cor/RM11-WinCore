# CarX Native Foundation v14 — Read-only Mesh Index & Vertex Buffer Byte Probe

تمت إضافة قارئ يعتمد على عقد TypeTree المسجلة في ملف SerializedFile v22، ويمر على
حقول كائن Mesh بترتيب التسلسل الأصلي. يدعم المصفوفات محدودة الحجم ومحاذاة 4 بايت،
ويحاول استخراج البايتات الخام من `m_IndexBuffer` و`m_VertexData.m_DataSize`
مع إزاحاتها **داخل كائن Mesh**، وليس أرقام عقد TypeTree.

إذا أمكن، يفحص نطاق فهارس SubMesh الأول مقارنةً بـ `m_VertexCount`، ويفصل
دائماً بين `raw bytes extracted` و `vertex positions decoded` (الأخير false).

القراءة محدودة 256 KiB لكل كائن، ومحصورة بعينات Mesh من ثلاث حزم UnityFS من
ملفات اللعبة الأصلية على هاتف المستخدم، ولا تعدل الملفات الأصلية.

فشل اجتياز نوع بيانات غير مدعوم يُسجل بالتقرير كـ `TYPE_TREE_OBJECT_WALK_INCOMPLETE`.
لا نفترض إزاحات أو أنواعاً لم يتم إثباتها، ولا نعتبر قراءة مخازن هندسة كافية
لرسم المجسم أو إثبات وجود Unity Player أو تشغيل CarX Street.

التحديث: نفس `applicationId=com.carx.nativefoundation.test.updates` وشهادة v7–v13
مع `versionCode=1400`. لا يُرفع المفتاح الخاص إلى GitHub.
