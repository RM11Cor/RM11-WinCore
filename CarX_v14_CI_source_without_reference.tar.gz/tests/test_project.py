import unittest,hashlib,xml.etree.ElementTree as ET,pathlib,re,struct,json,os
BASE=pathlib.Path(__file__).resolve().parents[1]
CPP=BASE/'app/src/main/cpp'
JAVA=BASE/'app/src/main/java/com/carx/nativefoundation/MainActivity.java'
REF=BASE/'app/src/main/assets/x86_reference_v2100.txt'
class ReleaseGuard(unittest.TestCase):
    def test_reference_hash(self):
        self.assertEqual(hashlib.sha256(REF.read_bytes()).hexdigest(), os.environ.get('CARX_REFERENCE_SHA','7d4eb4eb338d4fe3d7d5a29146b4dd248bb893b42a33b4a7461f9fdf0b6125ad'))
    def test_reference_records(self):
        lines=[x for x in REF.read_text().splitlines() if x and not x.startswith('#')]
        self.assertEqual(len(lines),1024)
        for i,line in enumerate(lines):
            v=list(map(int,line.split()))
            self.assertEqual(len(v),15)
            self.assertEqual((v[0],v[1]),(i//512,i%512))
    def test_known_assembly_sha(self):
        self.assertEqual(hashlib.sha256((CPP/'carx_prefix_a.S').read_bytes()).hexdigest(),'ee0210fc7d172f6b72aeb006f71ed8b9072b0bdb7c96eb366c26a41e509aceb6')
        self.assertEqual(hashlib.sha256((CPP/'carx_prefix_b.S').read_bytes()).hexdigest(),'ab42f72a6acdb2f2bc893c4cb0f949148f35a1824c89e1fafcb11587ac2feb57')
    def test_manifest(self):
        root=ET.parse(BASE/'app/src/main/AndroidManifest.xml').getroot()
        app=root.find('application'); self.assertIsNotNone(app)
        self.assertEqual(len(root.findall('uses-permission')),0)
    def test_java_native_matches_jni(self):
        j=JAVA.read_text(); c=(CPP/'native_bridge.c').read_text()
        for method in ('nativeRunDifferential','nativeProbeUnityFS','nativeProbePE','nativeProbeVulkan','nativeProbeGpu','nativeRenderVulkanSurface','nativeInspectBundleFd'):
            self.assertIn('native String '+method, j)
            self.assertIn('Java_com_carx_nativefoundation_MainActivity_'+method,c)
    def test_just_arm64(self):
        text=(BASE/'app/build.gradle').read_text()
        self.assertIn("abiFilters 'arm64-v8a'",text)
        self.assertIn("vulkan_gpu_probe.c",(CPP/'CMakeLists.txt').read_text())
    def test_user_scoped_saf(self):
        text=JAVA.read_text()
        self.assertIn('ACTION_OPEN_DOCUMENT_TREE',text)
        self.assertIn('takePersistableUriPermission',text)
        self.assertNotIn('MANAGE_EXTERNAL_STORAGE',text)
        self.assertNotIn('requestLegacyExternalStorage',text)
    def test_fail_closed_game_status(self):
        text=JAVA.read_text()
        self.assertIn('"game_boot_proven",false',text)
        self.assertIn('"unity_android_player_integrated",false',text)
        self.assertIn('FAIL_CLOSED',text)
    def test_no_windows_runtime(self):
        text=(CPP/'native_bridge.c').read_text()+(CPP/'carx_core.c').read_text()
        for bad in ('LoadLibraryA', 'NtCreateFile', 'wine_init', 'fexcore', 'qemu'):
            self.assertNotIn(bad,text)
    def test_ci_upload_apk(self):
        s=(BASE/'.github/workflows/build-native-foundation.yml').read_text()
        self.assertIn('assembleDebug',s)
        self.assertIn('upload-artifact@v4',s)
    def test_gpu_probe_guardrails(self):
        gpu=(CPP/'vulkan_gpu_probe.c').read_text()
        for function in ('vkCreateInstance','vkEnumeratePhysicalDevices','vkGetPhysicalDeviceQueueFamilyProperties',
                         'vkCreateDevice','vkDestroyDevice','vkDestroyInstance'):
            self.assertIn(function,gpu)
        self.assertIn('"game_rendered\\\":false',gpu)
        app=JAVA.read_text()
        self.assertIn('"vulkan_gpu_bringup"',app)
        self.assertIn('scanPlatformBundles',app)
        self.assertIn('vulkan_surface_frame',app)
        self.assertIn('android_target_assets_proven",false',app)
    def test_native_surface_frame_gate(self):
        code=(CPP/'vulkan_surface_frame.c').read_text()
        app=JAVA.read_text()
        cmake=(CPP/'CMakeLists.txt').read_text()
        for api in ('ANativeWindow_fromSurface','vkCreateAndroidSurfaceKHR','vkGetPhysicalDeviceSurfaceSupportKHR',
                    'vkCreateSwapchainKHR','vkAcquireNextImageKHR','vkCmdClearColorImage',
                    'vkQueueSubmit','vkQueuePresentKHR','vkDeviceWaitIdle'):
            self.assertIn(api,code)
        for missing in ('vkCreateGraphicsPipelines','UnityPlayer','GameAssembly.dll','Wine','FEX'):
            self.assertNotIn(missing,code)
        self.assertIn('\\"game_rendered\\":false',code)
        self.assertIn('SurfaceView',app)
        self.assertIn('surfaceCreated',app)
        self.assertIn('"game_boot_proven",false',app)
        self.assertIn(' android vulkan)',cmake)
    def test_unityfs_decoding_native_and_saf(self):
        code=(CPP/'unityfs_directory.c').read_text()
        bridge=(CPP/'native_bridge.c').read_text()
        java=JAVA.read_text()
        for required in ('pread(', 'lz4_decode(', 'node_count', 'MAX_DIRECTORY_COUNT',
                         'MAX_INFO_UNCOMPRESSED', 'PASS_UNITYFS_DIRECTORY_DECODED',
                         'android_asset_compatibility_proven'):
            self.assertIn(required,code)
        self.assertIn('unityfs_directory.c',(CPP/'CMakeLists.txt').read_text())
        self.assertIn('Java_com_carx_nativefoundation_MainActivity_nativeInspectBundleFd',bridge)
        self.assertIn('getContentResolver().openFileDescriptor',java)
        self.assertIn('unityfs_directory_probes',java)
        self.assertIn('"game_boot_proven",false',java)
    def test_serialized_v22_bounded_parser(self):
        code=(CPP/'unityfs_directory.c').read_text()
        for required in ('MAX_CAB_METADATA','MAX_SERIALIZED_TYPES','MAX_SERIALIZED_OBJECTS','PASS_V22_METADATA_OBJECT_INDEX','METADATA_PARSE_INCOMPLETE','class_id_sample','object_class_id_sample'):
            self.assertIn(required,code)
        gradle=(BASE/'app/build.gradle').read_text()
        self.assertIn('versionCode 1400',gradle)
        self.assertIn('type_tree_inspection',code)
        self.assertIn('PASS_BOUNDED_TYPETREE_NODES',code)
        self.assertIn('CarX_NativeFoundation_v14_Report.json',JAVA.read_text())
        self.assertIn('AOT_GPU_UNITYFS_MESH_BUFFERS_PROBED_NO_GAME_BOOT',JAVA.read_text())
        self.assertIn("applicationId 'com.carx.nativefoundation.test.updates'",gradle)
    def test_v14_geometry_field_locator_guards(self):
        code=(CPP/'unityfs_directory.c').read_text()
        for required in ('mesh_geometry_field(', 'mesh_geometry_field_locator', 'm_IndexBuffer', 'm_VertexData', 'ALL_TYPETREE_NODES_LOCAL_STRINGS_ONLY', 'serialized_object_offsets_proven'):
            self.assertIn(required,code)
        self.assertIn('versionCode 1400',(BASE/'app/build.gradle').read_text())
        self.assertIn('v14_mesh_buffer_report',code)
        self.assertIn('mesh_geometry_v14.inc',code)
        self.assertIn('CarX_NativeFoundation_v14_Report.json',JAVA.read_text())
        self.assertIn('AOT_GPU_UNITYFS_MESH_BUFFERS_PROBED_NO_GAME_BOOT',JAVA.read_text())
        self.assertIn("applicationId 'com.carx.nativefoundation.test.updates'",(BASE/'app/build.gradle').read_text())
    def test_app_has_no_full_game_binaries(self):
        for p in (BASE/'app').rglob('*'):
            if p.is_file():self.assertNotIn(p.suffix.lower(),{'.exe','.dll','.assets','.bundle','.apk'})
    def test_assembly_is_current_v2100_source(self):
        self.assertIn('0x008A78C0',(CPP/'carx_prefix_a.S').read_text())
        self.assertIn('0x0089B660',(CPP/'carx_prefix_b.S').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
