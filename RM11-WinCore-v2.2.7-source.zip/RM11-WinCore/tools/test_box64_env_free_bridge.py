#!/usr/bin/env python3
"""Compile a host fixture exercising the opt-in Bionic borrowed-environ-pointer guard.

This is NOT an Android NDK build or a Wine execution test.
"""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import tempfile

spec = importlib.util.spec_from_file_location('rm11_box64',Path(__file__).with_name('build_official_box64.py'))
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory(prefix='rm11-v226-env-free-') as td:
    root=Path(td)
    priv=root/'src/wrapped/wrappedlibc_private.h'
    impl=root/'src/wrapped/wrappedlibc.c'
    types=root/'src/wrapped/generated/wrappedlibctypes.h'
    types.parent.mkdir(parents=True)
    priv.write_text('GO(free, vFp)\nGOW(secure_getenv, pFp)\n')
    types.write_text('')
    impl.write_text(r'''#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#define EXPORT
struct x64emu_s { int unused; };typedef struct x64emu_s x64emu_t;
#include "generated/wrappedlibctypes.h"
int main(void) {
    if(setenv("RM11_TEST_ENV_FREE_GUARD", "1", 1)) return 10;
    if(setenv("RM11_TEST_OWNED_POINTER", "borrowed-value", 1)) return 11;
    char* ptr = my_secure_getenv(0, "RM11_TEST_OWNED_POINTER");
    if(!ptr || strcmp(ptr, "borrowed-value")) return 12;
    /* Native free(ptr) would be invalid. Our opt-in wrapper must skip it. */
    my_free(0, ptr);
    if(strcmp(getenv("RM11_TEST_OWNED_POINTER"), "borrowed-value")) return 13;
    /* Check a genuinely malloc-owned pointer is still normally released. */
    char* owned = malloc(48);
    if(!owned) return 14;
    strcpy(owned, "allocated");
    my_free(0, owned);
    if(setenv("RM11_TEST_ENV_FREE_GUARD", "0", 1)) return 15;
    if(strcmp(my_secure_getenv(0, "RM11_TEST_OWNED_POINTER"), "borrowed-value")) return 16;
    char* owned2=malloc(19);
    if(!owned2) return 17;
    my_free(0, owned2);
    return 0;
}
''')
    mod.patch_box64_borrowed_env_free_diagnostic(root)
    assert 'GOM(free, vFEp)' in priv.read_text()
    assert 'GOM(secure_getenv, pFEp)' in priv.read_text()
    assert impl.read_text().count('EXPORT void my_free(') == 1
    assert impl.read_text().count('EXPORT void* my_secure_getenv(') == 1
    cc=shutil.which('cc') or shutil.which('clang')
    if cc:
        exe=root/'test-env-free'
        subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Werror','-DANDROID',
                        '-Dsecure_getenv=__RM11_ANDROID_SYMBOL_UNAVAILABLE',
                        str(impl),'-o',str(exe)],check=True,timeout=30)
        done=subprocess.run([str(exe)],capture_output=True,text=True,check=True,timeout=10)
        assert 'RM11_ENV_FREE_RETURN borrowed=' in done.stderr,done.stderr
        assert done.stderr.count('RM11_ENV_FREE_MATCH') == 1,done.stderr
        assert 'borrowed-value' not in done.stderr,'Never log secrets/env values'
    for mode in ('repeat','changed'):
        if mode=='changed': priv.write_text('GO(free, WRONG)\nGOW(secure_getenv, pFp)\n')
        try: mod.patch_box64_borrowed_env_free_diagnostic(root)
        except RuntimeError: pass
        else: raise AssertionError('Must refuse patch on '+mode)
print('PASS: opt-in borrowed secure_getenv/free exact-pointer host fixture (Android NDK / Wine still unverified)')
