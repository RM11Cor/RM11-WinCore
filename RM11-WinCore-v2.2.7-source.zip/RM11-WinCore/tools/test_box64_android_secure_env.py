#!/usr/bin/env python3
"""Bionic API guard: secure_getenv is NOT exported on Android.

Check the source-emitted Android branch and generated wrapper via synthetic host
compiler with native secure_getenv deliberately unavailable. Does not replace
an actual Android NDK build.
"""
from pathlib import Path
import importlib.util, subprocess, tempfile, shutil
builder_path=Path(__file__).with_name('build_official_box64.py')
spec=importlib.util.spec_from_file_location('rm11_bionic_secure', builder_path)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
assert 'getauxval(AT_SECURE) ? NULL : getenv(key)' in builder_path.read_text()
assert '#include <sys/auxv.h>' in builder_path.read_text()
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    priv=root/'src/wrapped/wrappedlibc_private.h'
    impl=root/'src/wrapped/wrappedlibc.c'
    types=root/'src/wrapped/generated/wrappedlibctypes.h'
    types.parent.mkdir(parents=True)
    types.write_text('')
    priv.write_text('GO(free, vFp)\nGOW(secure_getenv, pFp)\n')
    impl.write_text('#define _GNU_SOURCE\n#include <stdlib.h>\n#include <stdint.h>\n#include <stdio.h>\n'
                    '#define EXPORT\ntypedef struct { int unused; } x64emu_t;\n'
                    '#include "generated/wrappedlibctypes.h"\n'
                    'int main(void){return my_secure_getenv(NULL,"RM11_NO_SUCH_KEY") != NULL;}\n')
    mod.patch_box64_borrowed_env_free_diagnostic(root)
    generated=impl.read_text()
    assert '#ifdef ANDROID\n#include <sys/auxv.h>' in generated
    assert 'char* value = getauxval(AT_SECURE) ? NULL : getenv(key);' in generated
    assert '#else\n    char* value = secure_getenv(key);' in generated
    cc=shutil.which('cc') or shutil.which('clang')
    if cc:
        # A strict link checks that no unsupported Android secure_getenv call remains.
        out=root/'exe'
        subprocess.run([cc,'-DANDROID','-Dsecure_getenv=__RM11_ABSENT_ON_BIONIC',
                        '-std=c11','-Wall','-Wextra','-Werror',str(impl),'-o',str(out)],
                       check=True,timeout=30)
        subprocess.run([str(out)],check=True,timeout=10)
print('PASS: Bionic getenv/getauxval secure getenv fallback, poisoned nonexistent symbol (host fixture)')
