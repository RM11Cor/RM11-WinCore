from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parent
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
assert manifest.tag == 'manifest'
java = (root / 'app/src/main/java/com/rm11/wincore/MainActivity.java').read_text()
catalog = (root / 'app/src/main/java/com/rm11/wincore/LauncherCatalog.java').read_text()
native = (root / 'app/src/main/cpp/VulkanProbe.cpp').read_text()
for term in ('steam', 'ubisoft', 'ea', 'rockstar'):
    assert f'new Launcher("{term}"' in catalog
assert 'ACTION_OPEN_DOCUMENT' in java and 'ACTION_CREATE_DOCUMENT' in java
assert 'RuntimeGateway.currentStatusArabic()' in java
assert 'vkEnumeratePhysicalDevices' in native
assert 'ACCESS_ALL_FILES' not in str(manifest.attrib)
print('PASS: project files, manifest, official launcher IDs, Vulkan native probe and report actions present')

ready = (root / 'app/src/main/java/com/rm11/wincore/RuntimeReadiness.java').read_text()
assert 'RuntimeReadiness.inspect' in java
assert 'NOT INTEGRATED' in ready and 'NX809J' in ready
assert 'vkGetPhysicalDeviceFeatures2' in native
print('PASS: V0.2 preflight and Vulkan feature bits are present')

# V0.3 source checks: read-only PE header, private workspace, native Android subprocess.
pe=(root/'app/src/main/java/com/rm11/wincore/PeInspector.java').read_text()
boot=(root/'app/src/main/java/com/rm11/wincore/RuntimeBootstrap.java').read_text()
assert 'MAX_HEADER = 1024 * 1024' in pe and "case 0x8664" in pe
assert 'process.waitFor(8, TimeUnit.SECONDS)' in boot and 'correctDevice()' in boot
assert 'rm11-runtime' in boot and 'wine-prefix-placeholder' in boot
assert 'new Thread' in java and 'PeInspector.inspect' in java
assert 'versionName = "0.5.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: inherited V0.3 workspace, bounded PE inspection and native subprocess checks')

# V0.4: streaming bundle audit with bounded data and no process execution.
bundle=(root/'app/src/main/java/com/rm11/wincore/EngineBundleVerifier.java').read_text()
assert 'MAX_TOTAL' in bundle and 'MessageDigest.getInstance("SHA-256")' in bundle
assert 'ZipInputStream' in bundle and 'RuntimeBootstrap.correctDevice()' in bundle
assert 'EngineBundleVerifier.verify' in java and 'VERIFY_ENGINE_BUNDLE' in java
assert 'NOT READY' in bundle and 'does NOT' not in bundle  # status does not claim executable Wine
print('PASS: V0.4 read-only streaming runtime bundle audit and device restrictions')

# V0.5: static graphics API hints and balanced *suggestions*, no claim of runnable Windows games.
import subprocess
import tempfile
assert 'WindowsExecutableAnalyzer.analyze' in java
assert 'SmartGameProfile.recommend' in java
assert 'GAME_PROFILE_PICK' in java and 'GAME_PROFILE_EXPORT' in java
assert 'no EXE execution' in (root/'app/src/main/java/com/rm11/wincore/SmartGameProfile.java').read_text()
print('PASS: V0.5 read-only EXE advisor UI and explicit no-execution status')
with tempfile.TemporaryDirectory(prefix='rm11-tests-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                    str(src/'WindowsExecutableAnalyzer.java'),
                    str(src/'SmartGameProfile.java'),
                    str(root/'tests/CompatibilityAnalysisTest.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'CompatibilityAnalysisTest'], check=True)
