package com.rm11.wincore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Arabic-first, offline diagnostic shell targeted at one device model. */
public final class MainActivity extends Activity {
    private static final int IMPORT_BASE = 180;
    private static final int REPORT_EXPORT = 360;
    private static final int INSPECT_PE = 480;
    private static final int VERIFY_ENGINE_BUNDLE = 580;
    private static final int GAME_PROFILE_PICK = 590;
    private static final int GAME_PROFILE_EXPORT = 591;
    private static final int BG = Color.rgb(8, 13, 24);
    private static final int SURFACE = Color.rgb(18, 28, 43);
    private static final int MUTED = Color.rgb(166, 181, 199);
    private static final int MINT = Color.rgb(62, 225, 188);
    private static final int WHITE = Color.rgb(239, 244, 252);
    private LinearLayout content;
    private TextView reportView;
    private Button scanButton;
    private Button preflightButton;
    private TextView preflightView;
    private TextView runtimeV03View;
    private TextView engineBundleStatusView;
    private TextView gameProfileView;
    private String gameProfile = "لم يتم فحص ملف لعبة بعد.";
    private String report = "لم يتم فحص الجهاز بعد. اضغط «فحص الهاتف الآن».";
    private final Map<String, TextView> installerStatusViews = new HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radius));
        return gd;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private void addSpace(LinearLayout p, int dpHeight) {
        View spacer = new View(this);
        p.addView(spacer, new LinearLayout.LayoutParams(1, dp(dpHeight)));
    }

    private LinearLayout card(String heading) {
        LinearLayout box = column();
        box.setPadding(dp(17), dp(16), dp(17), dp(16));
        box.setBackground(shape(SURFACE, 18));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        content.addView(box, params);
        if (!TextUtils.isEmpty(heading)) {
            box.addView(text(heading, 18, WHITE, true));
            addSpace(box, 6);
        }
        return box;
    }

    private Button button(String label, boolean primary, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(primary ? BG : WHITE);
        b.setBackground(shape(primary ? MINT : Color.rgb(42, 58, 77), 12));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setMinHeight(dp(46));
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        b.setLayoutParams(params);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content = column();
        content.setPadding(dp(16), dp(22), dp(16), dp(36));
        scroll.addView(content);
        setContentView(scroll);

        content.addView(text("RM11 WinCore", 32, MINT, true));
        content.addView(text("REDMAGIC 11 PRO  •  16GB / 512GB", 14, WHITE, true));
        content.addView(text("V0.5 — تحليل توافق الألعاب ومقترحات التوازن — مخصصة لهاتفك فقط", 13, MUTED, false));
        addSpace(content, 18);

        LinearLayout intro = card("بداية المشروع");
        intro.addView(text("هذا تطبيق حقيقي للفحص وإدارة ملفات تثبيت المشغّلات الرسمية. نسخة V0.5 تضيف قراءة معلومات ملف EXE واقتراح إعدادات أولية للتوازن بين الرسومات وFPS، إلى جانب أدوات الفحص السابقة. لم يتم دمج Wine/Box64 أو تشغيل برامج ويندوز بعد.", 14, MUTED, false));
        intro.addView(text("✓ فحص العتاد    ✓ فحص Vulkan    ✓ ملفات EXE    ✓ تقرير قابل للمشاركة", 13, MINT, false));

        LinearLayout diag = card("01  •  فحص جهاز REDMAGIC");
        diag.addView(text("سنقرأ معلومات الجهاز الحقيقية، الرام والتخزين وVulkan وحالة الحرارة. لا يتطلب روت أو تسجيل دخول.", 14, MUTED, false));
        scanButton = button("فحص الهاتف الآن", true, v -> runScan());
        diag.addView(scanButton);
        diag.addView(button("تصدير تقرير الفحص TXT", false, v -> exportReport()));
        reportView = text(report, 12, WHITE, false);
        reportView.setTextDirection(View.TEXT_DIRECTION_LTR);
        reportView.setGravity(Gravity.LEFT);
        reportView.setTextIsSelectable(true);
        reportView.setTypeface(Typeface.MONOSPACE);
        reportView.setPadding(dp(10), dp(10), dp(10), dp(10));
        reportView.setBackground(shape(Color.rgb(11, 18, 29), 10));
        LinearLayout.LayoutParams reportParams = new LinearLayout.LayoutParams(-1, -2);
        reportParams.topMargin = dp(12);
        diag.addView(reportView, reportParams);

        LinearLayout readiness = card("02  •  جاهزية المحرك على هاتفك");
        readiness.addView(text("يفحص المطابقة مع NX809J والذاكرة والتخزين وميزات Vulkan الحقيقية. هذا لا يقوم بتثبيت Wine/Box64 ولا يشغّل EXE.", 14, MUTED, false));
        preflightButton = button("فحص جاهزية المحرك", true, v -> runPreflight());
        readiness.addView(preflightButton);
        preflightView = text("لم يتم فحص جاهزية المحرك بعد.", 12, WHITE, false);
        preflightView.setTextDirection(View.TEXT_DIRECTION_LTR);
        preflightView.setGravity(Gravity.LEFT);
        preflightView.setTextIsSelectable(true);
        preflightView.setTypeface(Typeface.MONOSPACE);
        preflightView.setPadding(dp(10), dp(10), dp(10), dp(10));
        preflightView.setBackground(shape(Color.rgb(11, 18, 29), 10));
        readiness.addView(preflightView);

        LinearLayout bootstrap = card("03  •  تجهيز مساحة المحرك واختبار العمليات");
        bootstrap.addView(text("اختبار عملي جديد: ننشئ مجلدات خاصة بالتطبيق، نختبر تشغيل عملية أندرويد ARM64، ونفحص ترويسة EXE بدون تشغيلها. هذي مو بيئة Wine لحد الآن.", 14, MUTED, false));
        runtimeV03View = text("ما تم تشغيل اختبارات V0.3 بعد.", 12, WHITE, false);
        runtimeV03View.setTextDirection(View.TEXT_DIRECTION_LTR);
        runtimeV03View.setGravity(Gravity.LEFT);
        runtimeV03View.setTextIsSelectable(true);
        runtimeV03View.setTypeface(Typeface.MONOSPACE);
        runtimeV03View.setPadding(dp(10), dp(10), dp(10), dp(10));
        runtimeV03View.setBackground(shape(Color.rgb(11, 18, 29), 10));
        bootstrap.addView(button("1 — إنشاء مساحة المحرك المحلية", true, v -> runBootstrap(false)));
        bootstrap.addView(button("2 — اختبار تنفيذ عملية ARM64", false, v -> runBootstrap(true)));
        bootstrap.addView(button("3 — فحص بنية ملف Windows EXE", false, v -> choosePe()));
        bootstrap.addView(runtimeV03View);

        LinearLayout compatibility = card("04  •  RM11 Smart Balance — فحص لعبة تلقائياً");
        compatibility.addView(text("اختر ملف EXE أصلياً من لعبتك. نقرأ ترويسة PE وجدول استيراد DLL بصورة آمنة ونقترح دقة وهدف FPS مبدئيين لهاتفك، دون تشغيل اللعبة. هذا ليس كشفاً مضموناً لاسم اللعبة أو قياساً فعلياً للأداء.", 14, MUTED, false));
        compatibility.addView(button("تحليل EXE واقتراح توازن الرسوميات / FPS", true, v -> chooseGameForProfile()));
        compatibility.addView(button("تصدير مقترحات التوازن TXT", false, v -> exportGameProfile()));
        gameProfileView = text(gameProfile, 12, WHITE, false);
        gameProfileView.setTextDirection(View.TEXT_DIRECTION_LTR);
        gameProfileView.setGravity(Gravity.LEFT);
        gameProfileView.setTextIsSelectable(true);
        gameProfileView.setTypeface(Typeface.MONOSPACE);
        gameProfileView.setPadding(dp(10), dp(10), dp(10), dp(10));
        gameProfileView.setBackground(shape(Color.rgb(11, 18, 29), 10));
        compatibility.addView(gameProfileView);

        LinearLayout engineAudit = card("05  •  تدقيق مكونات محرك V0.4");
        engineAudit.addView(text("اختر حزمة RM11 الخاصة بالمحرك وفق مخططنا، لفحص الملفات و SHA256 والمعمارية والتراخيص قراءةً فقط. لا تستخدم APK الخاص بـ Winlator أو ZIP المصدر: هذان ليسا حزمة محرك. لا يتم التثبيت أو التشغيل هنا.", 14, MUTED, false));
        engineAudit.addView(button("فحص حزمة مكونات المحرك (ZIP)", false, v -> chooseEngineBundle()));
        engineBundleStatusView = text("لم يتم اختيار حزمة محرك. Wine/Box64 غير مدمجين بعد.", 12, WHITE, false);
        engineBundleStatusView.setTextDirection(View.TEXT_DIRECTION_LTR);
        engineBundleStatusView.setGravity(Gravity.LEFT);
        engineBundleStatusView.setTextIsSelectable(true);
        engineBundleStatusView.setTypeface(Typeface.MONOSPACE);
        engineBundleStatusView.setPadding(dp(10), dp(10), dp(10), dp(10));
        engineBundleStatusView.setBackground(shape(Color.rgb(11, 18, 29), 10));
        engineAudit.addView(engineBundleStatusView);

        LinearLayout launchers = card("06  •  مركز المشغّلات الرسمية");
        launchers.addView(text("نفتح مواقع الشركات الأصلية فقط، ثم نربط ملف التثبيت الذي اخترته. لن ننسخ المشغّلات أو نطلب كلمات المرور.", 14, MUTED, false));
        for (int i = 0; i < LauncherCatalog.ALL.length; ++i) {
            LauncherCatalog.Launcher item = LauncherCatalog.ALL[i];
            LinearLayout itemBox = column();
            itemBox.setPadding(dp(12), dp(12), dp(12), dp(12));
            itemBox.setBackground(shape(Color.rgb(25, 38, 55), 12));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.topMargin = dp(10);
            launchers.addView(itemBox, params);
            itemBox.addView(text(item.name, 17, WHITE, true));
            itemBox.addView(text(item.description, 13, MUTED, false));
            TextView linked = text(linkedInstallerStatus(item.id), 12, MINT, false);
            installerStatusViews.put(item.id, linked);
            itemBox.addView(linked);
            itemBox.addView(button("زيارة الموقع الرسمي", false, v -> openOfficial(item.officialUrl)));
            final int index = i;
            itemBox.addView(button("ربط ملف تثبيت EXE / MSI", false, v -> chooseInstaller(index)));
        }

        LinearLayout online = card("07  •  توافق الأونلاين");
        online.addView(text("المشغّل الرسمي ليس تصريحاً لتشغيل لعبة محمية. صلاحية اللعب يحددها ناشر اللعبة ونظام مكافحة الغش.", 14, MUTED, false));
        online.addView(text("• The Crew Motorfest: مشغّل Ubisoft مطلوب؛ التوافق على أندرويد غير مثبت.", 13, WHITE, false));
        online.addView(text("• PUBG PC: لا يوجد إثبات توافق رسمي على محاكينا.", 13, WHITE, false));
        online.addView(text("• Battlefield 6: Secure Boot وEA Javelin عائق حقيقي أمام طبقات Wine.", 13, WHITE, false));
        online.addView(text("• GTA Online: روكستار لا تدعم BattlEye على Steam Deck؛ لا نعد بالدعم هنا.", 13, WHITE, false));

        LinearLayout runtime = card("08  •  حالة محرك الألعاب");
        runtime.addView(text(RuntimeGateway.currentStatusArabic(), 14, MUTED, false));
        runtime.addView(text("خطة الدمج: Wine → Box64 → Vulkan/DXVK → إدخال وصوت → تشغيل برامج اختبار → المشغّلات.", 13, WHITE, false));
        runtime.addView(text("RM11 WinCore مشروع مستقل؛ غير تابع لـ Valve أو Ubisoft أو EA أو Rockstar.", 12, MUTED, false));
    }

    private void runScan() {
        scanButton.setEnabled(false);
        scanButton.setText("جاري فحص Vulkan ومواصفات الجهاز…");
        reportView.setText("جاري الفحص محلياً، بدون إرسال البيانات إلى أي خادم.");
        new Thread(() -> {
            String result;
            try { result = DeviceProbe.inspect(getApplicationContext()); }
            catch (Throwable t) { result = "فشل الفحص: " + t; }
            final String finalResult = result;
            runOnUiThread(() -> {
                report = finalResult;
                reportView.setText(report);
                scanButton.setText("إعادة فحص الهاتف");
                scanButton.setEnabled(true);
            });
        }, "rm11-device-probe").start();
    }

    private void runPreflight() {
        preflightButton.setEnabled(false);
        preflightButton.setText("جاري فحص جاهزية المحرك…");
        preflightView.setText("جاري فحص العتاد محلياً. لا يتم تشغيل أي ملف EXE.");
        new Thread(() -> {
            String result;
            try { result = RuntimeReadiness.inspect(getApplicationContext()); }
            catch (Throwable t) { result = "Preflight error: " + t.getMessage(); }
            final String finalResult = result;
            runOnUiThread(() -> {
                preflightView.setText(finalResult);
                preflightButton.setText("إعادة فحص جاهزية المحرك");
                preflightButton.setEnabled(true);
            });
        }, "rm11-runtime-preflight").start();
    }

    private void runBootstrap(boolean subprocess) {
        runtimeV03View.setText("جاري الاختبار المحلي…");
        new Thread(() -> {
            String info = subprocess ? RuntimeBootstrap.testSubprocess(getApplicationContext()) :
                RuntimeBootstrap.init(getApplicationContext());
            runOnUiThread(() -> runtimeV03View.setText(info));
        }, "rm11-runtime-bootstrap").start();
    }

    private void chooseGameForProfile() {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("*/*");
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(picker, GAME_PROFILE_PICK); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تطبيق اختيار الملفات غير متوفر.", Toast.LENGTH_LONG).show();
        }
    }

    private void exportGameProfile() {
        if (gameProfile.startsWith("لم يتم")) {
            Toast.makeText(this, "اختار ملف EXE وحلّله أولاً.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("text/plain");
        save.putExtra(Intent.EXTRA_TITLE, "RM11-Smart-Balance-Report.txt");
        try { startActivityForResult(save, GAME_PROFILE_EXPORT); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تصدير الملفات غير متوفر.", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseEngineBundle() {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("application/zip");
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(picker, VERIFY_ENGINE_BUNDLE); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تطبيق اختيار الملفات غير متوفر.", Toast.LENGTH_LONG).show();
        }
    }

    private void choosePe() {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("*/*");
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(picker, INSPECT_PE); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تطبيق اختيار الملفات غير متوفر.", Toast.LENGTH_LONG).show();
        }
    }

    private void openOfficial(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "ماكو متصفح مثبت لفتح الرابط.", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseInstaller(int index) {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("*/*");
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(picker, IMPORT_BASE + index);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "تطبيق اختيار الملفات غير متوفر.", Toast.LENGTH_LONG).show();
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        return name != null ? name : uri.getLastPathSegment();
    }

    private SharedPreferences preferences() {
        return getSharedPreferences("launcher-installer-uris", MODE_PRIVATE);
    }

    private String linkedInstallerStatus(String id) {
        String name = preferences().getString("name." + id, null);
        return name == null ? "الحالة: لم يتم ربط ملف تثبيت بعد" : "ملف مرتبط: " + name + "  •  غير مثبّت";
    }

    private void exportReport() {
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("text/plain");
        save.putExtra(Intent.EXTRA_TITLE, "RM11-WinCore-Device-Report.txt");
        try { startActivityForResult(save, REPORT_EXPORT); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "تصدير الملفات غير متوفر.", Toast.LENGTH_LONG).show(); }
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == GAME_PROFILE_PICK) {
            String chosenName = displayName(uri);
            if (chosenName == null || !chosenName.toLowerCase(Locale.ROOT).endsWith(".exe")) {
                gameProfileView.setText("[FAIL] اختار ملف Windows EXE فقط، مو APK أو ZIP.");
                return;
            }
            gameProfileView.setText("جاري تحليل ملف EXE محلياً، بدون تثبيت أو تشغيل...");
            new Thread(() -> {
                String info;
                try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                    WindowsExecutableAnalyzer.Result pe = WindowsExecutableAnalyzer.analyze(in, chosenName);
                    info = SmartGameProfile.recommend(pe);
                } catch (Exception ex) {
                    info = "[FAIL] فشل تحليل EXE: " + ex.getClass().getSimpleName() + ": " + ex.getMessage();
                }
                final String result = info;
                runOnUiThread(() -> {
                    gameProfile = result;
                    gameProfileView.setText(result);
                });
            }, "rm11-smart-balance-preview").start();
            return;
        }
        if (requestCode == GAME_PROFILE_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IllegalStateException("No output stream");
                out.write(gameProfile.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "تم حفظ تقرير التوازن المبدئي.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "تعذر حفظ التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode == VERIFY_ENGINE_BUNDLE) {
            engineBundleStatusView.setText("جاري تدقيق الحزمة بدون تثبيت أو تشغيل...");
            new Thread(() -> {
                String info = EngineBundleVerifier.verify(getContentResolver(), uri);
                runOnUiThread(() -> engineBundleStatusView.setText(info));
            }, "rm11-bundle-audit").start();
            return;
        }
        if (requestCode == INSPECT_PE) {
            runtimeV03View.setText("جاري فحص ترويسة الملف، دون تشغيله…");
            new Thread(() -> {
                String info = PeInspector.inspect(getContentResolver(), uri);
                runOnUiThread(() -> runtimeV03View.setText(info));
            }, "rm11-pe-inspector").start();
            return;
        }
        if (requestCode == REPORT_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IllegalStateException("No output stream");
                out.write(report.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "تم حفظ تقرير الفحص.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "تعذر حفظ التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
            return;
        }
        int index = requestCode - IMPORT_BASE;
        if (index < 0 || index >= LauncherCatalog.ALL.length) return;
        String name = displayName(uri);
        if (name == null) name = "unknown";
        String lowerName = name.toLowerCase(Locale.ROOT);
        if (!(lowerName.endsWith(".exe") || lowerName.endsWith(".msi"))) {
            new AlertDialog.Builder(this).setTitle("ملف غير مناسب")
                .setMessage("اختار ملف تثبيت ويندوز أصلي بامتداد EXE أو MSI.")
                .setPositiveButton("حسناً", null).show();
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException exception) {
            Toast.makeText(this, "لم يتم تثبيت إذن الملف؛ قد تحتاج إلى إعادة اختياره لاحقاً.", Toast.LENGTH_LONG).show();
        }
        String id = LauncherCatalog.ALL[index].id;
        preferences().edit().putString("uri." + id, uri.toString()).putString("name." + id, name).apply();
        TextView status = installerStatusViews.get(id);
        if (status != null) status.setText(linkedInstallerStatus(id));
        new AlertDialog.Builder(this)
            .setTitle("تم ربط الملف")
            .setMessage("حُفظ رابط ملف «" + name + "» على هاتفك. لم يتم تثبيته أو تشغيله لأن محرك Wine غير مدمج في النسخة الحالية.")
            .setPositiveButton("مفهوم", null).show();
    }
}
