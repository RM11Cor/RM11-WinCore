#!/usr/bin/env python3
"""Linux-only sanity check: executable alias -> C bridge -> Box64 -> wine server.

This models the real exec/argv forwarding and logging without pretending Linux
execution validates Android SELinux, Android linker, or full Wine startup.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
CC = shutil.which('cc') or shutil.which('gcc')
if not CC:
    print('SKIP: host C compiler missing; Java alias tests still cover symlink setup')
    raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='rm11-server-alias-') as td:
    root = Path(td)
    install = root / 'apk-native'
    install.mkdir()
    exe = install / 'librm11wineserverbridge.so'
    subprocess.run([CC, '-O2', '-fPIE', '-pie', '-Wall', '-Wextra',
        str(ROOT / 'app/src/main/cpp/WineServerBridge.c'), '-o', str(exe)], check=True)
    box = install / 'librm11box64.so'
    box.write_text('#!/bin/sh\nprintf "MOCK_BOX64_ARG_1=%s\\nMOCK_BOX64_ARG_2=%s\\n" "$1" "$2"\nexec "$@"\n')
    box.chmod(0o755)
    server = root / 'wine-runtime/usr/lib/wine/wineserver64'
    server.parent.mkdir(parents=True)
    server.write_text('#!/bin/sh\necho MOCK_WINESERVER_VERSION_OK\n')
    server.chmod(0o755)
    alias = server.parent / 'wineserver'
    alias.symlink_to(exe)
    env = os.environ.copy()
    env['RM11_WINESERVER64_PATH'] = str(server)
    ran = subprocess.run([str(alias), '--version'], env=env, capture_output=True, text=True, timeout=6)
    assert ran.returncode == 0, ran
    assert 'RM11_WINESERVER_BRIDGE_ENTER' in ran.stderr, ran.stderr
    assert 'MOCK_WINESERVER_VERSION_OK' in ran.stdout, ran.stdout
    assert 'MOCK_BOX64_ARG_1=' + str(server) in ran.stdout, ran.stdout
    assert 'MOCK_BOX64_ARG_2=--version' in ran.stdout, ran.stdout
    print('PASS: Wine wineserver alias -> real C native bridge -> Box64 argv -> guest wineserver64 mock')
