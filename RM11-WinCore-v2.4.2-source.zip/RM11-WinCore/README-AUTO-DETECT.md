# RM11 AutoCore v2.4.2 — structural game and executable inspection

This package continues the installable Android 16 diagnostic app project. It is NOT yet
an EXE runtime/emulator and does not ship Wine, Proton, FEX, Vulkan drivers or launchers.

**Features**
- Select one user-approved game folder using Android's system folder picker (SAF).
- Recursively enumerate up to 8,000 items with a depth cap of ten, explicitly reporting
  partial scans. Does not scan outside the selected tree.
- Infer an unknown game's name by PE metadata, then filenames/folder names. **No title list**.
- Inspect Win32 PE header architecture and bounded import DLL names (read-only and
  seek-based); identify likely DX9/DX11/DX12/Vulkan/OpenGL imports.
- Infer Unity, Unreal, Godot or Ren'Py from generic file-layout markers; no exhaustive
  verification, no automatic mapping from graphics hints to compatibility versions.
- Label Steam/Ubisoft/EA/Rockstar/EOS presence as circumstantial; this does NOT prove
  a license, game entitlement or a requirement to run a specific launcher.
- Save diagnostic JSON in app-private storage; never execute/edit/copy a game's files.

**Known limits**
- PE direct-import evidence misses dynamically-loaded and delay-loaded libraries.
- Unity can advertise a generic Unity executable version; it is NOT game version.
- SAF providers may reject seekable file access; then only folder/name inference works.
- Identifying an engine or DirectX is not proof the game can run on Adreno/Android.
- Scans are depth/item-limited; detection can be wrong for multi-EXE installers.
- Launcher detection is heuristic, and installing/running official launchers is future work.

**Build**
Upload the ZIP archive to the root of the existing `RM11Cor/RM11-WinCore` GitHub
repository. Existing Actions workflow extracts the highest-versioned `RM11-WinCore-v*-source.zip`
under `RM11-WinCore/` and builds a debug APK. Do not delete old sources.

**Versioning**
- Android package `com.rm11.autocore` unchanged.
- `versionCode` 3, `versionName` `0.3.0-alpha`; project source release `v2.4.2`.
- A debug APK may require uninstall if the signing key differs from an earlier run.
  Back up app-local profiles before uninstalling.
