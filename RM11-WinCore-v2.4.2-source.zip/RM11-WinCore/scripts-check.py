#!/usr/bin/env python3
"""Reject structurally incomplete source ZIPs before the legacy build job runs."""
from pathlib import Path
needed = [
    'settings.gradle',
    'build.gradle',
    'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/rm11/autocore/MainActivity.java',
    'app/src/main/java/com/rm11/autocore/GameDetector.java',
    'app/src/main/java/com/rm11/autocore/PeVersionReader.java',
    'app/src/main/java/com/rm11/autocore/PeImportReader.java',
    'app/src/test/java/com/rm11/autocore/GameDetectorTest.java',
    'app/src/test/java/com/rm11/autocore/PeImportReaderTest.java'
]
for filename in needed:
    path = Path(filename)
    if not path.is_file() or path.stat().st_size == 0:
        raise SystemExit('MISSING OR EMPTY: ' + filename)
print('RM11 AutoCore v2.4.2: structure OK (not an APK runtime test).')
