# CarX Native Foundation v6 — فحص UnityFS الحقيقي داخل APK

**APK أصلي بمعمارية arm64-v8a (بدون Wine/FEX/QEMU)، لكنه اختبار للمحرك وليس بورت CarX Street المكتمل.**

## إنجازات v5 المؤكدة على REDMAGIC 11 Pro
- `PASS_NATIVE_AOT_IN_APP_V3 vectors=1024`: اختبار مقطعين معزولين من مصدر GameAssembly (ليس IL2CPP كاملاً).
- `vkCreateDevice` ناجح على Adreno 840، و`vkQueuePresentKHR` ناجح: حالة FRAME_PRESENTED بإطار اختبار أزرق-أخضر 1112×715، 5 صور swapchain.
- `GameAssembly.dll` بنفس SHA256 المعتمد `3ae06c2e783f8e9aeabfe991b820df6b2eb3f760f2789710471dba6e477d4a8c`.
- لعبة CarX Street نفسها **لم تُقلع**، ولا يوجد Android Unity Player/IL2CPP مترابط ولا مورد رسومي حقيقي يُعرَض.

## ما الجديد في v6؟
- وحدة C أصلية `unityfs_directory.c` تقرأ عبر ملف Android SAF المفتوح للقراءة فقط، باستخدام `pread`، ولا تعدّل ملفات اللعبة أو تستخرجها إلى جهازك.
- تتعامل مع UnityFS الإصدارات 6،7،8؛ وملفات block-info ذات الترتيب الكبير Big Endian، ومواضعها أمام/نهاية الملف.
- دعم للبيانات غير المضغوطة وLZ4/LZ4HC على مستوى جدول المعلومات، مع فحص حدود الذاكرة وملفات الإدخال التالفة.
- تفهرس `node_count` وأول 8 أسماء CAB-* وأحجامها وعناوينها الافتراضية، وتفك **أول كتلة بيانات فقط** عند إمكان ذلك (1MiB حد أقصى)، دون استخدام أي أصول على GPU.
- تختار أول **3 ملفات .bundle** مرتبة بالاسم من `CarX Street_Data/StreamingAssets/aa/StandaloneWindows64/`، وتسجل تقريراً مستقلاً لكل ملف. لا تدّعي توافق Windows AssetBundles مع Android.
- إن كان ضغط أو حماية الملفات غير مدعومين يُسجل سبب واضح (`UNSUPPORTED_COMPRESSION` / `SPECIAL_FLAGS_UNSUPPORTED` / `BLOCK_INFO_DECODE_FAILED`) ولا تحاول فك حماية.
- اجتاز 28 اختباراً محلياً (15 بنيوياً + 13 لقارئ UnityFS بما فيها رفض حالات تالفة) وفحوص ASan/UBSan محلياً. **التشغيل على الهاتف لهذه النسخة مطلوب للتأكيد.**

## طريقة التجربة
1. نزّل APK v6 من GitHub Releases وثبّته على REDMAGIC.
2. افتحه واختر **المجلد الداخلي** الذي يحتوي `GameAssembly.dll` عبر زر اختيار المجلد.
3. اضغط **Run AOT + Vulkan GPU + file checks**. سيفحص المصدر والـGPU، ويقرأ جداول UnityFS الحقيقية لثلاث عينات.
4. زر إطار Vulkan الأزرق-الأخضر يبقى للاختبار الرسومي ويمكن إعادة تجربته.
5. اضغط **Export JSON report** واحفظ `CarX_NativeFoundation_v6_Report.json` وارفعه.

ركز على `unityfs_directory_probes`: لكل ملف حقل `status` و`nodes_sample` و`first_block` إن تمّت القراءة. نجاح `PASS_UNITYFS_DIRECTORY_DECODED` يثبت **قراءة بنية حزمة PC الأصلية**، لا تشغيل Unity ولا تحميل Mesh/Texture على Vulkan.

## ما الذي لا يزال مطلوباً للعبة؟
- Android Unity Player مناسب أو إعادة بناء محرك/Runtime متوافق.
- ربط IL2CPP كاملاً وترجمة ما يلزم من GameAssembly (حالياً قطع محدودة فقط).
- توافق/إعادة بناء موارد Windows-targeted، ومنها Shaders وTextures/AssetBundles.
- دورة مشاهد اللعبة، الفيزياء، الصوت، المدخلات، الشبكة، واستقرار التشغيل.

عدم وجود مشروع Unity الأصلي أو لاعب Android متوافق في نسخة PC المعاينة ما زال عائقاً جوهرياً. APK الاختبار لا يحقق شرط التحدي إلا بعد إثبات تشغيل نسخة PC نفسها بنظام Android أصلي.
