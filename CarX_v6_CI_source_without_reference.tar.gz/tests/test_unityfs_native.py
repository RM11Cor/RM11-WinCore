import json, pathlib, struct, subprocess, tempfile, unittest, os
BASE=pathlib.Path(__file__).resolve().parents[1]
SRC=BASE/'app/src/main/cpp/unityfs_directory.c'
CLI=BASE/'tests/unityfs_cli.c'
def b32(x):return struct.pack('>I',x)
def b64(x):return struct.pack('>Q',x)
def lz4_literals(b):
    n=len(b);prefix=bytes([(min(n,15)<<4)])
    if n>=15:
        r=n-15
        while r>=255: prefix+=b'\xff';r-=255
        prefix+=bytes([r])
    return prefix+b

def make_bundle(meta_kind=0,at_end=False,data_kind=0,overlarge_node=False,corrupt_lz4=False):
    content=b'CarX synthetic container test data only. '*7
    payload=content if data_kind==0 else lz4_literals(content)
    node_name=b'CAB-SYNTHETIC-TEST-ONLY\0'
    node_size=len(content)+1 if overlarge_node else len(content)
    meta=b'\0'*16+b32(1)+b32(len(content))+b32(len(payload))+struct.pack('>H',data_kind)+b32(1)+b64(0)+b64(node_size)+b32(4)+node_name
    compressed_meta=meta if meta_kind==0 else lz4_literals(meta)
    if corrupt_lz4: compressed_meta=b'\x00\x00\x00'
    flags=0x40|meta_kind|(0x80 if at_end else 0)
    head=b'UnityFS\0'+b32(8)+b'5.x.x\0'+b'0.0.0\0'
    unfilled=head+b64(0)+b32(len(compressed_meta))+b32(len(meta))+b32(flags)
    head=unfilled+b'\0'*((-len(unfilled))%16)
    body=head+(payload+compressed_meta if at_end else compressed_meta+payload)
    declared=len(body)
    header_end=len(unfilled)
    body=body[:len(head)] if False else body
    body=body[:len(head)] + body[len(head):]
    body=body[:len(head)] if False else body
    offset=len(b'UnityFS\0')+4+len(b'5.x.x\0')+len(b'0.0.0\0')
    return body[:offset]+b64(declared)+body[offset+8:]
class NativeBundleTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='carx_unityfs_v6_test_')
        cls.exe=pathlib.Path(cls.tmp.name)/'unityfs_cli'
        subprocess.run(['cc','-O1','-std=c11','-Wall','-Wextra','-Werror','-fstack-protector-strong',str(CLI),str(SRC),'-o',str(cls.exe)],check=True)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def inspect(self,blob):
        p=pathlib.Path(self.tmp.name)/'fixture.bundle';p.write_bytes(blob)
        proc=subprocess.run([str(self.exe),str(p)],capture_output=True,text=True,check=True)
        return json.loads(proc.stdout)
    def test_raw_inline(self):
        r=self.inspect(make_bundle());self.assertEqual(r['status'],'PASS_UNITYFS_DIRECTORY_DECODED')
        self.assertEqual(r['node_count'],1);self.assertTrue(r['first_block']['decoded'])
        self.assertEqual(r['nodes_sample'][0]['name'],'CAB-SYNTHETIC-TEST-ONLY')
    def test_raw_at_end(self):
        r=self.inspect(make_bundle(at_end=True));self.assertEqual(r['status'],'PASS_UNITYFS_DIRECTORY_DECODED')
        self.assertTrue(r['block_info_at_end']);self.assertTrue(r['first_block']['decoded'])
    def test_lz4_info_inline(self):
        r=self.inspect(make_bundle(meta_kind=2));self.assertEqual(r['status'],'PASS_UNITYFS_DIRECTORY_DECODED');self.assertEqual(r['info_compression'],2)
    def test_lz4hc_info_at_end(self):
        r=self.inspect(make_bundle(meta_kind=3,at_end=True));self.assertEqual(r['status'],'PASS_UNITYFS_DIRECTORY_DECODED')
    def test_lz4_data(self):
        r=self.inspect(make_bundle(meta_kind=3,data_kind=2,at_end=True));self.assertEqual(r['status'],'PASS_UNITYFS_DIRECTORY_DECODED');self.assertTrue(r['first_block']['decoded']);self.assertEqual(r['first_block']['compression'],2)
    def test_bad_lz4(self):
        r=self.inspect(make_bundle(meta_kind=2,corrupt_lz4=True));self.assertEqual(r['status'],'BLOCK_INFO_DECODE_FAILED')
    def test_node_virtual_bounds(self):
        r=self.inspect(make_bundle(overlarge_node=True));self.assertEqual(r['status'],'BLOCK_INFO_INVALID')
    def test_truncated(self):
        r=self.inspect(make_bundle()[:-7]);self.assertEqual(r['status'],'INVALID_BOUNDS')
    def test_bad_magic(self):
        r=self.inspect(b'garbage'+make_bundle()[7:]);self.assertEqual(r['status'],'NOT_UNITYFS')
    def test_unsupported_info_compression(self):
        v=bytearray(make_bundle());offset=8+4+6+6+8+4+4;v[offset+3]=0x41
        r=self.inspect(bytes(v));self.assertEqual(r['status'],'UNSUPPORTED_COMPRESSION')
    def test_special_flags(self):
        v=bytearray(make_bundle());offset=8+4+6+6+8+4+4;v[offset+2]=0x04
        r=self.inspect(bytes(v));self.assertEqual(r['status'],'SPECIAL_FLAGS_UNSUPPORTED')
    def test_untrusted_invalid_block_count(self):
        v=bytearray(make_bundle());start=48;v[start+16:start+20]=b'\xff\xff\xff\xff'
        r=self.inspect(bytes(v));self.assertEqual(r['status'],'BLOCK_INFO_INVALID')
    def test_untrusted_bad_node_count(self):
        v=bytearray(make_bundle());start=48;v[start+30:start+34]=b'\xff\xff\xff\xff'
        r=self.inspect(bytes(v));self.assertEqual(r['status'],'BLOCK_INFO_INVALID')
if __name__=='__main__':unittest.main(verbosity=2)
