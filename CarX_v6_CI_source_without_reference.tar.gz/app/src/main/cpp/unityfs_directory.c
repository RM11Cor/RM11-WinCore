/* CarX Native Foundation v6: read-only, bounded UnityFS v6-v8 container metadata.
 * Neither an Android Unity player nor a proof of Android AssetBundle compatibility.
 * Independently authored using public UnityFS format documentation. */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#define MAX_INFO_COMPRESSED (2u*1024u*1024u)
#define MAX_INFO_UNCOMPRESSED (8u*1024u*1024u)
#define MAX_SAMPLE_BLOCK (1024u*1024u)
#define MAX_BLOCK_COUNT 131072u
#define MAX_DIRECTORY_COUNT 8192u

typedef struct {char* buf; size_t cap, used; bool overflow;} Builder;
static void append(Builder* b,const char* fmt,...){
  if(b->overflow)return;
  if(b->used>=b->cap){b->overflow=true;return;}
  va_list va; va_start(va,fmt);
  int n=vsnprintf(b->buf+b->used,b->cap-b->used,fmt,va);
  va_end(va);
  if(n<0 || (size_t)n>=b->cap-b->used){b->overflow=true;return;}
  b->used+=(size_t)n;
}
static void append_escaped(Builder* b,const uint8_t* p,size_t n){
  append(b,"\"");
  for(size_t i=0;i<n;i++){
    unsigned c=p[i];
    if(c=='"'||c=='\\')append(b,"\\%c",(char)c);
    else if(c>=32&&c<127)append(b,"%c",(char)c);
    else append(b,"\\u%04x",c);
  }
  append(b,"\"");
}
static uint32_t be32(const uint8_t* p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint16_t be16(const uint8_t* p){return (uint16_t)(((uint16_t)p[0]<<8)|p[1]);}
static uint64_t be64(const uint8_t* p){return ((uint64_t)be32(p)<<32)|be32(p+4);}
static bool sum64(uint64_t a,uint64_t b,uint64_t* out){if(a>UINT64_MAX-b)return false;*out=a+b;return true;}
static bool align16(uint64_t n,uint64_t* out){if(n>UINT64_MAX-15)return false;*out=(n+15)&~UINT64_C(15);return true;}
static bool exact_read(int fd,uint64_t offset,void* buf,size_t count,uint64_t file_bytes){
  if(offset>file_bytes || count>file_bytes-offset || offset>(uint64_t)INT64_MAX)return false;
  size_t done=0;
  while(done<count){
    if(offset+done>(uint64_t)INT64_MAX)return false;
    ssize_t n=pread(fd,(uint8_t*)buf+done,count-done,(off_t)(offset+done));
    if(n<0 && errno==EINTR)continue;
    if(n<=0)return false;
    done+=(size_t)n;
  }
  return true;
}
static bool cstring(const uint8_t* data,size_t length,size_t* cursor,const uint8_t** string,size_t* bytes,size_t max){
  if(*cursor>=length)return false;
  size_t pos=*cursor;
  while(pos<length && pos-*cursor<max && data[pos]!=0)pos++;
  if(pos>=length || data[pos]!=0)return false;
  *string=data+*cursor; *bytes=pos-*cursor; *cursor=pos+1;
  return true;
}
/* Raw LZ4 block decoder (not frame format), allows overlapping backreferences. */
static bool lz4_decode(const uint8_t* in,size_t in_size,uint8_t* out,size_t out_size){
  size_t i=0,o=0;
  while(i<in_size){
    uint8_t token=in[i++];
    size_t literal=(token>>4)&15u;
    if(literal==15){uint8_t extension;do{if(i>=in_size || literal>out_size)return false;extension=in[i++];if(literal>SIZE_MAX-extension)return false;literal+=extension;}while(extension==255);}
    if(literal>in_size-i || literal>out_size-o)return false;
    memcpy(out+o,in+i,literal); i+=literal; o+=literal;
    if(i==in_size)return o==out_size;
    if(in_size-i<2)return false;
    size_t offset=(size_t)in[i]|((size_t)in[i+1]<<8);i+=2;
    if(offset==0 || offset>o)return false;
    size_t length=(token&15u);
    if(length==15){uint8_t extension;do{if(i>=in_size || length>out_size)return false;extension=in[i++];if(length>SIZE_MAX-extension)return false;length+=extension;}while(extension==255);}
    if(length>SIZE_MAX-4)return false;
    length+=4;
    if(length>out_size-o)return false;
    for(size_t k=0;k<length;k++)out[o+k]=out[o+k-offset];
    o+=length;
  }
  return o==out_size;
}
static bool uncompress_block(unsigned kind,const uint8_t* in,size_t in_size,uint8_t* out,size_t out_size){
  if(kind==0){if(in_size!=out_size)return false;memcpy(out,in,in_size);return true;}
  if(kind==2||kind==3)return lz4_decode(in,in_size,out,out_size);
  return false;
}
static void make_failure(char* out,size_t cap,const char* status,const char* reason){
  if(cap==0)return;
  snprintf(out,cap,"{\"schema\":\"carx.unityfs.bounded-directory.v6\",\"status\":\"%s\",\"reason\":\"%s\",\"game_rendered\":false,\"android_asset_compatibility_proven\":false}",status,reason);
}
void carx_inspect_unityfs_fd(int fd,uint64_t file_size,char* out,size_t cap){
  if(!out||cap<1024)return;
  out[0]=0;
  if(fd<0||file_size<64){make_failure(out,cap,"INVALID_INPUT","file too small or invalid fd");return;}
  uint8_t header[512];size_t hlen=file_size<sizeof header?(size_t)file_size:sizeof header;
  if(!exact_read(fd,0,header,hlen,file_size)){make_failure(out,cap,"READ_FAILED","cannot seek to header");return;}
  if(memcmp(header,"UnityFS\0",8)!=0){make_failure(out,cap,"NOT_UNITYFS","signature mismatch");return;}
  uint32_t version=be32(header+8);
  if(version<6||version>8){make_failure(out,cap,"UNSUPPORTED_VERSION","only UnityFS 6-8");return;}
  size_t p=12;const uint8_t *player,*engine;size_t playerlen=0,enginelen=0;
  if(!cstring(header,hlen,&p,&player,&playerlen,96)||!cstring(header,hlen,&p,&engine,&enginelen,96)||hlen-p<20){
    make_failure(out,cap,"BAD_HEADER","invalid UnityFS strings or dimensions");return;
  }
  uint64_t declared=be64(header+p);p+=8;
  uint32_t csize=be32(header+p);p+=4;
  uint32_t usize=be32(header+p);p+=4;
  uint32_t flags=be32(header+p);p+=4;
  if(declared<64||declared>file_size || csize==0 || csize>MAX_INFO_COMPRESSED || usize<20 || usize>MAX_INFO_UNCOMPRESSED){
    make_failure(out,cap,"INVALID_BOUNDS","invalid bundle length or metadata size cap");return;
  }
  if((flags&0x1400u)!=0){make_failure(out,cap,"SPECIAL_FLAGS_UNSUPPORTED","nonstandard or encryption flags");return;}
  unsigned info_kind=flags&63u;
  if(info_kind!=0&&info_kind!=2&&info_kind!=3){make_failure(out,cap,"UNSUPPORTED_COMPRESSION","metadata requires unsupported compression");return;}
  uint64_t aligned_header=0;
  if(!align16((uint64_t)p,&aligned_header)){make_failure(out,cap,"INVALID_HEADER","alignment overflow");return;}
  bool at_end=(flags&0x80u)!=0;
  uint64_t info_offset=at_end?declared-csize:aligned_header;
  uint64_t data_offset=at_end?aligned_header:0;
  if(!at_end&&!sum64(info_offset,csize,&data_offset)){
    make_failure(out,cap,"INVALID_BOUNDS","info offset overflow");return;
  }
  if((flags&0x200u)!=0){
    uint64_t a=0;if(!align16(data_offset,&a)){make_failure(out,cap,"INVALID_BOUNDS","data align overflow");return;}data_offset=a;
  }
  if((at_end && csize>declared) || info_offset>declared || csize>declared-info_offset || data_offset>declared || (at_end&&data_offset>info_offset)){
    make_failure(out,cap,"INVALID_BOUNDS","metadata or content out of file");return;
  }
  uint8_t* cinfo=(uint8_t*)malloc(csize),*info=(uint8_t*)malloc(usize);
  if(!cinfo||!info){free(cinfo);free(info);make_failure(out,cap,"OOM","metadata allocation");return;}
  if(!exact_read(fd,info_offset,cinfo,csize,file_size)||!uncompress_block(info_kind,cinfo,csize,info,usize)){
    free(cinfo);free(info);make_failure(out,cap,"BLOCK_INFO_DECODE_FAILED","bad compressed metadata or unsupported protection");return;
  }
  free(cinfo);
  size_t cur=16;
  if(usize-cur<4){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","missing block count");return;}
  uint32_t block_count=be32(info+cur);cur+=4;
  if(block_count==0||block_count>MAX_BLOCK_COUNT||(size_t)block_count>(usize-cur)/10){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","invalid block table count");return;
  }
  uint64_t stored_total=0,virtual_total=0;
  uint32_t first_u=0,first_c=0,first_flags=0;
  for(uint32_t i=0;i<block_count;i++){
    uint32_t u=be32(info+cur),c=be32(info+cur+4);uint16_t f=be16(info+cur+8);cur+=10;
    if(i==0){first_u=u;first_c=c;first_flags=f;}
    if(c==0||u==0||!sum64(stored_total,c,&stored_total)||!sum64(virtual_total,u,&virtual_total)){
      free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","zero or oversized chunk");return;
    }
  }
  uint64_t data_end=at_end?info_offset:declared;
  if(data_offset>data_end || stored_total>data_end-data_offset){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","chunk range beyond file data");return;
  }
  if(usize-cur<4){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","missing node count");return;}
  uint32_t node_count=be32(info+cur);cur+=4;
  if(node_count>MAX_DIRECTORY_COUNT||(size_t)node_count>(usize-cur)/21){
    free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","invalid directory count");return;
  }
  Builder outb={out,cap,0,false};
  append(&outb,"{\"schema\":\"carx.unityfs.bounded-directory.v6\",\"status\":\"PASS_UNITYFS_DIRECTORY_DECODED\",\"format_version\":%u,\"player_version\":",version);
  append_escaped(&outb,player,playerlen);
  append(&outb,",\"engine_version\":");append_escaped(&outb,engine,enginelen);
  append(&outb,",\"bundle_bytes\":%" PRIu64 ",\"declared_bytes\":%" PRIu64 ",\"flags\":%u,\"block_info_at_end\":%s,\"info_compression\":%u,\"block_count\":%u,\"virtual_data_bytes\":%" PRIu64 ",\"node_count\":%u,\"nodes_sample\":[",file_size,declared,flags,at_end?"true":"false",info_kind,block_count,virtual_total,node_count);
  bool valid=true;
  for(uint32_t i=0;i<node_count;i++){
    if(usize-cur<20){valid=false;break;}
    uint64_t virtual_offset=be64(info+cur),length=be64(info+cur+8);
    uint32_t node_flags=be32(info+cur+16);cur+=20;
    const uint8_t* name;size_t name_len;
    if(!cstring(info,usize,&cur,&name,&name_len,256)||virtual_offset>virtual_total||length>virtual_total-virtual_offset){valid=false;break;}
    if(i<8){if(i)append(&outb,",");append(&outb,"{\"name\":");append_escaped(&outb,name,name_len);
      append(&outb,",\"offset\":%" PRIu64 ",\"length\":%" PRIu64 ",\"flags\":%u}",virtual_offset,length,node_flags);}
  }
  if(!valid||outb.overflow){free(info);make_failure(out,cap,"BLOCK_INFO_INVALID","node bounds or output cap");return;}
  append(&outb,"],\"first_block\":{");
  if(first_c<=MAX_SAMPLE_BLOCK&&first_u<=MAX_SAMPLE_BLOCK&&((first_flags&63u)==0||(first_flags&63u)==2||(first_flags&63u)==3)){
    uint8_t* cin=(uint8_t*)malloc(first_c),*decoded=(uint8_t*)malloc(first_u);
    if(cin&&decoded&&exact_read(fd,data_offset,cin,first_c,file_size)&&uncompress_block(first_flags&63u,cin,first_c,decoded,first_u)){
      uint64_t hash=UINT64_C(14695981039346656037);
      for(uint32_t i=0;i<first_u;i++){hash^=decoded[i];hash*=UINT64_C(1099511628211);}
      append(&outb,"\"decoded\":true,\"bytes\":%u,\"compression\":%u,\"fnv64\":\"%016" PRIx64 "\"",first_u,first_flags&63u,hash);
      if(first_u>=20){
        uint32_t metadata_size=be32(decoded+0),embedded_file_size=be32(decoded+4),serialized_version=be32(decoded+8),data_start=be32(decoded+12);
        bool plausible=metadata_size>=16 && serialized_version>=5 && serialized_version<=50 && data_start>=metadata_size && embedded_file_size>=data_start;
        append(&outb,",\"possible_serialized_file_header\":%s",plausible?"true":"false");
        if(plausible)append(&outb,",\"serialized_file_version\":%u",serialized_version);
      }
    } else append(&outb,"\"decoded\":false,\"reason\":\"first block read/decompress failed\"");
    free(cin);free(decoded);
  }else append(&outb,"\"decoded\":false,\"reason\":\"first block exceeds cap or unsupported compression\"");
  append(&outb,"},\"read_only\":true,\"android_asset_compatibility_proven\":false,\"unity_integrated\":false,\"game_rendered\":false}");
  free(info);
  if(outb.overflow)make_failure(out,cap,"OUTPUT_TOO_LARGE","output capacity exhausted");
}
