#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
sha_expected="${CARX_REFERENCE_SHA:-7d4eb4eb338d4fe3d7d5a29146b4dd248bb893b42a33b4a7461f9fdf0b6125ad}"
sha_actual="$(sha256sum app/src/main/assets/x86_reference_v2100.txt | cut -d' ' -f1)"
[ "$sha_actual" = "$sha_expected" ] || { echo 'FAIL: original source reference mismatch';exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cc -O2 -std=c11 -Wall -Wextra -Werror -Iapp/src/main/cpp \
 app/src/main/cpp/carx_core.c tests/host_fallback.c tests/host_cli.c -o "$TMP/carx_host"
"$TMP/carx_host" app/src/main/assets/x86_reference_v2100.txt
python3 -m unittest discover -s tests -p "test_*.py" -v
cc -O2 -std=c11 -Wall -Wextra -Werror tests/unityfs_cli.c app/src/main/cpp/unityfs_directory.c -o "$TMP/unityfs_probe"
printf "PASS_NATIVE_UNITYFS_INSPECTOR_COMPILED tests=13\n"

# The GPU proof is Android-only; this validates its Android-conditional source syntax
# against a test-only API skeleton. The real APK uses official NDK Vulkan headers.
clang -std=c11 -O2 -Wall -Wextra -Werror -D__ANDROID__ -Itests/vulkan_mock \
  -fsyntax-only app/src/main/cpp/vulkan_gpu_probe.c
printf 'PASS_VULKAN_ANDROID_PATH_SYNTAX_USING_TEST_ONLY_HEADER\n'
clang --target=aarch64-linux-gnu -c app/src/main/cpp/carx_prefix_a.S -o "$TMP/aarch64a.o"
clang --target=aarch64-linux-gnu -c app/src/main/cpp/carx_prefix_b.S -o "$TMP/aarch64b.o"
printf 'PASS_AARCH64_OBJECTS_COMPILED count=2\n'
