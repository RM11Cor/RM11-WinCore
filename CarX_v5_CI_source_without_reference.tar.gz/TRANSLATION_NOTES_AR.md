# Native Foundation v5 — الحدود والتغطية

- مرجع x86 الأصلي ما زال نفس 1,024 متجه في v4، ولم نترجم دوال جديدة في هذه الحزمة.
- هدف v5 هو إثبات أن Vulkan يعمل عبر **Android Surface وSwapchain وQueuePresent**، وهي خطوة من الأساس الرسومي وليست تشغيل رسوم اللعبة.
- كل إطار اختبار يرسم لوناً واحداً عبر `vkCmdClearColorImage` بعد الانتقال إلى `VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL` ثم `VK_IMAGE_LAYOUT_PRESENT_SRC_KHR`.
- يتطلب دعم `VK_IMAGE_USAGE_TRANSFER_DST_BIT` في surface، ويختار queue يدعم GRAPHICS + present. يفشل بأمان مع تقرير المرحلة وVkResult إن لم تتوفر المتطلبات.
- يُنتج تقريراً صريحاً `game_rendered:false` و`unity_integrated:false` حتى عند نجاح العرض.
- التالي بعد إثبات العرض: تقييم Android Unity runtime / أصول Android / ربط IL2CPP؛ لن تعني زيادة عدد إطارات الاختبار أن اللعبة صارت قابلة للإقلاع.
