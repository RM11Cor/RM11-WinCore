#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
clang -O1 -std=c11 -Wall -Wextra -Werror -fPIE -pie \
  tests/source_fixture/generate_reference_x86.c tests/source_fixture/original_prefixes_x86.S -o /tmp/carx-native-v4-x86-reference
/tmp/carx-native-v4-x86-reference > app/src/main/assets/x86_reference_v2100.txt
sha256sum app/src/main/assets/x86_reference_v2100.txt
