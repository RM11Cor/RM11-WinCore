# CarX Native Foundation v5 — Vulkan Surface Gate

**هذا APK اختبار تقني لأندرويد ARM64، وليس لعبة CarX Street، ولا يحقق تحدي البورت الأصلي حتى الآن.**

النتيجة المستلمة من REDMAGIC في v4:
- نجاح 1,024 مقارنة AOT من مقاطع GameAssembly.dll الأصلية، بإطار معالج افتراضي.
- نجاح إنشاء VkInstance / VkDevice على Adreno 840 (Vulkan 1.4.295).
- تطابق SHA256 للملف GameAssembly.dll، ووجود 808 حزمة بداخل StandaloneWindows64.
- لم تُنشأ نافذة رسومية ولم يُعرض إطار لعب، ولم يُربط Android Unity Player.

الجديد في v5: إنشاء SurfaceView حقيقي، ثم VkAndroidSurfaceKHR، والتحقق من دعم queue للعرض، ثم VkSwapchainKHR، وVkCommandBuffer لتلوين صورة swapchain بلون أزرق-أخضر، ثم VkQueuePresentKHR. يتضمن التقارير تفصيلاً لكل خطوة (stage / VkResult / image acquired / present result). هذه **رسمة اختبار واحدة فقط**، لا تنفذ Shader من CarX ولا تعرض مشهدها.

## استخدام APK
1. ثبّت APK الاختباري على REDMAGIC.
2. افتح التطبيق واختر مجلد CarX Street الذي يحوي GameAssembly.dll.
3. اضغط «2. Run AOT + Vulkan GPU + file checks» للتحقق من مصدر اللعبة.
4. اضغط «3. Present Vulkan color frame» واختبر ظهور المستطيل الأزرق-الأخضر ونتيجة `frame_presented`.
5. اضغط «4. Export JSON report» واختر اسم `CarX_NativeFoundation_v5_Report.json`، ثم ارفع الملف وصورة المستطيل إن ظهر.

يظهر نجاح العرض فقط إذا كانت نتيجة VkQueuePresentKHR مساوية `VK_SUCCESS` أو `VK_SUBOPTIMAL_KHR`. لا يتم اعتبار إنشاء VkDevice أو swapchain وحده إثباتاً للصورة المعروضة. قد تتغير نتائج العرض عند إطفاء الشاشة أو تبديل التطبيق أثناء الاختبار.

## الحدود
- لا تشغيل للعبة ولا محاكي ولا Wine/FEX في هذا APK.
- AOT ما زال مقاطع محدودة، وليست دوال لعبة مكتملة.
- لا UnityPlayer Android ولا تحميل Scene أو AssetBundle على GPU.
- هذا بناء تجريبي موقّع بمفتاح Debug، وليس إصداراً نهائياً للنشر.

## البنية المصدرية
`app/src/main/cpp/vulkan_surface_frame.c` تنفيذ Vulkan المباشر. `MainActivity.java` واجهة SurfaceView ومزامنة نتيجة العرض مع تقرير JSON. `tests/test_project.py` فحوص بنيوية ضد ادعاء إنجاز اللعب وعدم استعمال طبقات توافق.

فحص الملفات للقراءة فقط، ويعمل عبر Android Storage Access Framework دون تعديل مجلد اللعبة.
