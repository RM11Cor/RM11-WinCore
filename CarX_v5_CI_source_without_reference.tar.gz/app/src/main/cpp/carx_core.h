#ifndef CARX_CORE_H
#define CARX_CORE_H
#include <stddef.h>
#include <stdint.h>
// Nonzero only when all 1,024 verified original-x86 reference rows match.
int carx_run_differential(const unsigned char* bytes, size_t n, char* out, size_t cap);
void carx_probe_unityfs(const unsigned char* data, size_t n, char* out, size_t cap);
void carx_probe_pe(const unsigned char* data, size_t n, char* out, size_t cap);
#endif
