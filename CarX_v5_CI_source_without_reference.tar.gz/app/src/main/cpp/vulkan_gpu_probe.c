/* CarX Native Foundation v4: Android Vulkan physical-device bring-up.
 * This is a real Android Vulkan instance/device probe, NOT CarX rendering.
 * No shader, window, swapchain, game scene or Unity runtime is created.
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <stdlib.h>
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
#endif

void carx_probe_gpu(char *out, size_t cap) {
  if (!out || cap < 128) return;
#if !defined(__ANDROID__)
  (void)snprintf(out, cap,
    "{\"platform\":\"host\",\"gpu_proven\":false,\"device_created\":false,\"game_rendered\":false}");
#else
  void *library = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
  if (!library) {
    snprintf(out, cap, "{\"platform\":\"android\",\"loader_found\":false,\"gpu_proven\":false,\"device_created\":false,\"game_rendered\":false}");
    return;
  }
  PFN_vkGetInstanceProcAddr get_proc = (PFN_vkGetInstanceProcAddr)dlsym(library, "vkGetInstanceProcAddr");
  if (!get_proc) {
    snprintf(out, cap, "{\"platform\":\"android\",\"loader_found\":true,\"error\":\"no_vkGetInstanceProcAddr\",\"gpu_proven\":false,\"device_created\":false,\"game_rendered\":false}");
    dlclose(library);
    return;
  }
  PFN_vkCreateInstance create_instance = (PFN_vkCreateInstance)get_proc(VK_NULL_HANDLE, "vkCreateInstance");
  if (!create_instance) {
    snprintf(out, cap, "{\"platform\":\"android\",\"loader_found\":true,\"error\":\"no_vkCreateInstance\",\"gpu_proven\":false,\"device_created\":false,\"game_rendered\":false}");
    dlclose(library);
    return;
  }
  VkApplicationInfo app = {0};
  app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
  app.pApplicationName = "CarX Native GPU Proof - NOT GAME";
  app.apiVersion = VK_API_VERSION_1_0;
  VkInstanceCreateInfo ci = {0};
  ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
  ci.pApplicationInfo = &app;
  VkInstance instance = VK_NULL_HANDLE;
  VkResult rc = create_instance(&ci, NULL, &instance);
  if (rc != VK_SUCCESS || instance == VK_NULL_HANDLE) {
    snprintf(out, cap, "{\"platform\":\"android\",\"loader_found\":true,\"create_instance_result\":%d,\"gpu_proven\":false,\"device_created\":false,\"game_rendered\":false}", (int)rc);
    dlclose(library);
    return;
  }
  PFN_vkDestroyInstance destroy_instance = (PFN_vkDestroyInstance)get_proc(instance,"vkDestroyInstance");
  PFN_vkEnumeratePhysicalDevices enumerate = (PFN_vkEnumeratePhysicalDevices)get_proc(instance, "vkEnumeratePhysicalDevices");
  PFN_vkGetPhysicalDeviceProperties properties = (PFN_vkGetPhysicalDeviceProperties)get_proc(instance, "vkGetPhysicalDeviceProperties");
  PFN_vkGetPhysicalDeviceQueueFamilyProperties queues = (PFN_vkGetPhysicalDeviceQueueFamilyProperties)get_proc(instance,"vkGetPhysicalDeviceQueueFamilyProperties");
  PFN_vkEnumerateDeviceExtensionProperties extensions = (PFN_vkEnumerateDeviceExtensionProperties)get_proc(instance,"vkEnumerateDeviceExtensionProperties");
  PFN_vkCreateDevice create_device = (PFN_vkCreateDevice)get_proc(instance,"vkCreateDevice");
  PFN_vkGetDeviceProcAddr device_proc = (PFN_vkGetDeviceProcAddr)get_proc(instance,"vkGetDeviceProcAddr");
  uint32_t physical_count = 0, queue_family = UINT32_MAX;
  VkPhysicalDevice physical = VK_NULL_HANDLE;
  VkPhysicalDeviceProperties gpu = {0};
  uint32_t graphics_queues = 0;
  int swapchain_available = 0;
  VkResult create_device_result = VK_ERROR_INITIALIZATION_FAILED;
  int device_created = 0;
  if (enumerate && properties && queues && extensions && create_device && device_proc &&
      enumerate(instance,&physical_count,NULL) == VK_SUCCESS && physical_count > 0) {
    /* Avoid unbounded allocation; target only first physical GPU. */
    uint32_t one = 1;
    VkResult physical_result=enumerate(instance,&one,&physical);
    if ((physical_result == VK_SUCCESS || physical_result == VK_INCOMPLETE) && one == 1 && physical) {
      properties(physical,&gpu);
      uint32_t qc = 0;
      queues(physical,&qc,NULL);
      if (qc > 0 && qc <= 256) {
        VkQueueFamilyProperties qps[256];
        memset(qps,0,sizeof(qps));
        queues(physical,&qc,qps);
        for (uint32_t i = 0; i < qc; ++i) {
          if (qps[i].queueCount > 0 && (qps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) {
            queue_family=i;graphics_queues=qps[i].queueCount;break;
          }
        }
      }
      uint32_t ex_count=0;
      if (extensions(physical,NULL,&ex_count,NULL)==VK_SUCCESS && ex_count>0 && ex_count<=4096) {
        /* Scan in bounded slices without allocating thousands of structs on stack. */
        VkExtensionProperties *ex = (VkExtensionProperties *)malloc(sizeof(VkExtensionProperties)*ex_count);
        if (ex) {
          uint32_t fetched=ex_count;
          if (extensions(physical,NULL,&fetched,ex)==VK_SUCCESS) {
            for (uint32_t i=0;i<fetched;i++)
              if (strcmp(ex[i].extensionName,VK_KHR_SWAPCHAIN_EXTENSION_NAME)==0)swapchain_available=1;
          }
          free(ex);
        }
      }
      if (queue_family!=UINT32_MAX) {
        float priority=1.0f;
        VkDeviceQueueCreateInfo qci={0};
        qci.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        qci.queueFamilyIndex=queue_family;
        qci.queueCount=1;
        qci.pQueuePriorities=&priority;
        VkDeviceCreateInfo dci={0};
        dci.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
        dci.queueCreateInfoCount=1;
        dci.pQueueCreateInfos=&qci;
        VkDevice device=VK_NULL_HANDLE;
        create_device_result=create_device(physical,&dci,NULL,&device);
        if (create_device_result==VK_SUCCESS && device) {
          device_created=1;
          PFN_vkDestroyDevice destroy_device=(PFN_vkDestroyDevice)device_proc(device,"vkDestroyDevice");
          if (destroy_device)destroy_device(device,NULL);
        }
      }
    }
  }
  char name[VK_MAX_PHYSICAL_DEVICE_NAME_SIZE];
  size_t j=0;
  for (size_t i=0; i<sizeof(gpu.deviceName) && gpu.deviceName[i] && j+1<sizeof(name); i++) {
    unsigned char c=(unsigned char)gpu.deviceName[i];
    if ((c>='a'&&c<='z') || (c>='A'&&c<='Z') || (c>='0'&&c<='9') || c==' ' || c=='-' || c=='_' || c=='.')name[j++]=(char)c;
  }
  name[j]=0;
  snprintf(out,cap,
    "{\"platform\":\"android\",\"loader_found\":true,\"create_instance_result\":%d,\"physical_devices\":%u,\"gpu_name\":\"%s\",\"vendor_id\":%u,\"device_id\":%u,\"gpu_vulkan_api\":\"%u.%u.%u\",\"graphics_queue_family\":%d,\"graphics_queue_count\":%u,\"swapchain_extension\":%s,\"create_device_result\":%d,\"device_created\":%s,\"gpu_proven\":%s,\"game_rendered\":false}",
    (int)rc,physical_count,name,gpu.vendorID,gpu.deviceID,
    VK_API_VERSION_MAJOR(gpu.apiVersion),VK_API_VERSION_MINOR(gpu.apiVersion),VK_API_VERSION_PATCH(gpu.apiVersion),
    queue_family==UINT32_MAX?-1:(int)queue_family,graphics_queues,swapchain_available?"true":"false",
    (int)create_device_result,device_created?"true":"false",physical!=VK_NULL_HANDLE?"true":"false");
  if (destroy_instance)destroy_instance(instance,NULL);
  dlclose(library);
#endif
}
