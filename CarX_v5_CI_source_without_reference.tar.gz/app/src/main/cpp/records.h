#ifndef CARX_RECORDS_H
#define CARX_RECORDS_H
#include <stdint.h>
typedef struct {
 uint64_t rax, rcx, rdx, r8, rbx, rsp, start_rsp, rflags, stack_pushed_rbx;
} Record;
_Static_assert(sizeof(Record)==72,"record ABI");
#endif
