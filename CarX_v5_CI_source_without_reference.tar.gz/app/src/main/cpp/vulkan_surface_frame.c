/* CarX Native Foundation v5 — Vulkan Android Surface / swapchain color frame.
 * Technical proof of Android window presentation ONLY; no Unity or CarX rendering.
 * Single bounded frame, synchronous within a Java-owned worker thread, no global state.
 */
#define VK_USE_PLATFORM_ANDROID_KHR 1
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>
#include <android/native_window_jni.h>
#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void status_json(char *out, size_t cap, const char *stage, int32_t vk_result,
                        int surface_ok, int swap_ok, int acquired, int presented,
                        uint32_t width, uint32_t height, uint32_t images,
                        int64_t format, int present_result) {
  snprintf(out,cap,
    "{\"schema\":\"carx.native-vulkan-surface.v5\",\"stage\":\"%s\",\"vk_result\":%d,"
    "\"android_surface_created\":%s,\"vulkan_swapchain_created\":%s,"
    "\"image_acquired\":%s,\"frame_presented\":%s,\"frame_type\":\"SOLID_TEAL_TEST_ONLY\","
    "\"extent_width\":%u,\"extent_height\":%u,\"swapchain_images\":%u,\"vk_format\":%lld,"
    "\"queue_present_result\":%d,\"game_rendered\":false,\"unity_integrated\":false}",
    stage,(int)vk_result,surface_ok?"true":"false",swap_ok?"true":"false",
    acquired?"true":"false",presented?"true":"false",width,height,images,(long long)format,present_result);
}

void carx_present_test_surface(JNIEnv *env, jobject java_surface, char *out, size_t cap) {
  if(!out || cap<400) return;
  int surface_ok=0,swap_ok=0,acquired=0,presented=0,queue_present_result=-999;
  VkResult rc=VK_ERROR_INITIALIZATION_FAILED;
  const char *stage="start";
  uint32_t width=0,height=0,images=0;
  int64_t format=0;
  ANativeWindow *window=NULL;
  VkInstance instance=VK_NULL_HANDLE;
  VkSurfaceKHR surface=VK_NULL_HANDLE;
  VkDevice device=VK_NULL_HANDLE;
  VkSwapchainKHR swapchain=VK_NULL_HANDLE;
  VkCommandPool pool=VK_NULL_HANDLE;
  VkCommandBuffer cmd=VK_NULL_HANDLE;
  VkSemaphore image_available=VK_NULL_HANDLE,render_done=VK_NULL_HANDLE;
  VkFence fence=VK_NULL_HANDLE;
  VkPhysicalDevice physical=VK_NULL_HANDLE;
  uint32_t queue_family=UINT32_MAX;
  VkQueue queue=VK_NULL_HANDLE;
  uint32_t image_index=0;
  if (!java_surface) { stage="no_surface"; goto done; }
  window=ANativeWindow_fromSurface(env, java_surface);
  if(!window){stage="no_native_window";goto done;}
  width=(uint32_t)ANativeWindow_getWidth(window);
  height=(uint32_t)ANativeWindow_getHeight(window);
  if(width==0 || height==0){stage="surface_extent_zero";goto done;}
  stage="instance";
  const char *inst_ext[]={VK_KHR_SURFACE_EXTENSION_NAME,VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
  VkApplicationInfo app={0};app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;
  app.pApplicationName="CarX Native Vulkan Surface TEST not game";
  app.apiVersion=VK_API_VERSION_1_0;
  VkInstanceCreateInfo ici={0};ici.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
  ici.pApplicationInfo=&app;ici.enabledExtensionCount=2;ici.ppEnabledExtensionNames=inst_ext;
  rc=vkCreateInstance(&ici,NULL,&instance);
  if(rc!=VK_SUCCESS)goto done;
  stage="android_surface";
  VkAndroidSurfaceCreateInfoKHR asci={0};asci.sType=VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
  asci.window=window;
  rc=vkCreateAndroidSurfaceKHR(instance,&asci,NULL,&surface);
  if(rc!=VK_SUCCESS)goto done;
  surface_ok=1;
  stage="physical_device";
  uint32_t count=0;
  rc=vkEnumeratePhysicalDevices(instance,&count,NULL);
  if(rc!=VK_SUCCESS || count==0 || count>32)goto done;
  VkPhysicalDevice devices[32]={0};
  rc=vkEnumeratePhysicalDevices(instance,&count,devices);
  if(rc!=VK_SUCCESS && rc!=VK_INCOMPLETE)goto done;
  stage="present_graphics_queue";
  for(uint32_t d=0;d<count && queue_family==UINT32_MAX;d++){
    uint32_t qc=0;vkGetPhysicalDeviceQueueFamilyProperties(devices[d],&qc,NULL);
    if(qc==0 || qc>256)continue;
    VkQueueFamilyProperties qs[256];memset(qs,0,sizeof qs);
    vkGetPhysicalDeviceQueueFamilyProperties(devices[d],&qc,qs);
    for(uint32_t q=0;q<qc;q++){
      if(qs[q].queueCount==0 || !(qs[q].queueFlags & VK_QUEUE_GRAPHICS_BIT))continue;
      VkBool32 can_present=VK_FALSE;
      rc=vkGetPhysicalDeviceSurfaceSupportKHR(devices[d],q,surface,&can_present);
      if(rc==VK_SUCCESS && can_present){ physical=devices[d];queue_family=q;break; }
    }
  }
  if(queue_family==UINT32_MAX) {rc=VK_ERROR_FEATURE_NOT_PRESENT;goto done;}
  stage="device_with_swapchain";
  float priority=1.0f;
  VkDeviceQueueCreateInfo qci={0};qci.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
  qci.queueFamilyIndex=queue_family;qci.queueCount=1;qci.pQueuePriorities=&priority;
  const char *dev_ext[]={VK_KHR_SWAPCHAIN_EXTENSION_NAME};
  VkDeviceCreateInfo dci={0};dci.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
  dci.queueCreateInfoCount=1;dci.pQueueCreateInfos=&qci;
  dci.enabledExtensionCount=1;dci.ppEnabledExtensionNames=dev_ext;
  rc=vkCreateDevice(physical,&dci,NULL,&device);
  if(rc!=VK_SUCCESS)goto done;
  vkGetDeviceQueue(device,queue_family,0,&queue);
  stage="surface_capabilities";
  VkSurfaceCapabilitiesKHR caps={0};
  rc=vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physical,surface,&caps);
  if(rc!=VK_SUCCESS)goto done;
  uint32_t fc=0;
  rc=vkGetPhysicalDeviceSurfaceFormatsKHR(physical,surface,&fc,NULL);
  if(rc!=VK_SUCCESS || fc==0 || fc>256)goto done;
  VkSurfaceFormatKHR *fmts=calloc(fc,sizeof *fmts);
  if(!fmts){rc=VK_ERROR_OUT_OF_HOST_MEMORY;stage="surface_formats_alloc";goto done;}
  rc=vkGetPhysicalDeviceSurfaceFormatsKHR(physical,surface,&fc,fmts);
  if(rc!=VK_SUCCESS){free(fmts);goto done;}
  VkSurfaceFormatKHR selected=fmts[0];
  for(uint32_t i=0;i<fc;i++){
    if(fmts[i].colorSpace==VK_COLOR_SPACE_SRGB_NONLINEAR_KHR &&
      (fmts[i].format==VK_FORMAT_R8G8B8A8_UNORM || fmts[i].format==VK_FORMAT_B8G8R8A8_UNORM)){
      selected=fmts[i];break;
    }
  }
  free(fmts);format=(int64_t)selected.format;
  stage="surface_extent";
  VkExtent2D extent=caps.currentExtent;
  if(extent.width==UINT32_MAX){
    extent.width=width;extent.height=height;
    if(extent.width<caps.minImageExtent.width)extent.width=caps.minImageExtent.width;
    if(extent.width>caps.maxImageExtent.width)extent.width=caps.maxImageExtent.width;
    if(extent.height<caps.minImageExtent.height)extent.height=caps.minImageExtent.height;
    if(extent.height>caps.maxImageExtent.height)extent.height=caps.maxImageExtent.height;
  }
  width=extent.width;height=extent.height;
  if(width==0 || height==0){rc=VK_ERROR_INITIALIZATION_FAILED;goto done;}
  /* A frame cleared via vkCmdClearColorImage needs TRANSFER_DST support. */
  if(!(caps.supportedUsageFlags & VK_IMAGE_USAGE_TRANSFER_DST_BIT)){
    rc=VK_ERROR_FORMAT_NOT_SUPPORTED;stage="transfer_dst_not_supported";goto done;
  }
  uint32_t min_images=caps.minImageCount+1;
  if(caps.maxImageCount && min_images>caps.maxImageCount)min_images=caps.maxImageCount;
  VkSurfaceTransformFlagBitsKHR transform=(caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
    ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
  VkCompositeAlphaFlagBitsKHR alpha=VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
  if(!(caps.supportedCompositeAlpha & alpha)){
    const VkCompositeAlphaFlagBitsKHR opts[]={VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR,
      VK_COMPOSITE_ALPHA_PRE_MULTIPLIED_BIT_KHR,VK_COMPOSITE_ALPHA_POST_MULTIPLIED_BIT_KHR};
    for(unsigned i=0;i<3;i++)if(caps.supportedCompositeAlpha & opts[i]){alpha=opts[i];break;}
  }
  stage="create_swapchain";
  VkSwapchainCreateInfoKHR sci={0};sci.sType=VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
  sci.surface=surface;sci.minImageCount=min_images;sci.imageFormat=selected.format;
  sci.imageColorSpace=selected.colorSpace;sci.imageExtent=extent;sci.imageArrayLayers=1;
  sci.imageUsage=VK_IMAGE_USAGE_TRANSFER_DST_BIT;sci.imageSharingMode=VK_SHARING_MODE_EXCLUSIVE;
  sci.preTransform=transform;sci.compositeAlpha=alpha;sci.presentMode=VK_PRESENT_MODE_FIFO_KHR;
  sci.clipped=VK_TRUE;
  rc=vkCreateSwapchainKHR(device,&sci,NULL,&swapchain);
  if(rc!=VK_SUCCESS)goto done;
  swap_ok=1;
  stage="swapchain_images";
  rc=vkGetSwapchainImagesKHR(device,swapchain,&images,NULL);
  if(rc!=VK_SUCCESS || images==0 || images>16)goto done;
  VkImage image_handles[16]={0};
  rc=vkGetSwapchainImagesKHR(device,swapchain,&images,image_handles);
  if(rc!=VK_SUCCESS && rc!=VK_INCOMPLETE)goto done;
  stage="command_pool";
  VkCommandPoolCreateInfo pci={0};pci.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
  pci.queueFamilyIndex=queue_family;
  rc=vkCreateCommandPool(device,&pci,NULL,&pool);
  if(rc!=VK_SUCCESS)goto done;
  VkCommandBufferAllocateInfo cai={0};cai.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
  cai.commandPool=pool;cai.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;cai.commandBufferCount=1;
  rc=vkAllocateCommandBuffers(device,&cai,&cmd);
  if(rc!=VK_SUCCESS)goto done;
  stage="synchronization";
  VkSemaphoreCreateInfo sem_ci={0};sem_ci.sType=VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
  rc=vkCreateSemaphore(device,&sem_ci,NULL,&image_available);
  if(rc!=VK_SUCCESS)goto done;
  rc=vkCreateSemaphore(device,&sem_ci,NULL,&render_done);
  if(rc!=VK_SUCCESS)goto done;
  VkFenceCreateInfo fci={0};fci.sType=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
  rc=vkCreateFence(device,&fci,NULL,&fence);
  if(rc!=VK_SUCCESS)goto done;
  stage="acquire_swapchain_image";
  rc=vkAcquireNextImageKHR(device,swapchain,UINT64_C(1000000000),image_available,VK_NULL_HANDLE,&image_index);
  if(rc!=VK_SUCCESS && rc!=VK_SUBOPTIMAL_KHR)goto done;
  acquired=1;
  if(image_index>=images){rc=VK_ERROR_INITIALIZATION_FAILED;goto done;}
  stage="record_clear_frame";
  VkCommandBufferBeginInfo bi={0};bi.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
  bi.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
  rc=vkBeginCommandBuffer(cmd,&bi);
  if(rc!=VK_SUCCESS)goto done;
  VkImageMemoryBarrier to_clear={0};to_clear.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
  to_clear.oldLayout=VK_IMAGE_LAYOUT_UNDEFINED;
  to_clear.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
  to_clear.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
  to_clear.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
  to_clear.image=image_handles[image_index];
  to_clear.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;
  to_clear.subresourceRange.levelCount=1;to_clear.subresourceRange.layerCount=1;
  to_clear.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;
  vkCmdPipelineBarrier(cmd,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,
                       0,NULL,0,NULL,1,&to_clear);
  VkClearColorValue teal={{0.03f,0.65f,0.74f,1.0f}};
  VkImageSubresourceRange clear_range={0};clear_range.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;
  clear_range.levelCount=1;clear_range.layerCount=1;
  vkCmdClearColorImage(cmd,image_handles[image_index],VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                       &teal,1,&clear_range);
  VkImageMemoryBarrier to_present={0};to_present.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
  to_present.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
  to_present.newLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
  to_present.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;
  to_present.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
  to_present.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
  to_present.image=image_handles[image_index];
  to_present.subresourceRange=clear_range;
  vkCmdPipelineBarrier(cmd,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,0,
                       0,NULL,0,NULL,1,&to_present);
  rc=vkEndCommandBuffer(cmd);if(rc!=VK_SUCCESS)goto done;
  stage="queue_submit";
  VkPipelineStageFlags waitstage=VK_PIPELINE_STAGE_TRANSFER_BIT;
  VkSubmitInfo submit={0};submit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;
  submit.waitSemaphoreCount=1;submit.pWaitSemaphores=&image_available;
  submit.pWaitDstStageMask=&waitstage;submit.commandBufferCount=1;submit.pCommandBuffers=&cmd;
  submit.signalSemaphoreCount=1;submit.pSignalSemaphores=&render_done;
  rc=vkQueueSubmit(queue,1,&submit,fence);if(rc!=VK_SUCCESS)goto done;
  stage="queue_present";
  VkPresentInfoKHR present={0};present.sType=VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
  present.waitSemaphoreCount=1;present.pWaitSemaphores=&render_done;
  present.swapchainCount=1;present.pSwapchains=&swapchain;present.pImageIndices=&image_index;
  rc=vkQueuePresentKHR(queue,&present);queue_present_result=(int)rc;
  if(rc==VK_SUCCESS || rc==VK_SUBOPTIMAL_KHR){presented=1;stage="FRAME_PRESENTED";}
  /* Lifetime: the report means vkQueuePresentKHR accepted the frame, not a proof of pixels on display. */
done:
  if(device){
    /* Avoid destroying in-flight semaphores/images before the queue has finished. */
    (void)vkDeviceWaitIdle(device);
    if(fence)vkDestroyFence(device,fence,NULL);
    if(render_done)vkDestroySemaphore(device,render_done,NULL);
    if(image_available)vkDestroySemaphore(device,image_available,NULL);
    if(pool)vkDestroyCommandPool(device,pool,NULL);
    if(swapchain)vkDestroySwapchainKHR(device,swapchain,NULL);
    vkDestroyDevice(device,NULL);
  }
  if(surface && instance)vkDestroySurfaceKHR(instance,surface,NULL);
  if(instance)vkDestroyInstance(instance,NULL);
  if(window)ANativeWindow_release(window);
  status_json(out,cap,stage,(int32_t)rc,surface_ok,swap_ok,acquired,presented,
              width,height,images,format,queue_present_result);
}
