#include "carx_core.h"
#include "records.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void carx_native_a_8a78c0(uint64_t rcx,uint64_t rax,uint64_t rsp,Record* out);
void carx_native_b_89b660(uint64_t rcx,uint64_t rdx,uint64_t rbx,uint64_t rax,uint64_t rsp,Record* out);

static uint64_t even_parity(uint8_t b){b^=(uint8_t)(b>>4);b^=(uint8_t)(b>>2);b^=(uint8_t)(b>>1);return (b&1u)==0;}
static uint64_t test32(uint32_t v){return (even_parity((uint8_t)v)?4:0)|(v==0?64:0)|(v&0x80000000u?128:0);}
static uint64_t sub64(uint64_t a,uint64_t b){
 uint64_t r=a-b,flags=0;
 if(a<b)flags|=1;
 if(even_parity((uint8_t)r))flags|=4;
 if((a^b^r)&16)flags|=16;
 if(r==0)flags|=64;
 if((r>>63)&1)flags|=128;
 if((((a^b)&(a^r))>>63)&1u)flags|=2048;
 return flags;
}
static int parse_row(char* p,uint64_t v[15]){
 for(int i=0;i<15;i++){
  while(*p==' '||*p=='\t')p++;
  if(*p<'0'||*p>'9')return 0;
  errno=0;char* end=0;
  unsigned long long x=strtoull(p,&end,10);
  if(end==p||errno==ERANGE)return 0;
  v[i]=(uint64_t)x;
  p=end;
 }
 while(*p==' '||*p=='\t'||*p=='\r')p++;
 return *p=='\0';
}
int carx_run_differential(const unsigned char* bytes,size_t n,char* out,size_t cap){
 if(!out||cap<128)return 0;
 if(!bytes||n>512000||n<128){snprintf(out,cap,"FAIL: bad reference length");return 0;}
 char* buf=(char*)malloc(n+1);
 if(!buf){snprintf(out,cap,"FAIL: allocation");return 0;}
 memcpy(buf,bytes,n);buf[n]=0;
 int count=0,a_count=0,b_count=0,sel0=0;
 char* p=buf;
 while(*p){
  char* line=p;char* e=strchr(p,'\n');
  if(e){*e=0;p=e+1;}else p+=strlen(p);
  if(line[0]=='#'||line[0]=='\0')continue;
  uint64_t v[15]={0};
  if(!parse_row(line,v) || count>=1024 || v[0]!=(uint64_t)(count/512) || v[1]!=(uint64_t)(count%512)){
   snprintf(out,cap,"FAIL: reference format at row %d",count);free(buf);return 0;
  }
  Record r={0};
  const uint64_t rcx=v[2],rdx=v[3],rbx=v[4],rax=v[5],start_rsp=v[12];
  const uint64_t host_rax=v[6],host_rcx=v[7],host_rdx=v[8],host_r8=v[9],host_rbx=v[10],host_rsp=v[11],host_flags=v[13],host_stack=v[14];
  if(v[0]==0){
   carx_native_a_8a78c0(rcx,rax,start_rsp,&r);
   uint32_t selector=(uint32_t)rcx>>29;
   const uint64_t mask=UINT64_C(0x8c5);
   if(r.rax!=host_rax||r.rcx!=host_rcx||r.rsp!=host_rsp||r.start_rsp!=start_rsp||(test32(selector)&mask)!=(host_flags&mask)){
    snprintf(out,cap,"FAIL: AOT block A mismatch at row %d",count);free(buf);return 0;
   }
   if(r.rcx==0)sel0++;
   a_count++;
  }else{
   carx_native_b_89b660(rcx,rdx,rbx,rax,start_rsp,&r);
   const uint64_t mask=UINT64_C(0x8d5);
   if(r.rax!=host_rax||r.rcx!=host_rcx||r.rdx!=host_rdx||r.r8!=host_r8||r.rbx!=host_rbx||r.rsp!=host_rsp||r.start_rsp!=start_rsp||r.stack_pushed_rbx!=host_stack||(sub64(start_rsp-8,80)&mask)!=(host_flags&mask)){
    snprintf(out,cap,"FAIL: AOT block B mismatch at row %d",count);free(buf);return 0;
   }
   b_count++;
  }
  count++;
 }
 free(buf);
 if(count!=1024||a_count!=512||b_count!=512||sel0!=64){
  snprintf(out,cap,"FAIL: incomplete coverage rows=%d a=%d b=%d selector_zero=%d",count,a_count,b_count,sel0);return 0;
 }
 snprintf(out,cap,"PASS_NATIVE_AOT_IN_APP_V3 vectors=1024 block_a=512 block_b=512 selector_zero=64; stop_before_untranslated_CALL_or_Jcc=1");
 return 1;
}
static int text_field(const unsigned char* d,size_t n,size_t* off,char* value,size_t cap){
 if(!d||!off||!value||cap<2||*off>=n)return 0;
 size_t k=0;
 while(*off<n && d[*off]!=0 && k+1<cap){
  unsigned char c=d[*off];
  if(c<32||c>126 || c=='"'||c=='\\')return 0;
  value[k++]=(char)c;(*off)++;
 }
 if(*off>=n||d[*off]!=0||k==0)return 0;
 (*off)++;value[k]=0;return 1;
}
void carx_probe_unityfs(const unsigned char* d,size_t n,char* out,size_t cap){
 if(!out||cap<128)return;
 if(!d||n<32||memcmp(d,"UnityFS\0",8)!=0){snprintf(out,cap,"{\"unityfs\":false,\"reason\":\"missing_unityfs_signature\"}");return;}
 uint32_t fmt=((uint32_t)d[8]<<24)|((uint32_t)d[9]<<16)|((uint32_t)d[10]<<8)|d[11];
 size_t off=12;
 char generator[80],engine[80];
 if(fmt<1||fmt>10||!text_field(d,n,&off,generator,sizeof(generator))||!text_field(d,n,&off,engine,sizeof(engine))){
  snprintf(out,cap,"{\"unityfs\":false,\"reason\":\"malformed_header\"}");return;
 }
 snprintf(out,cap,"{\"unityfs\":true,\"format_version\":%u,\"generator_version\":\"%s\",\"engine_version\":\"%s\",\"build_target_verified\":false}",fmt,generator,engine);
}
void carx_probe_pe(const unsigned char* d,size_t n,char* out,size_t cap){
 if(!out||cap<128)return;
 if(!d||n<64||d[0]!='M'||d[1]!='Z'){
  snprintf(out,cap,"{\"pe\":false}");return;
 }
 uint32_t off=(uint32_t)d[60]|((uint32_t)d[61]<<8)|((uint32_t)d[62]<<16)|((uint32_t)d[63]<<24);
 if((uint64_t)off+6>n||memcmp(d+off,"PE\0\0",4)!=0){snprintf(out,cap,"{\"pe\":false,\"reason\":\"invalid_nt_header_in_prefix\"}");return;}
 uint16_t arch=(uint16_t)d[off+4]|((uint16_t)d[off+5]<<8);
 snprintf(out,cap,"{\"pe\":true,\"machine\":\"0x%04x\",\"android_arm64_native_elf\":false}",(unsigned)arch);
}
