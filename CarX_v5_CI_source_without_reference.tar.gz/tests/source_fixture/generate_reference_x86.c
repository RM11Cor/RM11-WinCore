#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "records.h"
void carx_x86_8a78c0(uint64_t rcx,uint64_t rax,Record* out);
void carx_x86_89b660(uint64_t rcx,uint64_t rdx,uint64_t rbx,uint64_t rax,Record* out);
static uint64_t mix(uint64_t i){uint64_t x=i+UINT64_C(0x9e3779b97f4a7c15);x=(x^(x>>30))*UINT64_C(0xbf58476d1ce4e5b9);x=(x^(x>>27))*UINT64_C(0x94d049bb133111eb);return x^(x>>31);}
int main(void){
 puts("# kind index in_rcx in_rdx in_rbx seed_rax rax rcx rdx r8 rbx rsp start_rsp rflags pushed_rbx");
 for(int k=0;k<2;k++)for(int i=0;i<512;i++){
  uint64_t rcx=mix((uint64_t)i),rdx=mix((uint64_t)i+10000),rbx=mix((uint64_t)i+20000),rax=mix((uint64_t)i+30000);
  if(k==0){ // force all 8 selector values and both zero/nonzero flags
    rcx=(rcx&UINT64_C(0xffffffff00000000))|((uint64_t)(i%8)<<29)|(rcx&0x1fffffff);
  }
  Record r={0};
  if(!k)carx_x86_8a78c0(rcx,rax,&r);
  else carx_x86_89b660(rcx,rdx,rbx,rax,&r);
  printf("%d %d %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 "\n",k,i,rcx,rdx,rbx,rax,r.rax,r.rcx,r.rdx,r.r8,r.rbx,r.rsp,r.start_rsp,r.rflags,r.stack_pushed_rbx);
 }
 return 0;
}
