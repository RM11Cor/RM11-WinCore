#include "records.h"
#include <stdint.h>
void carx_native_a_8a78c0(uint64_t rcx,uint64_t rax,uint64_t rsp,Record* out){
 (void)rax;
 out->rax=((uint32_t)rcx>>1)&UINT32_C(0x0fffffff);
 out->rcx=(uint32_t)rcx>>29;
 out->rsp=rsp-88;
 out->start_rsp=rsp;
}
void carx_native_b_89b660(uint64_t rcx,uint64_t rdx,uint64_t rbx,uint64_t rax,uint64_t rsp,Record* out){
 out->rax=rax;
 out->rcx=rsp-88+48;
 out->rdx=rcx;
 out->r8=(uint32_t)rdx;
 out->rbx=rbx;
 out->rsp=rsp-88;
 out->start_rsp=rsp;
 out->stack_pushed_rbx=rbx;
}
