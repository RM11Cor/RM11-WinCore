/* TEST-ONLY API skeleton to syntax-check Android-dependent C code on Linux.
 * NOT a Vulkan runtime implementation, NOT shipped as Android native headers.
 * APK builds use the official NDK <vulkan/vulkan.h>.
 */
#ifndef CARX_VULKAN_SYNTAX_TEST_STUB
#define CARX_VULKAN_SYNTAX_TEST_STUB
#include <stdint.h>
#include <stddef.h>
#define VK_NULL_HANDLE 0
#define VK_SUCCESS 0
#define VK_INCOMPLETE 5
#define VK_ERROR_INITIALIZATION_FAILED (-3)
#define VK_MAX_PHYSICAL_DEVICE_NAME_SIZE 256
#define VK_API_VERSION_1_0 (1u<<22)
#define VK_API_VERSION_MAJOR(x) ((x)>>22)
#define VK_API_VERSION_MINOR(x) (((x)>>12)&1023u)
#define VK_API_VERSION_PATCH(x) ((x)&4095u)
#define VK_STRUCTURE_TYPE_APPLICATION_INFO 0
#define VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO 1
#define VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO 2
#define VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO 3
#define VK_QUEUE_GRAPHICS_BIT 1
#define VK_KHR_SWAPCHAIN_EXTENSION_NAME "VK_KHR_swapchain"
#define VKAPI_PTR
#define VKAPI_ATTR
typedef int32_t VkResult;
typedef struct VkInstance_T* VkInstance;
typedef struct VkPhysicalDevice_T* VkPhysicalDevice;
typedef struct VkDevice_T* VkDevice;
typedef void (*PFN_vkVoidFunction)(void);
typedef struct VkApplicationInfo {int sType;const void* pNext;const char* pApplicationName;uint32_t applicationVersion;const char* pEngineName;uint32_t engineVersion;uint32_t apiVersion;} VkApplicationInfo;
typedef struct VkInstanceCreateInfo {int sType;const void* pNext;uint32_t flags;const VkApplicationInfo* pApplicationInfo;uint32_t enabledLayerCount;const char* const* ppEnabledLayerNames;uint32_t enabledExtensionCount;const char* const* ppEnabledExtensionNames;} VkInstanceCreateInfo;
typedef struct VkPhysicalDeviceProperties {uint32_t apiVersion, driverVersion, vendorID, deviceID, deviceType;char deviceName[256];} VkPhysicalDeviceProperties;
typedef struct VkQueueFamilyProperties {uint32_t queueFlags,queueCount,timestampValidBits;uint64_t minImageTransferGranularity;} VkQueueFamilyProperties;
typedef struct VkExtensionProperties {char extensionName[256];uint32_t specVersion;} VkExtensionProperties;
typedef struct VkDeviceQueueCreateInfo {int sType;const void* pNext;uint32_t flags, queueFamilyIndex,queueCount;const float* pQueuePriorities;} VkDeviceQueueCreateInfo;
typedef struct VkDeviceCreateInfo {int sType;const void* pNext;uint32_t flags,queueCreateInfoCount;const VkDeviceQueueCreateInfo* pQueueCreateInfos;uint32_t enabledLayerCount;const char* const* ppEnabledLayerNames;uint32_t enabledExtensionCount;const char* const* ppEnabledExtensionNames;const void* pEnabledFeatures;} VkDeviceCreateInfo;
typedef PFN_vkVoidFunction (*PFN_vkGetInstanceProcAddr)(VkInstance,const char*);
typedef PFN_vkVoidFunction (*PFN_vkGetDeviceProcAddr)(VkDevice,const char*);
typedef VkResult (*PFN_vkCreateInstance)(const VkInstanceCreateInfo*,const void*,VkInstance*);
typedef void (*PFN_vkDestroyInstance)(VkInstance,const void*);
typedef VkResult (*PFN_vkEnumeratePhysicalDevices)(VkInstance,uint32_t*,VkPhysicalDevice*);
typedef void (*PFN_vkGetPhysicalDeviceProperties)(VkPhysicalDevice,VkPhysicalDeviceProperties*);
typedef void (*PFN_vkGetPhysicalDeviceQueueFamilyProperties)(VkPhysicalDevice,uint32_t*,VkQueueFamilyProperties*);
typedef VkResult (*PFN_vkEnumerateDeviceExtensionProperties)(VkPhysicalDevice,const char*,uint32_t*,VkExtensionProperties*);
typedef VkResult (*PFN_vkCreateDevice)(VkPhysicalDevice,const VkDeviceCreateInfo*,const void*,VkDevice*);
typedef void (*PFN_vkDestroyDevice)(VkDevice,const void*);
#endif
