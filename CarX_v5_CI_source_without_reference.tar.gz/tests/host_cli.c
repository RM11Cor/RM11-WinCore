#include "carx_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
static int test_headers(void){
 unsigned char good[160]={0};
 memcpy(good,"UnityFS\0",8);good[11]=6;
 memcpy(good+12,"5.x.x\0",6);
 memcpy(good+18,"2022.3.42f1\0",13);
 char out[512];
 carx_probe_unityfs(good,sizeof good,out,sizeof out);
 if(!strstr(out,"\"engine_version\":\"2022.3.42f1\"")){puts(out);return 0;}
 good[0]=0;carx_probe_unityfs(good,sizeof good,out,sizeof out);
 if(!strstr(out,"\"unityfs\":false"))return 0;
 unsigned char pe[128]={0};pe[0]='M';pe[1]='Z';pe[60]=64;
 memcpy(pe+64,"PE\0\0",4);pe[68]=0x64;pe[69]=0x86;
 carx_probe_pe(pe,sizeof pe,out,sizeof out);
 if(!strstr(out,"0x8664"))return 0;
 return 1;
}
int main(int argc,char**argv){
 if(argc!=2){fputs("Usage: native_cli x86_reference_v2100.txt\n",stderr);return 2;}
 FILE* f=fopen(argv[1],"rb");if(!f){perror("reference");return 2;}
 if(fseek(f,0,SEEK_END)!=0){fclose(f);return 2;}
 long size=ftell(f);rewind(f);if(size<1||size>512000){fclose(f);return 2;}
 unsigned char* p=malloc((size_t)size);if(!p){fclose(f);return 2;}
 int read_ok=fread(p,1,(size_t)size,f)==(size_t)size;fclose(f);
 char result[512]={0};
 int ok=read_ok&&carx_run_differential(p,(size_t)size,result,sizeof result);
 if(!ok){fprintf(stderr,"%s\n",result);free(p);return 1;}
 puts(result);
 if(!test_headers()){fputs("FAIL_HEADER_PARSING\n",stderr);free(p);return 1;}
 puts("PASS_UNITYFS_HEADER_PARSER_AND_PE_GUARD tests=3");
 // Tamper first numeric input: fail-closed comparison.
 unsigned char* q=malloc((size_t)size);
 if(!q){free(p);return 2;}
 memcpy(q,p,(size_t)size);char* hit=(char*)memchr(q,'\n',(size_t)size);
 if(!hit||hit-(char*)q+12>=size){free(q);free(p);return 2;}
 hit[4]='9';
 if(carx_run_differential(q,(size_t)size,result,sizeof result)){
  fputs("FAIL_TAMPERED_REFERENCE_ACCEPTED\n",stderr);free(q);free(p);return 1;
 }
 puts("PASS_REFERENCE_TAMPER_REJECTED cases=1");
 free(q);free(p);return 0;
}
