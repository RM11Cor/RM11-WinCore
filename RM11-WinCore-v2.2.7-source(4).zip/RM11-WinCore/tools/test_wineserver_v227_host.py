#!/usr/bin/env python3
"""V2.2.7 JVM checks. Tests link logic, NOT Android Wine or wineserver execution."""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/com/rm11/wincore/WineFirstExeV22.java'
C = ROOT / 'app/src/main/cpp/WineServerBridge.c'
assert 'RM11_WINESERVER_BRIDGE_ENTERED' in C.read_text()
assert 'execv(box,next)' in C.read_text()
with tempfile.TemporaryDirectory(prefix='rm11-server-v227-') as dir:
    t = Path(dir)
    for folder in ('android/content/res', 'android/content/pm', 'android/os', 'com/rm11/wincore'):
        (t/folder).mkdir(parents=True)
    (t/'android/content/Context.java').write_text('package android.content;import java.io.File;import android.content.res.AssetManager;import android.content.pm.ApplicationInfo;public class Context { public File getCacheDir(){return null;}public File getFilesDir(){return null;}public AssetManager getAssets(){return null;}public ApplicationInfo getApplicationInfo(){return null;}}')
    (t/'android/content/res/AssetManager.java').write_text('package android.content.res;import java.io.*;public class AssetManager {public InputStream open(String p)throws IOException{return null;}}')
    (t/'android/content/pm/ApplicationInfo.java').write_text('package android.content.pm;public class ApplicationInfo{public String nativeLibraryDir;}')
    (t/'android/os/Build.java').write_text('package android.os;public class Build{public static String[] SUPPORTED_ABIS={"arm64-v8a"};}')
    (t/'com/rm11/wincore/WineRuntimeV21.java').write_text('package com.rm11.wincore;import android.content.Context;import java.io.File;public class WineRuntimeV21 {public static void stageTo(Context c,File f){}}')
    (t/'com/rm11/wincore/WineFirstExeV227Test.java').write_text('''package com.rm11.wincore;
import java.io.File;
import java.nio.file.*;
class WineFirstExeV227Test {
  static void ok(boolean x){if(!x)throw new AssertionError();}
  public static void main(String[] argv)throws Exception{
    Path work=Path.of(argv[0]);
    Path dir=Files.createDirectory(work.resolve("wine"));
    Path nativeDir=Files.createDirectory(work.resolve("native"));
    Path helper=nativeDir.resolve("librm11wineserverbridge.so");
    Files.writeString(helper,"test-only executable");helper.toFile().setExecutable(true);
    File link=WineFirstExeV22.installWineserverEntry(dir.toFile(),helper.toFile());
    ok(Files.isSymbolicLink(link.toPath()));
    ok(Files.readSymbolicLink(link.toPath()).equals(helper.toRealPath()));
    ok(WineFirstExeV22.installWineserverEntry(dir.toFile(),helper.toFile()).equals(link));
    // A broken old link is replaced when the signing-compatible APK updates.
    Files.delete(link.toPath());Files.createSymbolicLink(link.toPath(),Path.of("/bogus/stale/helper"));
    WineFirstExeV22.installWineserverEntry(dir.toFile(),helper.toFile());
    ok(Files.readSymbolicLink(link.toPath()).equals(helper.toRealPath()));
    Files.delete(link.toPath());Files.writeString(link.toPath(),"a spoofed regular wineserver");
    try{WineFirstExeV22.installWineserverEntry(dir.toFile(),helper.toFile());throw new AssertionError("regular file accepted");}
    catch(IllegalStateException expected){ok(expected.getMessage().contains("non-link"));}
    Files.delete(link.toPath());Files.delete(helper);
    try{WineFirstExeV22.installWineserverEntry(dir.toFile(),helper.toFile());throw new AssertionError("missing helper accepted");}
    catch(IllegalStateException expected){ok(expected.getMessage().contains("helper"));}
    System.out.println("PASS V2.2.7 verified wineserver helper link; stale link refreshed; unsafe/absent helper rejected");
  }
}''')
    java = list((t/'android').rglob('*.java'))+list((t/'com').rglob('*.java'))+[SRC]
    subprocess.run(['javac','-encoding','UTF-8','-d',str(t/'classes'),*[str(x) for x in java]], check=True)
    subprocess.run(['java','-cp',str(t/'classes'),'com.rm11.wincore.WineFirstExeV227Test',str(t)], check=True)
