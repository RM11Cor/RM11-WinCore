"""Post-build APK audit for first-party ARM64 modules and standalone executable."""
import sys
from pathlib import Path
from zipfile import ZipFile

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 tools/verify_native_apk.py app-debug.apk")
apk = Path(sys.argv[1])
expected = {
    'lib/arm64-v8a/librm11probe.so',
    'lib/arm64-v8a/librm11runtime_adapter.so',
    'lib/arm64-v8a/librm11execprobe.so',
}
with ZipFile(apk) as archive:
    entries = set(archive.namelist())
    absent = expected - entries
    if absent:
        raise SystemExit("FAIL missing packaged native libs: " + ', '.join(sorted(absent)))
    data = archive.read('lib/arm64-v8a/librm11execprobe.so')
    if not data.startswith(b'\x7fELF') or data[18:20] != b'\xb7\x00':
        raise SystemExit('FAIL: standalone ARM64 PIE missing or malformed')
    import struct
    phoff = struct.unpack_from('<Q', data, 32)[0]
    phsize = struct.unpack_from('<H', data, 54)[0]
    phnum = struct.unpack_from('<H', data, 56)[0]
    if phsize < 56 or phnum > 128 or phoff + phsize*phnum > len(data):
        raise SystemExit('FAIL: executable program header out of bounds')
    if not any(struct.unpack_from('<I', data, phoff+i*phsize)[0] == 3 for i in range(phnum)):
        raise SystemExit('FAIL: Android PIE missing PT_INTERP')
    guest_path = 'assets/box64_test/hello_x86_64.elf'
    if guest_path not in entries:
        raise SystemExit('FAIL: x86-64 Linux guest ELF missing from APK assets')
    guest = archive.read(guest_path)
    if (len(guest) > 256*1024 or guest[:6] != b'\x7fELF\x02\x01' or
        guest[16:20] != b'\x02\x00\x3e\x00' or b'RM11_X86_64_GUEST_EXEC_OK' not in guest):
        raise SystemExit('FAIL: packaged x86-64 guest invalid or missing success marker')
    import struct
    phoff = struct.unpack_from('<Q', guest, 32)[0]
    phsize, phnum = struct.unpack_from('<HH', guest, 54)
    if phsize < 56 or not 1 <= phnum <= 64 or phoff + phsize*phnum > len(guest):
        raise SystemExit('FAIL: guest ELF program headers malformed')
    if any(struct.unpack_from('<I', guest, phoff + phsize*i)[0] == 3 for i in range(phnum)):
        raise SystemExit('FAIL: guest ELF unexpectedly has dynamic linker')
    print('PASS: Linux x86-64 freestanding test guest packaged as APK ASSET (not executed by Android)')
    dynamic_path = 'assets/box64_test/hello_glibc_x86_64.elf'
    if dynamic_path not in entries:
        raise SystemExit('FAIL: V1.5 glibc-linked Linux guest is missing from APK assets')
    dynamic_guest = archive.read(dynamic_path)
    if (not 64 <= len(dynamic_guest) <= 256*1024 or dynamic_guest[:6] != b'\x7fELF\x02\x01'
        or dynamic_guest[18:20] != b'\x3e\x00'
        or b'RM11_X86_64_GLIBC_DYNAMIC_OK' not in dynamic_guest
        or b'/lib64/ld-linux-x86-64.so.2' not in dynamic_guest
        or b'libc.so.6' not in dynamic_guest):
        raise SystemExit('FAIL: V1.5 dynamic guest architecture/loader/libc metadata invalid')
    print('PASS: x86-64 dynamic glibc test guest packaged as inert APK asset; Linux rootfs not included')
    maybe_box64 = 'lib/arm64-v8a/librm11box64.so'
    if maybe_box64 in entries:
        box64_data = archive.read(maybe_box64)
        if not box64_data.startswith(b'\x7fELF') or box64_data[18:20] != b'\xb7\x00':
            raise SystemExit('FAIL: experimental Box64 ELF has invalid ARM64 header')
        print('EXPERIMENTAL: upstream ARM64 Box64 appears in APK; on-device --version still required')
    else:
        print('NOT BUILT: optional experimental Box64 not packaged; official ARM64 probe still available')
print('PASS: ARM64 JNI libraries plus runnable ELF PIE packaged in APK')
