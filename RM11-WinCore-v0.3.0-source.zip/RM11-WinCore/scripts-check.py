from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parent
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
assert manifest.tag == 'manifest'
java = (root / 'app/src/main/java/com/rm11/wincore/MainActivity.java').read_text()
catalog = (root / 'app/src/main/java/com/rm11/wincore/LauncherCatalog.java').read_text()
native = (root / 'app/src/main/cpp/VulkanProbe.cpp').read_text()
for term in ('steam', 'ubisoft', 'ea', 'rockstar'):
    assert f'new Launcher("{term}"' in catalog
assert 'ACTION_OPEN_DOCUMENT' in java and 'ACTION_CREATE_DOCUMENT' in java
assert 'RuntimeGateway.currentStatusArabic()' in java
assert 'vkEnumeratePhysicalDevices' in native
assert 'ACCESS_ALL_FILES' not in str(manifest.attrib)
print('PASS: project files, manifest, official launcher IDs, Vulkan native probe and report actions present')

ready = (root / 'app/src/main/java/com/rm11/wincore/RuntimeReadiness.java').read_text()
assert 'RuntimeReadiness.inspect' in java
assert 'NOT INTEGRATED' in ready and 'NX809J' in ready
assert 'vkGetPhysicalDeviceFeatures2' in native
print('PASS: V0.2 preflight and Vulkan feature bits are present')

# V0.3 source checks: read-only PE header, private workspace, native Android subprocess.
pe=(root/'app/src/main/java/com/rm11/wincore/PeInspector.java').read_text()
boot=(root/'app/src/main/java/com/rm11/wincore/RuntimeBootstrap.java').read_text()
assert 'MAX_HEADER = 1024 * 1024' in pe and "case 0x8664" in pe
assert 'process.waitFor(8, TimeUnit.SECONDS)' in boot and 'correctDevice()' in boot
assert 'rm11-runtime' in boot and 'wine-prefix-placeholder' in boot
assert 'new Thread' in java and 'PeInspector.inspect' in java
assert 'versionName = "0.3.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: V0.3 workspace, bounded PE inspection and native subprocess source checks')
