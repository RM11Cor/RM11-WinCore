#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sstream>
#include <string>

// This is a REAL native library smoke test executed inside RM11's own process.
// It deliberately never loads third-party ELF, Wine, Box64, or a Windows executable.
extern "C" JNIEXPORT jstring JNICALL
Java_com_rm11_wincore_NativeRuntimeBridge_nativeSelfTest(JNIEnv* env, jclass) {
    std::ostringstream out;
    out << "RM11 WinCore 0.7-A / Packaged Native Runtime Smoke Test\n";
    out << "Executing JNI C++ code from RM11's own APK; NOT Windows emulation.\n\n";
#if defined(__aarch64__)
    out << "[PASS] Compiled native architecture: ARM64 (aarch64)\n";
#else
    out << "[FAIL] Compiled native architecture is NOT ARM64\n";
#endif
    const long pageSize = sysconf(_SC_PAGESIZE);
    if (pageSize > 0) out << "[PASS] Host page size: " << pageSize << " bytes\n";
    else out << "[FAIL] Cannot determine host page size\n";

    struct utsname kernel{};
    if (uname(&kernel) == 0) {
        out << "[PASS] Linux kernel machine: " << kernel.machine << "\n";
    } else {
        out << "[FAIL] uname() failed\n";
    }

    // Check that the Android Bionic linker can load a host library within this process.
    // This is NOT a glibc, Box64, or Wine test.
    void* libc = dlopen("libc.so", RTLD_NOW | RTLD_LOCAL);
    if (!libc) {
        out << "[FAIL] Bionic libc.so dlopen failed\n";
    } else {
        void* sym = dlsym(libc, "getpid");
        out << (sym ? "[PASS] Android linker resolved libc.so:getpid\n"
                    : "[FAIL] Android linker could not resolve getpid\n");
        dlclose(libc);
    }
    out << "Host process ID (PID): " << static_cast<long>(getpid()) << "\n";
    out << "\n[NOT INTEGRATED] Wine, Box64, glibc rootfs, DXVK and EXE launching are absent.\n";
    out << "[NEXT] Obtain license-compliant ARM64 runtime builds and integrate via Android-compatible packaging.\n";
    return env->NewStringUTF(out.str().c_str());
}
