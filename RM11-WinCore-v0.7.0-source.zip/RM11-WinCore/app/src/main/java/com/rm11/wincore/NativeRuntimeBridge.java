package com.rm11.wincore;

/**
 * Calls our own packaged ARM64 native library through JNI. A smoke test only:
 * not a Wine/Box64 installer and not an executable launcher.
 */
public final class NativeRuntimeBridge {
    private static final String loadIssue;
    static {
        String issue = null;
        try {
            System.loadLibrary("rm11probe");
        } catch (UnsatisfiedLinkError | SecurityException e) {
            issue = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        loadIssue = issue;
    }
    private NativeRuntimeBridge() {}
    private static native String nativeSelfTest();

    public static String inspect() {
        if (loadIssue != null) return "[FAIL] Native APK library load error: " + loadIssue;
        try {
            return nativeSelfTest();
        } catch (UnsatisfiedLinkError | SecurityException e) {
            return "[FAIL] Native JNI invocation failed: " + e.getMessage();
        } catch (Exception e) {
            return "[FAIL] Native probe error: " + e.getClass().getSimpleName();
        }
    }
}
