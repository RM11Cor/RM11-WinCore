package com.rm11.autocore;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

/** Generic metadata extraction tests. All titles are arbitrary synthetic examples. */
public class GameManifestReaderTest {
    private GameManifestReader.Result parsed(String path, String text) {
        return GameManifestReader.analyze(Collections.singletonList(new GameManifestReader.Document(path, text)));
    }
    @Test public void steamManifestContainsNameAndAppIdWithoutLicenseAssumption() {
        GameManifestReader.Result r = parsed("steamapps/appmanifest_95123.acf",
                "\"AppState\"\n{\"appid\" \"95123\"\n\"name\" \"Moonlight City\"\n\"buildid\" \"555\"}");
        assertEquals("Moonlight City",r.title);
        assertEquals("95123",r.steamAppId);
        assertTrue(r.platform.contains("لا يثبت الترخيص"));
    }
    @Test public void arbitraryUnityGameInfoCanProvideTitle() {
        assertEquals("Amber Canyons",parsed("Amber_Data/app.info","Studio\nAmber Canyons\n").title);
    }
    @Test public void epicAndGogMetadataAreRecognized() {
        assertEquals("Ocean Velocity",parsed(".egstore/12.item","{\"DisplayName\":\"Ocean Velocity\"}").title);
        assertEquals("Desert Echo",parsed("goggame-123456.info","{\"name\":\"Desert Echo\"}").title);
    }
    @Test public void unrealProjectDisplayTitleIsRead() {
        assertEquals("Northern Sky",parsed("Config/DefaultGame.ini",
                "ProjectDisplayedTitle=NSLOCTEXT(\"X\",\"Y\",\"Northern Sky\")").title);
    }
    @Test public void rejectLargeOrUnrelatedFiles() {
        assertFalse(GameManifestReader.accepts("Game/World.pak",999999));
        assertFalse(GameManifestReader.accepts("Game/random.ini",120));
        assertTrue(GameManifestReader.accepts("Game_Data/app.info",250));
    }
    @Test public void metadataTakesPriorityOverGenericExe() {
        GameDetector.Detection d=GameDetector.analyze(
                Collections.singletonList(new GameDetector.Entry("Game/Game.exe",false,9000000)),false,
                parsed("Game_Data/app.info","Studio\nReal Unknown Game Title\n"));
        assertEquals("Real Unknown Game Title",d.title);
    }
    @Test public void launchedExeSuffixDoesNotPolluteTitle() {
        GameDetector.Detection d=GameDetector.analyze(
                Collections.singletonList(new GameDetector.Entry("CarX Street Launcher.exe",false,9000000)),false);
        assertEquals("CarX Street",d.title);
    }
    @Test public void exeProductNameWithManifestConflictIsReported() {
        GameDetector.Detection d=GameDetector.analyze(
                Collections.singletonList(new GameDetector.Entry("Game.exe",false,9000000,
                        "True Product Name", "", "1.0")),false,
                parsed("steamapps/appmanifest_12345.acf","\"name\" \"Conflicting Title\""));
        assertEquals("True Product Name",d.title);
        assertTrue(String.join(" ",d.evidence).contains("تعارض"));
    }
}
