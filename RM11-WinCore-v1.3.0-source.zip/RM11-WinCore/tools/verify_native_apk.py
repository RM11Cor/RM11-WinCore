"""Post-build APK audit for first-party ARM64 modules and standalone executable."""
import sys
from pathlib import Path
from zipfile import ZipFile

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 tools/verify_native_apk.py app-debug.apk")
apk = Path(sys.argv[1])
expected = {
    'lib/arm64-v8a/librm11probe.so',
    'lib/arm64-v8a/librm11runtime_adapter.so',
    'lib/arm64-v8a/librm11execprobe.so',
}
with ZipFile(apk) as archive:
    entries = set(archive.namelist())
    absent = expected - entries
    if absent:
        raise SystemExit("FAIL missing packaged native libs: " + ', '.join(sorted(absent)))
    data = archive.read('lib/arm64-v8a/librm11execprobe.so')
    if not data.startswith(b'\x7fELF') or data[18:20] != b'\xb7\x00':
        raise SystemExit('FAIL: standalone ARM64 PIE missing or malformed')
    import struct
    phoff = struct.unpack_from('<Q', data, 32)[0]
    phsize = struct.unpack_from('<H', data, 54)[0]
    phnum = struct.unpack_from('<H', data, 56)[0]
    if phsize < 56 or phnum > 128 or phoff + phsize*phnum > len(data):
        raise SystemExit('FAIL: executable program header out of bounds')
    if not any(struct.unpack_from('<I', data, phoff+i*phsize)[0] == 3 for i in range(phnum)):
        raise SystemExit('FAIL: Android PIE missing PT_INTERP')
    maybe_box64 = 'lib/arm64-v8a/librm11box64.so'
    if maybe_box64 in entries:
        box64_data = archive.read(maybe_box64)
        if not box64_data.startswith(b'\x7fELF') or box64_data[18:20] != b'\xb7\x00':
            raise SystemExit('FAIL: experimental Box64 ELF has invalid ARM64 header')
        print('EXPERIMENTAL: upstream ARM64 Box64 appears in APK; on-device --version still required')
    else:
        print('NOT BUILT: optional experimental Box64 not packaged; official ARM64 probe still available')
print('PASS: ARM64 JNI libraries plus runnable ELF PIE packaged in APK')
