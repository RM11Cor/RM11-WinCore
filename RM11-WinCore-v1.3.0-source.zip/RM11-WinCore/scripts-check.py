from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parent
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
assert manifest.tag == 'manifest'
java = (root / 'app/src/main/java/com/rm11/wincore/MainActivity.java').read_text()
catalog = (root / 'app/src/main/java/com/rm11/wincore/LauncherCatalog.java').read_text()
native = (root / 'app/src/main/cpp/VulkanProbe.cpp').read_text()
for term in ('steam', 'ubisoft', 'ea', 'rockstar'):
    assert f'new Launcher("{term}"' in catalog
assert 'ACTION_OPEN_DOCUMENT' in java and 'ACTION_CREATE_DOCUMENT' in java
assert 'RuntimeGateway.currentStatusArabic()' in java
assert 'vkEnumeratePhysicalDevices' in native
assert 'ACCESS_ALL_FILES' not in str(manifest.attrib)
print('PASS: project files, manifest, official launcher IDs, Vulkan native probe and report actions present')

ready = (root / 'app/src/main/java/com/rm11/wincore/RuntimeReadiness.java').read_text()
assert 'RuntimeReadiness.inspect' in java
assert 'NOT INTEGRATED' in ready and 'NX809J' in ready
assert 'vkGetPhysicalDeviceFeatures2' in native
print('PASS: V0.2 preflight and Vulkan feature bits are present')

# V0.3 source checks: read-only PE header, private workspace, native Android subprocess.
pe=(root/'app/src/main/java/com/rm11/wincore/PeInspector.java').read_text()
boot=(root/'app/src/main/java/com/rm11/wincore/RuntimeBootstrap.java').read_text()
assert 'MAX_HEADER = 1024 * 1024' in pe and "case 0x8664" in pe
assert 'process.waitFor(8, TimeUnit.SECONDS)' in boot and 'correctDevice()' in boot
assert 'rm11-runtime' in boot and 'wine-prefix-placeholder' in boot
assert 'new Thread' in java and 'PeInspector.inspect' in java
assert 'versionName = "1.3.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: inherited V0.3 workspace, bounded PE inspection and native subprocess checks')

# V0.4: streaming bundle audit with bounded data and no process execution.
bundle=(root/'app/src/main/java/com/rm11/wincore/EngineBundleVerifier.java').read_text()
assert 'MAX_TOTAL' in bundle and 'MessageDigest.getInstance("SHA-256")' in bundle
assert 'ZipInputStream' in bundle and 'RuntimeBootstrap.correctDevice()' in bundle
assert 'EngineBundleVerifier.verify' in java and 'VERIFY_ENGINE_BUNDLE' in java
assert 'NOT READY' in bundle and 'does NOT' not in bundle  # status does not claim executable Wine
print('PASS: V0.4 read-only streaming runtime bundle audit and device restrictions')

# V0.5: static graphics API hints and balanced *suggestions*, no claim of runnable Windows games.
import subprocess
import tempfile
assert 'WindowsExecutableAnalyzer.analyze' in java
assert 'SmartGameProfile.recommend' in java
assert 'GAME_PROFILE_PICK' in java and 'GAME_PROFILE_EXPORT' in java
assert 'no EXE execution' in (root/'app/src/main/java/com/rm11/wincore/SmartGameProfile.java').read_text()
print('PASS: V0.5 read-only EXE advisor UI and explicit no-execution status')
with tempfile.TemporaryDirectory(prefix='rm11-tests-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                    str(src/'WindowsExecutableAnalyzer.java'),
                    str(src/'SmartGameProfile.java'),
                    str(root/'tests/CompatibilityAnalysisTest.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'CompatibilityAnalysisTest'], check=True)

# V0.6-A native ELF metadata audit, never execute components.
elf=(root/'app/src/main/java/com/rm11/wincore/ElfRuntimeInspector.java').read_text()
assert 'ELF_RUNTIME_PICK' in java and 'ElfRuntimeInspector.analyze' in java
assert 'MAX_PREFIX = 256 * 1024' in elf and 'DT_NEEDED' in elf
assert 'Nothing installed, loaded, or executed' in elf
with tempfile.TemporaryDirectory(prefix='rm11-elf-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                    str(src/'ElfRuntimeInspector.java'),
                    str(root/'tests/ElfRuntimeInspectorTest.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'ElfRuntimeInspectorTest'], check=True)
print('PASS: V0.6-A bounded ARM64 ELF loader and library audit; no executable engine')

# V0.7: test a *packaged* Android ARM64 JNI library and host linker path.
# This is not a test of Windows emulation or third-party binary execution.
bridge_cpp=(root/'app/src/main/cpp/RuntimeNativeBridge.cpp').read_text()
bridge_java=(root/'app/src/main/java/com/rm11/wincore/NativeRuntimeBridge.java').read_text()
cmake=(root/'app/src/main/cpp/CMakeLists.txt').read_text()
assert 'Java_com_rm11_wincore_NativeRuntimeBridge_nativeSelfTest' in bridge_cpp
assert 'dlopen("libc.so"' in bridge_cpp and 'dlsym(libc, "getpid")' in bridge_cpp
assert 'RuntimeNativeBridge.cpp' in cmake and ' dl)' in cmake
assert 'NativeRuntimeBridge.inspect()' in java and 'NativeRuntimeBridge' in bridge_java
assert 'System.loadLibrary("rm11probe")' in bridge_java
assert '[NOT INTEGRATED]' in bridge_cpp and 'versionName = "1.3.0"' in (root/'app/build.gradle.kts').read_text()
print('PASS: V0.7 JNI Android/Bionic host smoke test wired to UI; no Wine/Box64 claims')


# V0.8: a real second NDK .so module, dlopen/dlsym C ABI handshake.
# This proves Android intra-APK native integration, NOT Box64/Wine execution.
import shutil
adapter = (root/'app/src/main/cpp/RuntimePluginAdapter.cpp').read_text()
contract = (root/'app/src/main/cpp/RuntimeAdapterContract.h').read_text()
assert 'add_library(rm11runtime_adapter SHARED RuntimePluginAdapter.cpp)' in cmake
assert 'dlopen("librm11runtime_adapter.so"' in bridge_cpp
assert 'RM11_ADAPTER_ABI_VERSION' in bridge_cpp and 'dlsym(module' in bridge_cpp
assert 'NativeRuntimeBridge.inspectAdapter()' in java
assert 'versionCode = 13' in (root/'app/build.gradle.kts').read_text()
assert 'RM11_ADAPTER_ABI_VERSION 1u' in contract
assert 'rm11_adapter_self_test' in adapter
assert '[NOT INTEGRATED]' in bridge_cpp
compiler = shutil.which('g++')
if compiler:
    with tempfile.TemporaryDirectory(prefix='rm11-adapter-') as tmp:
        cpp = root/'app/src/main/cpp'
        shared = Path(tmp)/'librm11runtime_adapter.so'
        exe = Path(tmp)/'adapter-contract-test'
        subprocess.run([compiler,'-std=c++17','-Wall','-Wextra','-Werror','-fPIC',
                        '-shared',str(cpp/'RuntimePluginAdapter.cpp'),'-o',str(shared)],check=True)
        subprocess.run([compiler,'-std=c++17','-Wall','-Wextra','-Werror',
                        '-I',str(cpp),str(root/'tests/NativeAdapterContractTest.cpp'),
                        '-ldl','-o',str(exe)],check=True)
        subprocess.run([str(exe),str(shared)],check=True)
else:
    print('WARN: g++ not available; native dynamic module test omitted')
print('PASS: V0.8 native adapter module, interface and Java binding wired')

# V0.9: stage verified inert bundle bytes to application private storage, never execute.
stager = (root / 'app/src/main/java/com/rm11/wincore/EngineBundleStager.java').read_text()
assert 'EngineBundleStager.stage' in java and 'STAGE_ENGINE_BUNDLE' in java
assert 'new AlertDialog.Builder(this)' in java and 'runOnUiThread' in java
assert 'MessageDigest.getInstance("SHA-256")' in stager and 'getUsableSpace()' in stager
assert 'spec.id + ".blob"' in stager and 'new File(stage, spec.path)' not in stager
assert 'MAX_TOTAL' in stager and 'renameTo(active)' in stager
assert 'NO ENGINE EXECUTION' in stager and 'NOT RUNNABLE' in stager
assert 'Runtime.getRuntime().exec' not in stager and 'ProcessBuilder' not in stager
print('PASS: V0.9 inert engine bundle staging, checksum validation, rollback and UI consent')

subprocess.run(['python3', str(root/'tools/test_stager_host.py')], check=True)

# V1.0-A: read-only audit of staged bundles with fresh SHA256 plus bounded ELF details.
inventory = (root / 'app/src/main/java/com/rm11/wincore/StagedEngineInventory.java').read_text()
binary_audit = (root / 'app/src/main/java/com/rm11/wincore/RuntimeBinaryAudit.java').read_text()
assert 'StagedEngineInventory.inspect' in java and 'runStagedInventory()' in java
assert 'RuntimeBinaryAudit.inspect' in inventory and 'ElfRuntimeInspector.analyze' in binary_audit
assert 'SHA256 is NOT proof of origin' in inventory
assert '[NOT RUNNABLE]' in inventory and '[MISSING]' in inventory
assert 'ProcessBuilder' not in inventory and 'Runtime.getRuntime().exec' not in inventory
with tempfile.TemporaryDirectory(prefix='rm11-inventory-') as tmp:
    src = root/'app/src/main/java/com/rm11/wincore'
    subprocess.run(['javac', '-encoding','UTF-8','-d',tmp,
                    str(src/'ElfRuntimeInspector.java'),
                    str(src/'RuntimeBinaryAudit.java'),
                    str(root/'tests/RuntimeBinaryAuditTest.java')],check=True)
    subprocess.run(['java','-cp',tmp,'RuntimeBinaryAuditTest'],check=True)
print('PASS: V1.0 staged bundle inventory/re-hash and native ELF classification; no EXE claims')

# V1.1: real Android ARM64 PIE *process*, built by NDK into APK native lib directory.
# Unlike V0.3 shell test, this executes our own compiled ARM64 ELF in a new OS process.
exec_java=(root/'app/src/main/java/com/rm11/wincore/PackagedNativeProcess.java').read_text()
exec_c=(root/'app/src/main/cpp/PackagedExecProbe.c').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
assert 'PackagedNativeProcess.runSelfTest' in java and 'runPackagedNativeProcess()' in java
assert 'ProcessBuilder(executable.getAbsolutePath(), "--self-test")' in exec_java
assert 'process.waitFor(7, TimeUnit.SECONDS)' in exec_java
assert 'RM11_ANDROID_ELF_EXEC_OK' in exec_c
assert 'useLegacyPackaging = true' in gradle
assert '[NOT INTEGRATED]' in exec_java
subprocess.run(['python3',str(root/'tools/test_exec_host.py')], check=True)
# The default GitHub Actions ZIP workflow already calls scripts-check.py before Gradle:
# build the executable here, avoiding another manual workflow-file edit per release.
command=['python3',str(root/'tools/build_native_exec.py')]
if __import__('os').environ.get('CI'):
    command.append('--required')
subprocess.run(command,check=True)
print('PASS: V1.1 first-party APK executable launch path; Wine/Box64 remain absent')

# V1.2: pin the debug signing certificate across ephemeral GitHub Action runners.
# This development key is public to anyone with the source; NOT for publication.
assert 'signingConfigs.getByName("rm11PrototypeDebug")' in gradle
assert 'versionName = "1.3.0"' in gradle and 'versionCode = 13' in gradle
subprocess.run(['python3', str(root/'tools/check_debug_signing.py')], check=True)
assert '[DEV SIGNING]' in java and '[ONE-TIME]' in java
print('PASS: V1.2 development debug key identity pinned; update version incremented')

# V1.3: attempt to build real upstream Box64, on CI only, from pinned MIT source.
# The legacy Android test executable still builds even when experimental Box64 fails.
box64_probe=(root/'app/src/main/java/com/rm11/wincore/OfficialBox64Probe.java').read_text()
box64_builder=(root/'tools/build_official_box64.py').read_text()
assert 'OfficialBox64Probe.inspect' in java and 'runOfficialBox64Probe()' in java
assert 'new ProcessBuilder(binary.getAbsolutePath(), "--version")' in box64_probe
assert '[NOT BUILT]' in box64_probe and 'Box64 --version success is NOT evidence' in box64_probe
assert '2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a' in box64_builder
assert '-DANDROID=ON' in box64_builder and 'verify_android_pie(binary)' in box64_builder
assert 'versionCode = 13' in gradle and 'versionName = "1.3.0"' in gradle
subprocess.run(['python3',str(root/'tools/test_box64_builder.py')],check=True)
subprocess.run(['python3',str(root/'tools/test_box64_probe_host.py')],check=True)
if __import__('os').environ.get('CI') and not __import__('os').environ.get('RM11_SKIP_BOX64'):
    # Experimental compilation errors cannot break the proven RM11 Android probe.
    subprocess.run(['python3',str(root/'tools/build_official_box64.py')],check=True)
else:
    print('SKIP: optional upstream Box64 build (CI only); no Box64 executable bundled locally')
print('PASS: V1.3 upstream Box64 build path, pinned revision, bounded version probe and fallback')
