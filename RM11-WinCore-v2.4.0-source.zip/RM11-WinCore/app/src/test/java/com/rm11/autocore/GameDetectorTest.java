package com.rm11.autocore;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

public class GameDetectorTest {
    @Test public void identifiesForzaFromFolder() {
        GameDetector.Detection r = GameDetector.analyze(Arrays.asList(
            new GameDetector.Entry("ForzaHorizon5.exe", false),
            new GameDetector.Entry("media", true)), false);
        assertEquals("fh5", r.gameId);
        assertEquals("DirectX 12", r.graphics);
        assertEquals("ForzaHorizon5.exe", r.exe);
    }
    @Test public void identifiesCyberpunkNestedExecutable() {
        GameDetector.Detection r = GameDetector.analyze(Collections.singletonList(
            new GameDetector.Entry("bin/x64/Cyberpunk2077.exe", false)), false);
        assertEquals("cyberpunk2077", r.gameId);
    }
    @Test public void steamDllIsOnlyTentative() {
        GameDetector.Detection r = GameDetector.analyze(Arrays.asList(
            new GameDetector.Entry("GTA5.exe", false),
            new GameDetector.Entry("steam_api64.dll", false)), false);
        assertEquals("gta5-legacy", r.gameId);
        assertTrue(r.platform.contains("احتمال"));
    }
    @Test public void emptyFolderHasNoExecutable() {
        GameDetector.Detection r = GameDetector.analyze(Collections.emptyList(), false);
        assertEquals("unknown", r.gameId);
        assertEquals("", r.exe);
    }
    @Test public void doesNotMisidentifyUnknownExe() {
        GameDetector.Detection r = GameDetector.analyze(Collections.singletonList(
            new GameDetector.Entry("CustomGame.exe", false)), true);
        assertEquals("unknown", r.gameId);
        assertEquals("CustomGame.exe", r.exe);
        assertTrue(r.truncated);
    }
}
