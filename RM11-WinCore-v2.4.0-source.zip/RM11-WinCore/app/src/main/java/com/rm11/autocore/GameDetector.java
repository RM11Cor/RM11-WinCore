package com.rm11.autocore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Pure-Java, bounded, read-only path analyzer. Does NOT launch Windows games. */
public final class GameDetector {
    private GameDetector() { }

    public static final class Entry {
        public final String path;
        public final boolean directory;
        public Entry(String path, boolean directory) {
            this.path = path == null ? "" : path.replace('\\', '/');
            this.directory = directory;
        }
    }

    public static final class Detection {
        public final String title;
        public final String gameId;
        public final String exe;
        public final String graphics;
        public final String platform;
        public final String certainty;
        public final List<String> evidence;
        public final int scannedCount;
        public final boolean truncated;

        Detection(String title, String gameId, String exe, String graphics, String platform,
                  String certainty, List<String> evidence, int scannedCount, boolean truncated) {
            this.title = title;
            this.gameId = gameId;
            this.exe = exe;
            this.graphics = graphics;
            this.platform = platform;
            this.certainty = certainty;
            this.evidence = Collections.unmodifiableList(new ArrayList<>(evidence));
            this.scannedCount = scannedCount;
            this.truncated = truncated;
        }
    }

    private static boolean hasExact(List<String> paths, String name) {
        for (String p : paths) {
            if (p.equals(name) || p.endsWith("/" + name)) return true;
        }
        return false;
    }
    private static String findExe(List<String> paths, String file) {
        for (String p : paths) {
            if (p.equals(file) || p.endsWith("/" + file)) return p;
        }
        return "";
    }
    private static boolean contains(List<String> paths, String fragment) {
        for (String p : paths) if (p.contains(fragment)) return true;
        return false;
    }

    public static Detection analyze(List<Entry> entries, boolean truncated) {
        if (entries == null) entries = Collections.emptyList();
        List<String> files = new ArrayList<>();
        List<String> originalPaths = new ArrayList<>();
        for (Entry e : entries) {
            if (e == null || e.directory || e.path.isEmpty()) continue;
            files.add(e.path.toLowerCase(Locale.ROOT));
            originalPaths.add(e.path);
        }
        String title = "لعبة غير معروفة";
        String id = "unknown";
        String dx = "غير محدد";
        String candidate = "";
        String[] titles = {"Forza Horizon 5", "Grand Theft Auto V Enhanced", "Grand Theft Auto V Legacy",
                "Cyberpunk 2077", "Red Dead Redemption 2", "Watch Dogs 2", "God of War"};
        String[] ids = {"fh5", "gta5-enhanced", "gta5-legacy", "cyberpunk2077", "rdr2", "watchdogs2", "gow"};
        String[] markers = {"forzahorizon5.exe", "gta5_enhanced.exe", "gta5.exe", "cyberpunk2077.exe",
                "rdr2.exe", "watchdogs2.exe", "gow.exe"};
        String[] graphics = {"DirectX 12", "DirectX 12", "DirectX 11 (typical)",
                "DirectX 12", "Vulkan / DirectX 12", "DirectX 11", "DirectX 11"};
        List<String> evidence = new ArrayList<>();
        for (int i = 0; i < markers.length; i++) {
            String match = findExe(files, markers[i]);
            if (!match.isEmpty()) {
                title = titles[i]; id = ids[i]; dx = graphics[i]; candidate = originalPaths.get(files.indexOf(match));
                evidence.add("ملف تشغيل مطابق: " + candidate);
                break;
            }
        }
        if (candidate.isEmpty()) {
            for (int i = 0; i < files.size(); i++) {
                String p = files.get(i);
                if (p.endsWith(".exe") && !p.contains("setup") && !p.contains("unins")
                        && !p.contains("redist") && !p.contains("launcher") && !p.contains("crashreport")) {
                    candidate = originalPaths.get(i);
                    evidence.add("ملف تشغيل مرشح (غير مؤكد): " + candidate);
                    break;
                }
            }
        }
        String platform = "غير معروف / قد تكون مستقلة";
        if (contains(files, "uplay_r1_loader") || hasExact(files, "upc_r2_loader.dll")) {
            platform = "Ubisoft Connect (احتمال)";
            evidence.add("مكتبات Ubisoft موجودة؛ لا تثبت نوع الترخيص");
        } else if (hasExact(files, "socialclub.dll") || hasExact(files, "socialclub64.dll")) {
            platform = "Rockstar Games Launcher (احتمال)";
            evidence.add("مكتبة Social Club موجودة");
        } else if (hasExact(files, "steam_appid.txt") || hasExact(files, "steam_api64.dll") || hasExact(files, "steam_api.dll")) {
            platform = "Steam (احتمال، غير مؤكد)";
            evidence.add("ملف متعلق بواجهة Steam؛ لا يثبت الاعتماد على Steam");
        } else if (contains(files, "eaappinstaller") || hasExact(files, "originclient.dll")) {
            platform = "EA app (احتمال)";
            evidence.add("ملف متعلق بخدمات EA");
        }
        String certainty = id.equals("unknown") ? "غير محدد" : "تعرف على اسم اللعبة (الإصدار يحتاج تحقق)";
        if (truncated) evidence.add("الفحص محدود؛ ربما لم تُفحص جميع الملفات");
        evidence.add("توافق Proton/FEX/Turnip/VKD3D لم يُختبر بعد على هذا الجهاز");
        return new Detection(title, id, candidate, dx, platform, certainty,
                evidence, entries.size(), truncated);
    }
}
