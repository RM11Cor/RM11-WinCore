RM11-WinCore v2.4.14-alpha — source update

This ZIP contains a Git patch that updates the existing RM11Cor/RM11-WinCore v2.4.13-alpha source tree; it is NOT an APK or a ready-to-play Windows emulator.

Recommended: in a local clone of https://github.com/RM11Cor/RM11-WinCore at v2.4.13-alpha, run:
    git apply --check RM11-WinCore-v2.4.14-runtime-bootstrap.patch
    git apply RM11-WinCore-v2.4.14-runtime-bootstrap.patch
Then commit/push the changed source and run the existing GitHub Actions workflow. Do not upload this ZIP itself into the repository and expect GitHub to apply it automatically.

Changes: Android JNI ARM64 native/JIT smoke test, transparent readiness gates, build version 2.4.14-alpha, and CI version assertion adjustment.

Not included: FEX/Wine/Proton runtime, Vulkan/DXVK fully integrated game execution, downloadable signed APK.

Signing: no keystore included or replaced; existing GitHub Actions signing setup is preserved, subject to verification during build.
