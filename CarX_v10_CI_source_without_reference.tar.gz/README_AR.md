# CarX Native Foundation v10 — Actual Unity Serialized Object Payloads

هذه الحزمة اختبار Android ARM64 أصلي وليست اللعبة ولا Unity Player.

الجديد: فك جدول الكائنات ثم قراءة أول 64 بايت من **البيانات الفعلية** لعينة من كائنات SerializedFile v22 من الحزم الثلاث؛ حتى لو امتدت بين كتل LZ4. يعرض هوية الصنف، موضع الكائن وحجمه وعينات البايتات، ويستخرج الاسم المحتمل لكائن Mesh أو Material فقط إذا كانت البنية متوافقة مع سلسلة UTF-8 ASCII بسيطة.

- تحققات الحدود صارمة ولا تعدل أي ملف للعبة.
- حفظ الأصل: `GameAssembly.dll` تتطابق بصمته قبل فحص موارد اللعبة.
- رقم البناء 1000، اسم الحزمة `com.carx.nativefoundation.test.updates`، يحتاج التوقيع نفسه لقناة v7 كي يتم التحديث فوق v9.1.
- معيار النجاح: `PASS_V22_METADATA_OBJECT_INDEX` و `actual_object_data_samples` تتضمن قيم `read_ok:true`.
- هذه ليست إعادة بناء AssetBundle لـAndroid ولا بناء Unity/IL2CPP ولا تشغيل مشهد؛ تأكيد التشغيل الكامل مؤجل إلى إثباته فعلياً.
