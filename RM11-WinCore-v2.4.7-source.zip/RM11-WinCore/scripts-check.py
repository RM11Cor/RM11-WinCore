#!/usr/bin/env python3
"""Reject structurally incomplete source ZIPs before the legacy build job runs."""
from pathlib import Path
needed = [
    'settings.gradle',
    'build.gradle',
    'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/rm11/autocore/MainActivity.java',
    'app/src/main/java/com/rm11/autocore/GameDetector.java',
    'app/src/main/java/com/rm11/autocore/PeVersionReader.java',
    'app/src/main/java/com/rm11/autocore/PeImportReader.java',
    'app/src/main/java/com/rm11/autocore/GameManifestReader.java',
    'app/src/main/java/com/rm11/autocore/CompatibilityPlanner.java',
    'app/src/test/java/com/rm11/autocore/GameDetectorTest.java',
    'app/src/test/java/com/rm11/autocore/GameManifestReaderTest.java',
    'app/src/test/java/com/rm11/autocore/PeImportReaderTest.java',
    'app/src/test/java/com/rm11/autocore/CompatibilityPlannerTest.java'
]
for filename in needed:
    path = Path(filename)
    if not path.is_file() or path.stat().st_size == 0:
        raise SystemExit('MISSING OR EMPTY: ' + filename)
print('RM11 AutoCore v2.4.7: structure OK (not an APK runtime test).')

# Protect upgrade identity and signed-release configuration.
config = Path('app/build.gradle').read_text(encoding='utf-8')
checks = {
    "stable applicationId": "applicationId 'com.rm11.autocore'",
    'monotonic versionCode': 'versionCode 8',
    'release versionName': "versionName '2.4.7-alpha'",
    'stable release signing': 'signingConfig signingConfigs.stable',
    'keystore from environment': "System.getenv('RM11_RELEASE_KEYSTORE')",
    'password from environment': "System.getenv('RM11_RELEASE_PASSWORD')",
}
for label, value in checks.items():
    if value not in config:
        raise SystemExit('INVALID BUILD CONFIG (' + label + '): ' + value)
print('RM11 v2.4.7: update identity and signing configuration OK')
