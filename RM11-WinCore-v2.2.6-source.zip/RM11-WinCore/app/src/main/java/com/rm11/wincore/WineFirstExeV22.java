package com.rm11.wincore;

import android.content.Context;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** V2.2.6 ONLY runs our own offline Windows console PE under Wine via Box64.
 * PASS requires BOTH a zero process status AND marker created through Win32 IO.
 * Not a user-file launcher or evidence that games/graphics are supported.
 */
public final class WineFirstExeV22 {
    private WineFirstExeV22() { }
    private static final String ASSET = "wine_exe_v22/";
    private static final String MARKER_FILE = "RM11-V22-WIN32-OK.txt";
    private static final String MARKER = "RM11_V22_WINDOWS_PE_EXEC_OK\n";
    private static final String WIN_DIR = "usr/lib/x86_64-linux-gnu/wine/x86_64-windows/";
    private static final String[] ESSENTIAL = {"kernel32.dll", "kernelbase.dll", "wineboot.exe"};
    private static final int MAX_FILE = 32 * 1024 * 1024;
    // A Wine NLS manifest can contain up to 128 codepages plus PE modules.
    // 10,000 bytes rejected valid V2.2.1 manifests before Wine could start.
    static final int MAX_MANIFEST_BYTES = 64 * 1024;
    static final int MAX_LOG = 32000;
    /** Keeps the first 4 KB and final 28 KB instead of losing the fatal tail on chatty Box64 runs. */
    static final class HeadTailLog {
        private static final int HEAD = 4096;
        private static final int TAIL = MAX_LOG - HEAD;
        private final ByteArrayOutputStream first = new ByteArrayOutputStream(HEAD);
        private final byte[] last = new byte[TAIL];
        private long count;
        private int tailPos;

        synchronized void append(byte[] src, int length) {
            if (length < 0 || length > src.length) throw new IllegalArgumentException("Invalid log chunk");
            int f = Math.min(length, HEAD - first.size());
            if (f > 0) first.write(src, 0, f);
            for (int i = 0; i < length; ++i) {
                last[tailPos] = src[i];
                tailPos = (tailPos + 1) % TAIL;
            }
            count += length;
        }

        synchronized String text() {
            byte[] initial = first.toByteArray();
            int tailBytes = (int)Math.min(count, TAIL);
            int start = count >= TAIL ? tailPos : 0;
            byte[] suffix = new byte[tailBytes];
            for (int i = 0; i < tailBytes; ++i) suffix[i] = last[(start+i)%TAIL];
            if (count <= MAX_LOG) {
                int overlap = Math.max(0, initial.length + tailBytes - (int)count);
                return new String(initial, StandardCharsets.UTF_8)
                    + new String(suffix, overlap, tailBytes-overlap, StandardCharsets.UTF_8);
            }
            return new String(initial, StandardCharsets.UTF_8)
                + "\n[LOG TRUNCATED: middle omitted; crash tail preserved]\n"
                + new String(suffix, StandardCharsets.UTF_8);
        }
    }
    private static final String NLS_DIR = "usr/share/wine/nls/";
    private static final String[] NLS_REQUIRED = {"locale.nls","l_intl.nls","c_1252.nls","c_437.nls"};
    private static final int TIMEOUT_SECONDS = 55;

    static Map<String,String> parseManifest(String text) {
        Map<String,String> result = new HashMap<>();
        for (String line : text.split("\\r?\\n")) {
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("Version: ") || line.startsWith("Use: ")) continue;
            String[] parts = line.split("\\t",-1);
            if (parts.length!=3 || !(parts[0].startsWith("usr/lib/x86_64-linux-gnu/wine/") ||
                parts[0].startsWith(NLS_DIR) || parts[0].equals("usr/share/wine/wine.inf")) ||
                parts[0].contains("..") || parts[0].contains("\\\\") ||
                !parts[1].matches("[0-9a-f]{64}") || !parts[2].matches("[0-9]{1,10}"))
                throw new IllegalArgumentException("Untrusted Wine PE manifest entry");
            if (result.put(parts[0],parts[1])!=null) throw new IllegalArgumentException("Duplicate Wine PE module");
        }
        if (result.size()<8 || result.size()>160) throw new IllegalArgumentException("Invalid Wine PE module count");
        for (String module : ESSENTIAL) if (!result.containsKey(WIN_DIR+module))
            throw new IllegalArgumentException("Missing core Windows PE module: "+module);
        for (String name : NLS_REQUIRED) if (!result.containsKey(NLS_DIR+name))
            throw new IllegalArgumentException("Missing Wine NLS file: " + name);
        if (!result.containsKey("usr/share/wine/wine.inf"))
            throw new IllegalArgumentException("Missing Wine prefix configuration file");
        return result;
    }

    static String classify(int exitCode, boolean timeout, boolean markerOk, String log) {
        if (timeout) return "[TIMEOUT] Wine Windows EXE did not finish in " + TIMEOUT_SECONDS + " seconds.\n";
        if (exitCode==0 && markerOk) return "[PASS WINDOWS EXE] Verified own x86-64 PE invoked Win32 CreateFileA/WriteFile under Wine.\n"
          + "[LIMIT] Does NOT establish general EXE, GUI, DXVK, games or FPS compatibility.\n";
        String lower = log.toLowerCase(Locale.ROOT);
        // A fatal pointer-tag/allocator error takes priority over earlier
        // incidental missing-dependency warnings printed during Wine startup.
        if (lower.contains("pointer tag") || lower.contains("box64(free") || lower.contains("sigabrt"))
            return "[MEMORY CRASH] Native heap/Box64 pointer or Wine allocation fault suspected; tag opt-out is a TEMPORARY diagnostic, not an allocator fix.\n";
        if (lower.contains("unrecognized charset"))
            return "[LOCALE ABI] Box64 glibc/Bionic charset mapping still failed.\n";
        if (lower.contains("failed to load") && lower.contains(".nls"))
            return "[NLS BLOCKED] Wine failed to read its packaged locale data.\n";
        if (lower.contains("no such file") || lower.contains("could not load") || lower.contains("error loading needed")
                || lower.contains("unresolved") || lower.contains("symbol not found") || lower.contains("not found in lib")
                || lower.contains("failed to start") || lower.contains("could not be started")
                || lower.contains("exec format") || lower.contains("wineserver"))
            return "[BLOCKED] Wine initialization, wineserver, DLL or Box64 dependency failed. Read exact first error above.\n";
        if (exitCode==0) return "[NOT PROVEN] Process exited 0 but did NOT write Win32 marker. No EXE success claimed.\n";
        return "[FAIL WINDOWS EXE] Exit=" + exitCode + "; marker=" + markerOk + ". Read log above.\n";
    }

    // Limit reads even if a corrupt APK includes unusually large assets.
    static byte[] readAssetBounded(InputStream in, String path, int limit) throws Exception {
        if (limit < 1) throw new IllegalArgumentException("Invalid asset limit");
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] block = new byte[8192]; int n;
            while ((n=stream.read(block)) != -1) {
                if (n > limit - out.size()) throw new IllegalArgumentException("Oversized asset: " + path);
                out.write(block,0,n);
            }
            return out.toByteArray();
        }
    }
    private static byte[] asset(Context ctx, String path, int limit) throws Exception {
        return readAssetBounded(ctx.getAssets().open(path), path, limit);
    }
    private static String sha(byte[] data) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder sb=new StringBuilder();
        for(byte b:digest) sb.append(String.format(Locale.ROOT,"%02x",b&255));
        return sb.toString();
    }
    private static void stage(File root, String rel, byte[] data) throws Exception {
        File target=new File(root,rel);
        if (!target.getParentFile().isDirectory() && !target.getParentFile().mkdirs())
            throw new IllegalStateException("Cannot create staging directories");
        try(FileOutputStream out = new FileOutputStream(target)) {out.write(data); out.getFD().sync();}
    }

    private enum ProbeMode { NORMAL, REDUCED_TAG_CHECKS, MALLOC_TRACKING, ENV_FREE_GUARD }

    public static String run(Context ctx) { return run(ctx, ProbeMode.NORMAL); }

    /** Legacy opt-in A/B diagnostic; weakens Bionic checking ONLY in the Box64 subprocess. */
    public static String runHeapDiagnostic(Context ctx) { return run(ctx, ProbeMode.REDUCED_TAG_CHECKS); }

    /** New V2.2.5 probe: Box64 special malloc/mmap/free tracking; Android heap safety stays enabled. */
    public static String runMallocTrackingDiagnostic(Context ctx) { return run(ctx, ProbeMode.MALLOC_TRACKING); }

    /** Opt-in pointer identity diagnostic for secure_getenv / free. Never enabled by default. */
    public static String runEnvFreeDiagnostic(Context ctx) { return run(ctx, ProbeMode.ENV_FREE_GUARD); }

    private static String run(Context ctx, ProbeMode mode) {
        boolean isolateHeap = mode == ProbeMode.REDUCED_TAG_CHECKS;
        boolean mallocTracking = mode == ProbeMode.MALLOC_TRACKING;
        boolean guardEnvFree = mode == ProbeMode.ENV_FREE_GUARD;
        StringBuilder report = new StringBuilder("RM11 WinCore V2.2.6 / Box64 borrowed environment pointer A/B\n")
            .append("Offline, first-party Win32 CreateFileA/WriteFile test only; no game/GUI or external EXE.\n");
        if (Build.SUPPORTED_ABIS.length==0 || !"arm64-v8a".equals(Build.SUPPORTED_ABIS[0]))
            return report.append("[STOP] ARM64 device required.\n").toString();
        report.append(guardEnvFree
            ? "[ENV-FREE TEST] Opt-in exact secure_getenv pointer match; guards borrowed free only. Android tags stay enabled; NOT a fix.\n"
            : mallocTracking
            ? "[TRACKING TEST] BOX64_MALLOC_HACK=2 only for this Box64 child; Android heap tags stay enabled; NOT a fix.\n"
            : isolateHeap
                ? "[ISOLATED HEAP TEST] Reduced heap-tag protection ONLY in Box64 child process for this one run, NOT a fix.\n"
                : "[DEFAULT] Native heap pointer tagging stays enabled; baseline test.\n");
        File nativeDir=new File(ctx.getApplicationInfo().nativeLibraryDir);
        File box=new File(nativeDir,"librm11box64.so");
        File bridge=new File(nativeDir,"librm11wineserverbridge.so");
        if (!box.isFile() || !bridge.isFile())
            return report.append("[NOT BUILT] Box64 or wineserver ARM64 bridge missing in APK.\n").toString();
        Process process=null;
        try {
            File root=new File(ctx.getCacheDir(),"rm11-wine-v22");
            WineRuntimeV21.stageTo(ctx,root); // requires all SHA256-checked 7 Wine startup binaries
            String manifest=new String(asset(ctx,ASSET+"WINDOWS-COMPONENTS.tsv",MAX_MANIFEST_BYTES),StandardCharsets.UTF_8);
            Map<String,String> modules=parseManifest(manifest);
            for (String rel : modules.keySet()) {
                byte[] raw=asset(ctx,ASSET+rel,MAX_FILE);
                if (!sha(raw).equals(modules.get(rel))) throw new IllegalArgumentException("Wine DLL SHA256 mismatch: "+rel);
                stage(root,rel,raw);
                // Wine loader may resolve ../../../share/wine relative to usr/lib/wine.
                // Provide that exact fallback path as well as canonical usr/share/wine.
                if (rel.startsWith("usr/share/wine/")) stage(root,"share/wine/"+rel.substring("usr/share/wine/".length()),raw);
            }
            byte[] exe=asset(ctx,ASSET+"rm11_probe.exe",100000);
            String expected=new String(asset(ctx,ASSET+"PE-SHA256.txt",128),StandardCharsets.UTF_8).trim();
            if (!expected.matches("[0-9a-f]{64}") || !sha(exe).equals(expected))
                throw new IllegalArgumentException("Windows test EXE SHA256 mismatch");
            // PE32+ x86-64 signature, import table names and literal test marker.
            int peOff = (exe[0x3c] & 255) | ((exe[0x3d] & 255) << 8) |
                        ((exe[0x3e] & 255) << 16) | ((exe[0x3f] & 255) << 24);
            if (exe.length<1024 || exe[0]!='M' || exe[1]!='Z' ||
                peOff<64 || peOff>exe.length-26 || exe[peOff]!='P' || exe[peOff+1]!='E' ||
                exe[peOff+2]!=0 || exe[peOff+3]!=0 ||
                (exe[peOff+4]&255)!=0x64 || (exe[peOff+5]&255)!=0x86 ||
                (exe[peOff+24]&255)!=0x0b || (exe[peOff+25]&255)!=0x02 ||
                !new String(exe,StandardCharsets.ISO_8859_1).contains("KERNEL32.dll") ||
                !new String(exe,StandardCharsets.ISO_8859_1).contains("CreateFileA"))
                throw new IllegalArgumentException("Not a recognized first-party Win64 PE");
            File work = new File(ctx.getFilesDir(),guardEnvFree?"rm11-v226-env-free-work":mallocTracking?"rm11-v225-malloc-tracking-work":isolateHeap?"rm11-v224-heap-isolation-work":"rm11-v22-win32-work");
            if (!work.isDirectory() && !work.mkdirs()) throw new IllegalStateException("Workdir unavailable");
            File success=new File(work,MARKER_FILE);
            if (success.exists() && !success.delete()) throw new IllegalStateException("Stale marker could not be removed");
            File guest=new File(work,"rm11_probe.exe");
            stage(work,"rm11_probe.exe",exe);
            File prefix=new File(ctx.getFilesDir(),guardEnvFree?"rm11-v226-env-free-prefix":mallocTracking?"rm11-v225-malloc-tracking-prefix":isolateHeap?"rm11-v224-heap-isolation-prefix":"rm11-v22-wineprefix");
            if (!prefix.isDirectory() && !prefix.mkdirs()) throw new IllegalStateException("Wine prefix unavailable");
            File wine=new File(root,"usr/lib/wine/wine64");
            File server=new File(root,"usr/lib/wine/wineserver64");
            if (!wine.canExecute() || !server.canExecute()) throw new IllegalArgumentException("Wine/wineserver executable missing");
            report.append("[STAGED] 7 V2.1 Wine binaries + ").append(modules.size()).append(" Wine PE/NLS/INF files\n")
                .append("[NLS] locale.nls, l_intl.nls and codepage tables hashed, staged at two Wine search paths\n")
                .append(guardEnvFree
                    ? "[BORROWED ENV A/B] Only exact secure_getenv address matches are skipped in this run; native tags stay on\n"
                    : mallocTracking
                    ? "[ALLOCATOR A/B] BOX64_MALLOC_HACK=2; track special mmap/free only in this run; tagging retained\n"
                    : isolateHeap
                        ? "[HEAP TAG A/B] Explicit child-process trial only; Box64 must confirm mallopt; NOT a memory fix\n"
                        : "[HEAP TAG] Android pointer-tag protection retained; no mitigation applied\n")
                .append("[PE VERIFIED] first-party Windows x86-64 PE (not Linux ELF), SHA256 OK\n")
                .append("[WINESERVER] ARM64 launcher -> Box64 -> Wine wineserver64\n")
                .append("[PREFIX] private application directory; no root/network\n");
            ProcessBuilder pb=new ProcessBuilder(box.getAbsolutePath(),wine.getAbsolutePath(),guest.getAbsolutePath());
            pb.directory(work);pb.redirectErrorStream(true);
            Map<String,String> env=pb.environment();
            env.put("BOX64_DYNAREC","0");env.put("BOX64_LOG","1");
            // Keep the opt-out entirely scoped to one user-requested subprocess.
            if (isolateHeap) env.put("RM11_TEST_DISABLE_BIONIC_HEAP_TAGS","1");
            else env.remove("RM11_TEST_DISABLE_BIONIC_HEAP_TAGS");
            if (guardEnvFree) env.put("RM11_TEST_ENV_FREE_GUARD", "1");
            else env.remove("RM11_TEST_ENV_FREE_GUARD");
            if (mallocTracking) {
                env.put("BOX64_MALLOC_HACK", "2");
                env.put("BOX64_ROLLING_LOG", "16");
                env.put("BOX64_SHOWBT", "1");
            } else {
                env.remove("BOX64_MALLOC_HACK");
                env.remove("BOX64_ROLLING_LOG");
                env.remove("BOX64_SHOWBT");
            }
            env.put("BOX64_LD_LIBRARY_PATH",new File(root,"usr/lib/x86_64-linux-gnu/wine/x86_64-unix").getAbsolutePath()
                +":"+new File(root,"usr/lib/x86_64-linux-gnu").getAbsolutePath());
            env.put("WINEDLLPATH",new File(root,"usr/lib/x86_64-linux-gnu/wine").getAbsolutePath());
            env.put("WINESERVER",bridge.getAbsolutePath());
            env.put("RM11_WINESERVER64_PATH",server.getAbsolutePath());
            env.put("WINELOADER",wine.getAbsolutePath());
            env.put("WINEPREFIX",prefix.getAbsolutePath());env.put("WINEARCH","win64");
            env.put("HOME",ctx.getFilesDir().getAbsolutePath());
            env.put("XDG_CACHE_HOME",ctx.getCacheDir().getAbsolutePath());
            env.put("WINEDEBUG","warn+all");
            env.put("WINEDATADIR",new File(root,"usr/share/wine").getAbsolutePath());
            // Android's inherited LC_*/TZ can confuse Wine/glibc locale bootstrap.
            env.keySet().removeIf(k -> k.startsWith("LC_"));
            env.put("LANG","C");env.put("LC_ALL","C");env.put("LANGUAGE","C");env.put("TZ","UTC");
            env.remove("LD_PRELOAD"); env.remove("DISPLAY");env.remove("WAYLAND_DISPLAY");
            process=pb.start();
            Process child=process;
            HeadTailLog bounded=new HeadTailLog();
            Thread drain=new Thread(() -> {
                try(InputStream src=child.getInputStream()) {
                    byte[] buf=new byte[2048];int n;
                    while((n=src.read(buf))!=-1) bounded.append(buf,n);
                } catch(Exception ignored) { }
            },"rm11-v22-wine-output");
            drain.setDaemon(true);drain.start();
            boolean finished=process.waitFor(TIMEOUT_SECONDS,TimeUnit.SECONDS);
            if(!finished) {process.destroyForcibly();process.waitFor(2,TimeUnit.SECONDS);}
            drain.join(1200);
            String output = bounded.text();
            boolean written=success.isFile() && success.length()==MARKER.getBytes(StandardCharsets.UTF_8).length
                && MARKER.equals(new String(Files.readAllBytes(success.toPath()),StandardCharsets.UTF_8));
            int code=finished?process.exitValue():-1;
            if (guardEnvFree) {
                if (!output.contains("RM11_ENV_FREE_RETURN"))
                    report.append("[UNCONFIRMED] No secure_getenv return observed. Guard not exercised; NO diagnostic conclusion.\n");
                else if (output.contains("RM11_ENV_FREE_MATCH"))
                    report.append("[MATCH] Wine requested free of an address from secure_getenv; guarded only in this test.\n");
                else report.append("[NO MATCH] secure_getenv returned storage but none matched guarded free in captured log.\n");
            }
            if (isolateHeap && !output.contains("RM11_HEAP_ISOLATION_APPLIED"))
                report.append("[NOT APPLIED] Missing subprocess confirmation; cannot infer result.\n");
            report.append("Exit code: ").append(code).append(finished?"":" (TIMEOUT)")
                .append("\nWin32 marker verified: ").append(written?"YES":"NO")
                .append("\nWine/Box64 output (bounded):\n").append(output).append("\n")
                .append(classify(code,!finished,written,output));
        } catch(Exception e) {
            report.append("[RUNTIME ERROR] ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append('\n');
        } finally {
            if(process!=null && process.isAlive()) process.destroyForcibly();
        }
        return report.toString();
    }
}
