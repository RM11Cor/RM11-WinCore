#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <dlfcn.h>
#include "carx_core.h"

JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeRunDifferential(JNIEnv* env,jclass cls,jbyteArray data){
 (void)cls;
 char out[512]={0};
 if(!data)return (*env)->NewStringUTF(env,"FAIL: missing original x86 reference");
 jsize n=(*env)->GetArrayLength(env,data);
 jbyte* bytes=(*env)->GetByteArrayElements(env,data,0);
 if(!bytes)return (*env)->NewStringUTF(env,"FAIL: cannot access reference");
 carx_run_differential((const unsigned char*)bytes,(size_t)n,out,sizeof out);
 (*env)->ReleaseByteArrayElements(env,data,bytes,JNI_ABORT);
 return (*env)->NewStringUTF(env,out);
}
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeProbeUnityFS(JNIEnv* env,jclass cls,jbyteArray data){
 (void)cls;
 char out[512]={0};
 if(!data)return (*env)->NewStringUTF(env,"{\"unityfs\":false}");
 jsize n=(*env)->GetArrayLength(env,data);
 jbyte* b=(*env)->GetByteArrayElements(env,data,0);
 if(!b)return (*env)->NewStringUTF(env,"{\"unityfs\":false}");
 carx_probe_unityfs((const unsigned char*)b,(size_t)n,out,sizeof out);
 (*env)->ReleaseByteArrayElements(env,data,b,JNI_ABORT);
 return (*env)->NewStringUTF(env,out);
}
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeProbePE(JNIEnv* env,jclass cls,jbyteArray data){
 (void)cls;
 char out[512]={0};
 if(!data)return (*env)->NewStringUTF(env,"{\"pe\":false}");
 jsize n=(*env)->GetArrayLength(env,data);
 jbyte* b=(*env)->GetByteArrayElements(env,data,0);
 if(!b)return (*env)->NewStringUTF(env,"{\"pe\":false}");
 carx_probe_pe((const unsigned char*)b,(size_t)n,out,sizeof out);
 (*env)->ReleaseByteArrayElements(env,data,b,JNI_ABORT);
 return (*env)->NewStringUTF(env,out);
}
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeProbeVulkan(JNIEnv* env,jclass cls){
 (void)cls;
 char out[512];
 void* vk=dlopen("libvulkan.so",RTLD_NOW|RTLD_LOCAL);
 if(!vk){snprintf(out,sizeof out,"{\"loader_found\":false,\"device_validated\":false}");return (*env)->NewStringUTF(env,out);}
 typedef int (*enumerate_instance_version_fn)(uint32_t*);
 enumerate_instance_version_fn f=(enumerate_instance_version_fn)dlsym(vk,"vkEnumerateInstanceVersion");
 uint32_t version=(1u<<22);
 int result=f?f(&version):0;
 if(result!=0)version=0;
 snprintf(out,sizeof out,"{\"loader_found\":true,\"loader_api_version\":\"%u.%u.%u\",\"device_validated\":false}",(version>>22),(version>>12)&1023u,version&4095u);
 dlclose(vk);
 return (*env)->NewStringUTF(env,out);
}

/* v4: actual GPU enumeration and VkDevice creation, not a renderer. */
void carx_probe_gpu(char* out,size_t cap);
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeProbeGpu(JNIEnv* env,jclass cls){
 (void)cls;
 char out[2048]={0};
 carx_probe_gpu(out,sizeof out);
 return (*env)->NewStringUTF(env,out);
}

/* v5: real Android SurfaceView -> VkSurfaceKHR / VkSwapchainKHR / QueuePresent.
 * A flat color TEST frame, never game content. */
void carx_present_test_surface(JNIEnv* env, jobject surface, char* out, size_t cap);
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeRenderVulkanSurface(JNIEnv* env,jclass cls,jobject surface){
 (void)cls;
 char out[1024]={0};
 carx_present_test_surface(env,surface,out,sizeof out);
 return (*env)->NewStringUTF(env,out);
}

/* v6: read-only direct inspection of UnityFS block and CAB directory data.
 * Does not load an asset into Unity, decrypt, or run any CarX game code. */
void carx_inspect_unityfs_fd(int fd,uint64_t file_size,char* out,size_t cap);
JNIEXPORT jstring JNICALL Java_com_carx_nativefoundation_MainActivity_nativeInspectBundleFd(JNIEnv* env,jclass cls,jint fd,jlong file_size){
 (void)cls;
 char out[32768]={0};
 carx_inspect_unityfs_fd((int)fd,file_size<0?0:(uint64_t)file_size,out,sizeof out);
 return (*env)->NewStringUTF(env,out);
}
