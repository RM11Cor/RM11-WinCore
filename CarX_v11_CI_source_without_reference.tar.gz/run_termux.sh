#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [ "$(uname -m)" != "aarch64" ]; then echo 'FAIL: ARM64 phone is required'; exit 3; fi
for cmd in clang sha256sum; do command -v "$cmd" >/dev/null || { echo "Please install Termux package: $cmd"; exit 3; }; done
expected='7d4eb4eb338d4fe3d7d5a29146b4dd248bb893b42a33b4a7461f9fdf0b6125ad'
actual="$(sha256sum app/src/main/assets/x86_reference_v2100.txt | awk '{print $1}')"
[ "$actual" = "$expected" ] || { echo 'FAIL: reference SHA mismatch'; exit 3; }
mkdir -p tests/build
clang -O2 -std=c11 -Wall -Wextra -Werror \
 -Iapp/src/main/cpp app/src/main/cpp/carx_core.c \
 app/src/main/cpp/carx_prefix_a.S app/src/main/cpp/carx_prefix_b.S \
 tests/host_cli.c -o tests/build/carx_native_arm64_check
LOG="/sdcard/Download/CarX_NativeFoundation_v6_native.txt"
tests/build/carx_native_arm64_check app/src/main/assets/x86_reference_v2100.txt | tee "$LOG"
command -v python3 >/dev/null && python3 - "$LOG" <<'PY'
import json,sys,pathlib
log=pathlib.Path(sys.argv[1]).read_text()
out={"schema":"carx.native-foundation.termux-v6","arch":"aarch64","status":"PASS_NATIVE_AOT_ONLY" if "PASS_NATIVE_AOT_IN_APP_V3 vectors=1024" in log and "PASS_UNITYFS_HEADER_PARSER_AND_PE_GUARD" in log else "FAIL","game_boot_proven":False,"apk_built_by_this_script":False,"evidence":log.splitlines()}
p=pathlib.Path('/sdcard/Download/CarX_NativeFoundation_v6_Termux.json');p.write_text(json.dumps(out,indent=2));print('REPORT='+str(p))
PY
