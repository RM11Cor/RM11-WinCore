# CarX Native Foundation v11 — Real Mesh TypeTree Metadata

مرحلة Android ARM64 أصلية لقراءة **TypeTree** الفعلي من ملفات CarX Streamed UnityFS v22، من دون تعديل البيانات، وإظهار بنية حقول Mesh/Material/GameObject مع البصمة البنيوية للنوع؛ يحافظ على استعراض العينات الفعلية من v10.

**إصلاح دقة**: PathID يخزّن كنصّ عشري للحفاظ على 64 بت بدون خسارة دقة في JSON على Android.

الأسماء ذات الإزاحة المرتفعة في TypeTree تشير إلى جدول Unity المشترك غير الموجود داخل هذه الحزم، لذا تظهر `null` مع رقم الإزاحة بدلاً من التخمين.

**ليس بورت CarX المكتمل.** لا يتم بناء Unity Android Player أو تشغيل IL2CPP أو استخراج vertex/index buffers بعد. فحص الموارد فقط لتمهيد تحديد حقول المجسم الفعلي؛ الخطوة التالية تفسير قنوات الرؤوس والمؤشرات وبناء حزمة هندسية للعرض عبر Vulkan.

اسم حزمة التحديث `com.carx.nativefoundation.test.updates`، رقم البناء 1100، التوقيع يجب أن يطابق v7–v10 قبل النشر.
