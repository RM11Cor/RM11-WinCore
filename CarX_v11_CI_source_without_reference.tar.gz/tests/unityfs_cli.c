#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
void carx_inspect_unityfs_fd(int fd,uint64_t file_size,char* out,size_t cap);
int main(int argc,char** argv){
 if(argc!=2){fprintf(stderr,"usage: unityfs_cli path\n");return 2;}
 int fd=open(argv[1],O_RDONLY);
 if(fd<0)return 2;
 struct stat st;if(fstat(fd,&st)||st.st_size<0){close(fd);return 2;}
 char json[8192]={0};carx_inspect_unityfs_fd(fd,(uint64_t)st.st_size,json,sizeof json);
 close(fd);puts(json);
 return 0;
}
