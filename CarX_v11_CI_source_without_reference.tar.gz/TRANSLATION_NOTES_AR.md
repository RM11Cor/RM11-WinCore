# CarX Native v11 — بنية حقول Mesh الفعلية

حالة المصدر: تقرير v10: 25 + 20 + 20 كائن Unity SerializedFile v22 من ثلاث AssetBundles لشيفرات Windows. أسماء mesh `spokes`, `rim`, `cap`، واسم GameObject `EnkeiApache2`. هذه ليست أصول Android مجهزة للتشغيل.

التحسين الجديد: قراءة TypeTree nodes بطول 32 بايت، الاحتفاظ بالعمق، قياس الحقل، اسم ونوع الحقل (إذا كان النص داخل البايتات المحلية)، وتوثيق إزاحات common string table غير المتاحة بالأرقام من دون التخمين. تحفظ بصمة FNV64 لبنية TypeTree، وتبقى PathID نصاً عشرياً دقيقاً.

الأدلة المطلوبة من v11 على الهاتف: `type_tree_inspection.status=PASS_BOUNDED_TYPETREE_NODES`، ومعلومات Mesh (`class_id:43`) وMaterial (`class_id:21`) من النسخة الحقيقية، ودقة PathID. الهدف الذي يليها فك vertex/index streams للمجسم من نفس المصدر بشكل مدقق مع اختبارات خصائص بيانات حقيقية.

لا يجوز وصف هذه المرحلة بأنها إعادة ترجمة IL2CPP كاملة أو تشغيل اللعبة أو برهان قابلية AssetBundle للبناء على Android.
