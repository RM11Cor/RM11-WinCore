# RM11 WinCore V2.2.8 — هوية البناء وفحص تشغيل wineserver

- رقم التطبيق: `versionName=2.2.8`, `versionCode=35`.
- إضافة ختم واضح في واجهة القسم 22: `RM11_CORE_SOURCE_2_2_8`، وختم مستقل في تقرير تنفيذ Windows PE.
- اختبار مستقل لمسار `wineserver` الفعلي قبل تشغيل Wine. يرجع `RM11_WINESERVER_BRIDGE_SELFTEST_OK` من ARM64 APK helper دون بدء Wine.
- في حال فشل فحص المساعد يتوقف اختبار Wine بأسباب واضحة، دون تكرار SIGABRT غير المشخص.
- فحص CI يرفض APK إن اختلف الإصدار المبني عن هوية السورس في DEX.
- لا توجد تغييرات تعطل فحص أمان heap في أندرويد أو تدعي إصلاح كل مشاكل Wine/Box64.

**حدود هذا الإصدار:** هذه تعديلات تشخيص وفصل مشاكل البناء والتشغيل. لا يوجد APK مبني أو اختبار على REDMAGIC 11 Pro داخل هذه البيئة. ظهور `Exit code:0` مع `Win32 marker verified:YES` فقط هو إثبات نجاح اختبار Windows PE المحدود.

**رفع الملفات:** ارفع ZIP `RM11-WinCore-v2.2.8-source.zip` نفسه إلى جذر المستودع مثل الإصدارات السابقة، وليس مجلداً مفكوكاً. GitHub Actions الحالي يختار اسم أعلى ZIP بواسطة `sort -V`. إن أردت تشغيل workflow المحسن المضمن في السورس، استبدل ملف `.github/workflows/build-apk.yml` أيضاً من داخل ZIP، وإلا يظل فحص السورس يعمل في `scripts-check.py`.
