#!/usr/bin/env python3
"""CI guard against a versionName-only bump with stale Java/Dex code."""
import json, pathlib, sys, zipfile
if len(sys.argv)!=3:
    raise SystemExit('usage: check_runtime_identity_228.py app-debug.apk output-metadata.json')
apk, metadata = map(pathlib.Path,sys.argv[1:])
meta=json.loads(metadata.read_text())
assert meta['elements'][0]['versionName']=='2.2.8', 'APK output metadata is not V2.2.8'
assert meta['elements'][0]['versionCode']==35, 'APK versionCode is not 35'
with zipfile.ZipFile(apk) as z:
    dexes=[z.read(n) for n in z.namelist() if n.startswith('classes') and n.endswith('.dex')]
    assert dexes,'No DEX in APK'
    joined=b''.join(dexes)
    for expected in (b'RM11_CORE_SOURCE_2_2_8',b'RM11 WinCore V2.2.8',b'RM11_WINESERVER_BRIDGE_SELFTEST_OK'):
        if expected==b'RM11_WINESERVER_BRIDGE_SELFTEST_OK':
            # Marker is emitted by native C helper, not Java. Java side expects it.
            pass
        assert expected in joined, 'Version/source/bridge selftest missing from compiled DEX: '+repr(expected)
print('PASS: built APK metadata, DEX source marker and V2.2.8 runtime code agree')
