# RM11 AutoCore v2.4.1: generic, read-only game identification

- No list of known game titles or executable names in the production detector.
- Scans the user-selected Android SAF tree, not the entire device.
- Ranks plausible EXE launch targets structurally; ignores obvious redistributables/installers/crash handlers.
- Reads RT_VERSION in the Windows PE `.rsrc` section, if the provider supports seekable reads, without downloading/copying the whole EXE.
- Prefers `ProductName`, then `FileDescription`, then a clearly labelled inference from EXE or folder name.
- Reports PE product version separately from actual game version (not necessarily identical).
- Marks uncertainty and partial scans; no false claims of verified game identity or compatibility.
- Does not execute EXE, download remote code, or change game files.
- Steam DLL and other launcher signals are only hints; not proof of entitlements or required launcher.
- Profiles are stored locally in application-private storage; the game's original location is unchanged.
- Windows runtime, auto-tuning, binary import analysis, online store identification and download manager are future work.

## Build
Keep the ZIP archive in repository root as `RM11-WinCore-v2.4.1-source.zip` to use the repository's existing `build-apk.yml` workflow (which selects the newest versioned ZIP). Never delete previous versions without explicit permission.
