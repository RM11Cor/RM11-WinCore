package com.rm11.autocore;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Generic, read-only game-folder inference. No hardcoded game titles or game-specific mappings. */
public final class GameDetector {
    private GameDetector() { }

    public static final class Entry {
        public final String path;
        public final boolean directory;
        public final long size;
        public final String productName;
        public final String fileDescription;
        public final String productVersion;
        public Entry(String path, boolean directory) { this(path, directory, -1, "", "", ""); }
        public Entry(String path, boolean directory, long size) { this(path, directory, size, "", "", ""); }
        public Entry(String path, boolean directory, long size, String productName,
                     String fileDescription, String productVersion) {
            this.path = path == null ? "" : path.replace('\\', '/');
            this.directory = directory;
            this.size = size;
            this.productName = clean(productName);
            this.fileDescription = clean(fileDescription);
            this.productVersion = clean(productVersion);
        }
    }

    public static final class Detection {
        public final String title, gameId, exe, graphics, platform, certainty, version;
        public final List<String> evidence;
        public final int scannedCount;
        public final boolean truncated;
        Detection(String title, String gameId, String exe, String graphics, String platform,
                  String certainty, String version, List<String> evidence, int scannedCount, boolean truncated) {
            this.title = title;
            this.gameId = gameId;
            this.exe = exe;
            this.graphics = graphics;
            this.platform = platform;
            this.certainty = certainty;
            this.version = version;
            this.evidence = Collections.unmodifiableList(new ArrayList<>(evidence));
            this.scannedCount = scannedCount;
            this.truncated = truncated;
        }
    }

    private static final Pattern NON_GAME_EXECUTABLE = Pattern.compile(
            "(?i)^(?:unins\\d*|uninstall|install|setup|dxsetup|vcredist(?:_x(?:64|86))?|vc_redist.*|"
            + "unitycrashhandler(?:32|64)?|crash(?:handler|reporter|reportclient).*|"
            + "easyanticheat.*|eaclauncher|epicwebhelper|steam(?:service|webhelper|errorreporter)|"
            + "ubisoftconnect|eadesktop|eaapp|origin|redist.*|prereq.*|updater|"
            + "bugreport.*|.*_crashhandler|.*_helper|.*-win64-shipping-helper)\\.exe$");
    private static final Pattern GENERIC_NAME = Pattern.compile(
            "(?i)^(?:game|game-win64-shipping|game-win32-shipping|ue4game|unreal|unity|"
            + "launcher|start|client|win64|shipping|application|project|my project|windows|"
            + "app|bootstrapper|projectname|test|main)$");

    private static String clean(String x) {
        if (x == null) return "";
        return x.replace('\u0000', ' ').replaceAll("\\s+", " ").trim();
    }
    private static String basename(String path) {
        int p = path.lastIndexOf('/');
        return path.substring(p + 1);
    }
    private static String stem(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }
    private static String parent(String path) {
        int p = path.lastIndexOf('/');
        return p <= 0 ? "" : path.substring(0, p);
    }
    private static String normalTitle(String raw) {
        String s = clean(stem(raw));
        s = s.replaceAll("(?i)(?:-win64-shipping|-win32-shipping|_win64|_win32|_shipping)$", "");
        s = s.replace('_', ' ').replace('-', ' ').replace('.', ' ');
        s = s.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        s = s.replaceAll("(?<=[a-zA-Z])(?=\\d)", " ");
        s = s.replaceAll("(?<=\\d)(?=[a-zA-Z])", " ");
        return clean(s);
    }
    private static boolean meaningful(String x) {
        String s = clean(x);
        return s.length() >= 3 && s.length() <= 120 && !GENERIC_NAME.matcher(s).matches()
                && !s.equalsIgnoreCase("Microsoft Windows") && !s.equalsIgnoreCase("Unity Player")
                && !s.equalsIgnoreCase("Unreal Engine") && !s.equalsIgnoreCase("Executable")
                && !s.toLowerCase(Locale.ROOT).contains("unreal engine");
    }
    private static boolean looksLikeGameExe(Entry e) {
        String name = basename(e.path);
        if (e.directory || !name.toLowerCase(Locale.ROOT).endsWith(".exe")) return false;
        if (NON_GAME_EXECUTABLE.matcher(name).matches()) return false;
        String p = e.path.toLowerCase(Locale.ROOT);
        return !p.contains("/redist/") && !p.contains("/_commonredist/")
                && !p.contains("/redistributables/") && !p.contains("/installer/")
                && !p.contains("/support/software/") && !p.contains("/directx/");
    }
    private static int score(Entry e, List<Entry> all) {
        String lower = e.path.toLowerCase(Locale.ROOT);
        String rawStem = stem(basename(e.path));
        int slash = e.path.length() - e.path.replace("/", "").length();
        int score = 70 - 6 * Math.min(slash, 6);
        if (meaningful(e.productName)) score += 120;
        if (meaningful(e.fileDescription)) score += 45;
        if (meaningful(normalTitle(rawStem))) score += 25;
        else score -= 45;
        if (e.size > 1_000_000) score += 12;
        if (e.size >= 0 && e.size < 200_000) score -= 15;
        if (lower.contains("/engine/binaries/")) score -= 55;
        if (lower.contains("/binaries/win64/")) score += 18;
        if (lower.contains("/tools/") || lower.contains("/thirdparty/")) score -= 35;
        String normalized = stem(basename(lower));
        for (Entry other : all) {
            String otherPath = other.path.toLowerCase(Locale.ROOT);
            if (other.directory && otherPath.endsWith(normalized + "_data")) score += 30;
            if (otherPath.endsWith("/" + normalized + "_data/globalgamemanagers")) score += 25;
        }
        return score;
    }
    /** Candidate EXEs, ordered by structural likelihood, NOT by a list of known games. */
    public static List<Entry> candidates(List<Entry> entries, int limit) {
        if (entries == null || limit <= 0) return Collections.emptyList();
        List<Entry> result = new ArrayList<>();
        for (Entry e : entries) if (e != null && looksLikeGameExe(e)) result.add(e);
        result.sort(Comparator.comparingInt((Entry e) -> score(e, entries)).reversed()
                .thenComparing(e -> e.path));
        if (result.size() > limit) return new ArrayList<>(result.subList(0, limit));
        return result;
    }
    private static boolean has(List<Entry> entries, String target) {
        for (Entry e : entries) {
            if (e.directory) continue;
            String p = e.path.toLowerCase(Locale.ROOT);
            if (p.equals(target) || p.endsWith("/" + target)) return true;
        }
        return false;
    }
    private static boolean partial(List<Entry> entries, String fragment) {
        for (Entry e : entries)
            if (!e.directory && e.path.toLowerCase(Locale.ROOT).contains(fragment)) return true;
        return false;
    }
    private static String idFor(String title) {
        String s = Normalizer.normalize(title.toLowerCase(Locale.ROOT), Normalizer.Form.NFKD)
                .replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        return s.isEmpty() ? "unresolved" : s;
    }
    public static Detection analyze(List<Entry> entries, boolean truncated) {
        if (entries == null) entries = Collections.emptyList();
        List<String> evidence = new ArrayList<>();
        List<Entry> matches = candidates(entries, 2);
        String title = "لعبة غير معروفة", id = "unresolved", exe = "";
        String certainty = "غير محدد", version = "غير محدد";
        if (!matches.isEmpty()) {
            Entry main = matches.get(0);
            exe = main.path;
            String best = "";
            if (meaningful(main.productName)) {
                best = main.productName;
                certainty = "مرتفع: بيانات ProductName داخل ملف EXE";
                evidence.add("اسم المنتج من بيانات EXE: " + best);
            } else if (meaningful(main.fileDescription)) {
                best = main.fileDescription;
                certainty = "متوسط: وصف ملف EXE";
                evidence.add("وصف من بيانات EXE: " + best);
            } else if (meaningful(normalTitle(basename(exe)))) {
                best = normalTitle(basename(exe));
                certainty = "متوسط/منخفض: اسم ملف التشغيل (استنتاج)";
                evidence.add("اسم مستنتج من EXE، وليس تأكيد هوية: " + best);
            } else {
                String dirName = basename(parent(exe));
                if (meaningful(normalTitle(dirName))) {
                    best = normalTitle(dirName);
                    certainty = "منخفض: اسم مجلد اللعبة (استنتاج)";
                    evidence.add("اسم مستنتج من المجلد: " + best);
                }
            }
            if (!best.isEmpty()) { title = best; id = idFor(title); }
            if (!main.productVersion.isEmpty()) {
                version = main.productVersion;
                evidence.add("إصدار ملف EXE المعلن: " + version + " (قد يختلف عن إصدار اللعبة)");
            }
            evidence.add("مرشح التشغيل الأول: " + exe);
            if (matches.size() > 1) evidence.add("توجد ملفات EXE إضافية؛ يجب تأكيد ملف التشغيل إذا كان الاختيار خاطئاً");
        } else evidence.add("لم يُعثر على ملف تشغيل مناسب ضمن العناصر التي تمت قراءتها");
        String platform = "غير معروف؛ لا يمكن الجزم بأنها مستقلة";
        if (has(entries, "steam_appid.txt") || partial(entries, "appmanifest_")) {
            platform = "Steam (قرينة؛ لا تثبت الترخيص أو وجوب تشغيل Steam)";
            evidence.add("ملف تعريف Steam محتمل");
        } else if (has(entries, "steam_api64.dll") || has(entries, "steam_api.dll")) {
            platform = "Steam (احتمال ضعيف؛ وجود DLL لا يثبت الاعتماد على Steam)";
        } else if (has(entries, "upc_r2_loader.dll") || partial(entries, "uplay_r1_loader")) {
            platform = "Ubisoft Connect (احتمال)";
        } else if (has(entries, "socialclub.dll") || has(entries, "socialclub64.dll")) {
            platform = "Rockstar Games Launcher (احتمال)";
        } else if (has(entries, "originclient.dll") || partial(entries, "eaappinstaller")) {
            platform = "EA app (احتمال)";
        }
        // Never infer DirectX support from a title or an unrelated DLL name.
        String graphics = "غير محدد؛ يحتاج تحليل imports أو اختبار تشغيل";
        if (truncated) evidence.add("الفحص غير شامل؛ قد توجد ملفات لم تُقرأ");
        evidence.add("لا توجد إعدادات Proton/FEX/VKD3D/Turnip معتمدة قبل اختبار التوافق");
        return new Detection(title, id, exe, graphics, platform, certainty, version,
                evidence, entries.size(), truncated);
    }
}
