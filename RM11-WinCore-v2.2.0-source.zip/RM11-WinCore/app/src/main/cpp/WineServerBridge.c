/* Standalone Android ARM64 PIE (packed as lib*.so for APK extraction).
 * Executed ONLY as a wineserver helper by Wine, then execs trusted Box64 and
 * the packaged Wine wineserver64. No shell, root, network, or arbitrary args.
 */
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    const char *server = getenv("RM11_WINESERVER64_PATH");
    if (!server || server[0] != '/' || strstr(server, "wineserver64") == NULL) {
        fputs("RM11: trusted wineserver path missing\n", stderr);
        return 91;
    }
    char own[PATH_MAX];
    ssize_t n=readlink("/proc/self/exe",own,sizeof(own)-1);
    if (n<=0 || n >= (ssize_t)sizeof(own)-1) return 92;
    own[n]=0;
    char *slash=strrchr(own,'/');
    if (!slash) return 93;
    *(slash+1)=0;
    char box[PATH_MAX];
    int size=snprintf(box,sizeof(box),"%slibrm11box64.so",own);
    if (size<0 || size >= (int)sizeof(box)) return 94;
    if (access(box,X_OK)!=0 || access(server,R_OK)!=0) {
        fputs("RM11: Box64 or wineserver64 missing\n",stderr);
        return 95;
    }
    char **next=(char**)calloc((size_t)argc+2,sizeof(char*));
    if (!next) return 96;
    next[0]=box;
    next[1]=(char*)server;
    for (int i=1;i<argc;i++) next[i+1]=argv[i];
    execv(box,next);
    fprintf(stderr,"RM11 wineserver bridge exec failed: %s\n",strerror(errno));
    return 97;
}
