#!/usr/bin/env python3
"""Offline tests for Windows PE staging + exact Windows PE result classification.
No Android or Wine execution is claimed by these host checks.
"""
from pathlib import Path
import importlib.util
import hashlib
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('v22',ROOT/'tools/package_wine_exe_v22.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
source=ROOT/'app/src/main/assets/wine_exe_v22'
pe=(source/'rm11_probe.exe').read_bytes()
from build_v22_pe_guest import audit
assert audit(pe)==(source/'PE-SHA256.txt').read_text().strip()

with tempfile.TemporaryDirectory(prefix='rm11-v22-test-') as td:
    t=Path(td);mod.OUT=t/'out';mod.OUT.mkdir()
    mod.V21=t/'wine21';mod.V21.mkdir()
    version='9.0~rm11-synthetic'
    (mod.V21/'COMPONENTS.tsv').write_text('Version: '+version+'\n')
    package=t/'libwine'
    (package/'DEBIAN').mkdir(parents=True)
    (package/'DEBIAN/control').write_text(f'Package: libwine\nVersion: {version}\nArchitecture: amd64\nMaintainer: RM11 Test\nDescription: Synthetic fixtures only\n')
    notice=package/'usr/share/doc/libwine/copyright';notice.parent.mkdir(parents=True);notice.write_text('TEST ONLY\n')
    for item in mod.REQUIRED + ('user32.dll',):
        rel=mod.WIN+item
        dest=package/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(pe)
    deb=t/'libwine.deb'
    subprocess.run(['dpkg-deb','--build',str(package),str(deb)],check=True,stdout=subprocess.DEVNULL)
    mod.package(deb)
    manifest=(mod.OUT/'WINDOWS-COMPONENTS.tsv').read_text()
    for item in mod.REQUIRED + ('user32.dll',):
        rel=mod.WIN+item
        assert rel+'\t'+hashlib.sha256(pe).hexdigest()+'\t'+str(len(pe)) in manifest
    assert (mod.OUT/'LIBWINE-COPYRIGHT.txt').is_file()
    (mod.V21/'COMPONENTS.tsv').write_text('Version: 0.0-mismatch\n')
    try:mod.package(deb)
    except ValueError as e:assert 'does not match' in str(e)
    else: raise AssertionError('Version mismatch was accepted')
    (mod.V21/'COMPONENTS.tsv').write_text('Version: '+version+'\n')
    bad=t/'invalid'
    (bad/'DEBIAN').mkdir(parents=True)
    (bad/'DEBIAN/control').write_text(f'Package: libwine\nVersion: {version}\nArchitecture: arm64\nMaintainer: RM11 Test\nDescription: Wrong arch\n')
    subprocess.run(['dpkg-deb','--build',str(bad),str(t/'wrong.deb')],check=True,stdout=subprocess.DEVNULL)
    try:mod.package(t/'wrong.deb')
    except ValueError as e:assert 'amd64' in str(e)
    else:raise AssertionError('Wrong Wine package architecture accepted')

    for directory in ('android/content/res','android/content/pm','android/os','com/rm11/wincore'):
        (t/directory).mkdir(parents=True,exist_ok=True)
    (t/'android/content/Context.java').write_text('package android.content;import java.io.File;import android.content.res.AssetManager;import android.content.pm.ApplicationInfo;public class Context { public File getCacheDir(){return null;} public File getFilesDir(){return null;} public AssetManager getAssets(){return null;} public ApplicationInfo getApplicationInfo(){return null;}}')
    (t/'android/content/res/AssetManager.java').write_text('package android.content.res;import java.io.*;public class AssetManager { public InputStream open(String p) throws IOException{return null;}}')
    (t/'android/content/pm/ApplicationInfo.java').write_text('package android.content.pm;public class ApplicationInfo{public String nativeLibraryDir;}')
    (t/'android/os/Build.java').write_text('package android.os;public class Build{public static String[] SUPPORTED_ABIS={"arm64-v8a"};}')
    (t/'com/rm11/wincore/WineFirstExeV22Test.java').write_text('''package com.rm11.wincore;
public class WineFirstExeV22Test {
  static void ck(boolean v){if(!v)throw new AssertionError();}
  public static void main(String[] args){
    String root="usr/lib/x86_64-linux-gnu/wine/x86_64-windows/";
    String sha="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    StringBuilder s=new StringBuilder("Version: 9.0\\n");
    for(String x:new String[]{"kernel32.dll","kernelbase.dll","wineboot.exe"})s.append(root+x).append("\\t").append(sha).append("\\t1024\\n");
    ck(WineFirstExeV22.parseManifest(s.toString()).size()==3);
    try{WineFirstExeV22.parseManifest(s.toString().replace("kernelbase.dll","../bad.dll"));throw new AssertionError();}catch(IllegalArgumentException expected){}
    try{WineFirstExeV22.parseManifest(s.toString().replace("wineboot.exe","fake.exe"));throw new AssertionError();}catch(IllegalArgumentException expected){}
    ck(WineFirstExeV22.classify(0,false,true,"").contains("[PASS WINDOWS EXE]"));
    ck(WineFirstExeV22.classify(0,false,false,"").contains("[NOT PROVEN]"));
    ck(!WineFirstExeV22.classify(0,false,false,"wine-9.0").contains("[PASS WINDOWS EXE]"));
    ck(WineFirstExeV22.classify(1,false,false,"wineserver: failed to start").contains("[BLOCKED]"));
    ck(WineFirstExeV22.classify(-1,true,true,"").contains("[TIMEOUT]"));
    System.out.println("PASS: V2.2 Java PE smoke checks and false-positive prevention");
  }
}''')
    android=list((t/'android').rglob('*.java'))
    java=list((t/'com').rglob('*.java'))
    src=ROOT/'app/src/main/java/com/rm11/wincore'
    java.extend([src/'WineFirstExeV22.java',src/'WineRuntimeV21.java',src/'WineLoaderV20.java'])
    subprocess.run(['javac','-encoding','UTF-8','-d',str(t/'outjava'),*[str(p) for p in android+java]],check=True)
    subprocess.run(['java','-cp',str(t/'outjava'),'com.rm11.wincore.WineFirstExeV22Test'],check=True)
print('PASS: V2.2 matched Wine Windows DLL packaging + first-party PE integrity + Java host checks')
