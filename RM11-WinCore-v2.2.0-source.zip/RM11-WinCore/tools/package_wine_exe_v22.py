#!/usr/bin/env python3
"""Stage a controlled subset of Ubuntu Wine PE DLLs for an offline Win64 probe.

This is NOT a complete Wine prefix/rootfs and is NOT a general game launcher.
The libwine package must match the exact version staged for V2.1.4.
"""
from pathlib import Path
import argparse
import hashlib
import shutil
import subprocess
import sys
import tempfile
from build_v22_pe_guest import audit
from package_wine_runtime_v21 import validate_elf, validate_pe64

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'app/src/main/assets/wine_exe_v22'
V21=ROOT/'app/src/main/assets/wine_runtime_v21'
WIN='usr/lib/x86_64-linux-gnu/wine/x86_64-windows/'
UNIX='usr/lib/x86_64-linux-gnu/wine/x86_64-unix/'
# Core modules are required; optional Wine components are included when present.
REQUIRED=('kernel32.dll','kernelbase.dll','wineboot.exe')
OPTIONAL=('advapi32.dll','sechost.dll','rpcrt4.dll','msvcrt.dll','ucrtbase.dll',
          'user32.dll','gdi32.dll','win32u.dll','ws2_32.dll','bcrypt.dll',
          'shell32.dll','ole32.dll','oleaut32.dll','imm32.dll','shlwapi.dll',
          'version.dll','setupapi.dll','winhttp.dll','wininet.dll')
OPTIONAL_UNIX=('win32u.so',)
MAX_FILE=32*1024*1024

def package(libwine_deb):
    from subprocess import check_output
    deb=Path(libwine_deb)
    if check_output(['dpkg-deb','-f',str(deb),'Package'],text=True).strip()!='libwine' or check_output(['dpkg-deb','-f',str(deb),'Architecture'],text=True).strip()!='amd64':
        raise ValueError('Expected Ubuntu amd64 libwine .deb')
    version=check_output(['dpkg-deb','-f',str(deb),'Version'],text=True).strip()
    stage_manifest=(V21/'COMPONENTS.tsv')
    if not stage_manifest.is_file() or ('Version: '+version+'\n') not in stage_manifest.read_text():
        raise ValueError('V2.2 libwine version does not match V2.1.4 Wine runtime')
    with tempfile.TemporaryDirectory(prefix='rm11-v22-extract-') as td:
        root=Path(td)
        subprocess.run(['dpkg-deb','-x',str(deb),str(root)],check=True)
        if not (root/'usr/share/doc/libwine/copyright').is_file():
            raise ValueError('Missing libwine package copyright')
        records=['# RM11 V2.2 matched Wine Windows PE test assets', 'Version: '+version,
                 'Use: only built-in RM11 Windows PE test; arbitrary EXE not supported',
                 '# path<TAB>sha256<TAB>size']
        for name in REQUIRED + OPTIONAL + OPTIONAL_UNIX:
            rel=(UNIX if name.endswith('.so') else WIN)+name
            src=root/rel
            if not src.is_file():
                if name in REQUIRED: raise ValueError('Required Windows Wine component absent: '+rel)
                continue
            raw=src.read_bytes()
            if not 512 <= len(raw) <= MAX_FILE: raise ValueError('Excessive/malformed PE library: '+rel)
            if name.endswith('.so'): validate_elf(raw)
            else: validate_pe64(raw)
            dest=OUT/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(raw)
            records.append(rel+'\t'+hashlib.sha256(raw).hexdigest()+'\t'+str(len(raw)))
        (OUT/'WINDOWS-COMPONENTS.tsv').write_text('\n'.join(records)+'\n',encoding='utf-8')
        (OUT/'LIBWINE-COPYRIGHT.txt').write_bytes((root/'usr/share/doc/libwine/copyright').read_bytes())
        print('PASS V2.2 wine modules included:',len(records)-4,', from matched libwine',version)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--libwine-deb',type=Path)
    p.add_argument('--required',action='store_true')
    a=p.parse_args()
    try:
        if a.libwine_deb: package(a.libwine_deb)
        else:
            with tempfile.TemporaryDirectory(prefix='rm11-v22-apt-') as td:
                subprocess.run(['apt-get','download','libwine'],cwd=td,timeout=400,check=True)
                pkg=list(Path(td).glob('libwine_*_amd64.deb'))
                if len(pkg)!=1: raise ValueError('Expected one matching Ubuntu libwine package')
                package(pkg[0])
    except (ValueError,OSError,subprocess.SubprocessError) as e:
        print('V2.2 WINE PE NOT PACKAGED: '+str(e),file=sys.stderr)
        if a.required: raise SystemExit(1)

if __name__=='__main__':main()
