#!/usr/bin/env python3
"""Optional EXPERIMENTAL build of upstream Box64 as an Android arm64 executable.

Downloads pinned *upstream* MIT-licensed sources on CI. DOES NOT run x86/Windows
code or fetch arbitrary APK packages. A failed experiment leaves the existing
RM11 APK working and leaves no fake Box64 placeholder in the package.
"""
from pathlib import Path
import argparse
import os
import shutil
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / 'app/src/main/jniLibs/arm64-v8a/librm11box64.so'
LICENSE = ROOT / 'app/src/main/assets/third_party/box64/LICENSE.txt'
PATCH_RECEIPT = ROOT / 'app/src/main/assets/third_party/box64/RM11-STARTUP-PATCH.txt'
# Official Box64 v0.4.4 release, pin the actual commit too to detect moved tags.
UPSTREAM = 'https://github.com/ptitSeb/box64.git'
TAG = 'v0.4.4'
COMMIT = '2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a'
NDK = '27.2.12479018'


def find_compiler():
    roots = []
    for env in ('RM11_NDK_HOME', 'ANDROID_NDK_HOME'):
        if os.environ.get(env):
            roots.append(Path(os.environ[env]))
    for env in ('ANDROID_HOME', 'ANDROID_SDK_ROOT'):
        if os.environ.get(env):
            roots.append(Path(os.environ[env]) / 'ndk' / NDK)
    roots.append(Path.home() / 'Android/Sdk/ndk' / NDK)
    for root in roots:
        compiler = root / 'toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android31-clang'
        if compiler.is_file():
            return compiler
    return None


def verify_android_pie(path):
    """Only AArch64 dynamic PIE with Android linker is accepted for APK packaging."""
    with open(path, 'rb') as f:
        header = f.read(64)
        if len(header) != 64 or header[:6] != b'\x7fELF\x02\x01':
            raise RuntimeError('Not 64-bit little endian ELF')
        typ, machine = struct.unpack_from('<HH', header, 16)
        if typ != 3 or machine != 183:
            raise RuntimeError('Expected AArch64 ET_DYN PIE executable')
        phoff = struct.unpack_from('<Q', header, 32)[0]
        phsize = struct.unpack_from('<H', header, 54)[0]
        phnum = struct.unpack_from('<H', header, 56)[0]
        file_size = Path(path).stat().st_size
        if phsize < 56 or not 1 <= phnum <= 128 or phoff + phsize * phnum > file_size:
            raise RuntimeError('Corrupt/oversized ELF program headers')
        interp = None
        for i in range(phnum):
            f.seek(phoff + i * phsize)
            ph = f.read(56)
            if struct.unpack_from('<I', ph)[0] == 3:  # PT_INTERP
                offset, length = struct.unpack_from('<QQ', ph, 8)[0], struct.unpack_from('<Q', ph, 32)[0]
                if not 1 <= length <= 128 or offset + length > file_size:
                    raise RuntimeError('Invalid PT_INTERP')
                f.seek(offset)
                interp = f.read(length).rstrip(b'\0')
                break
        if interp != b'/system/bin/linker64':
            raise RuntimeError('Android /system/bin/linker64 required; glibc Linux build rejected')


def run(cmd, *, cwd=None, timeout=600):
    print('$', ' '.join(map(str, cmd)), flush=True)
    subprocess.run([str(x) for x in cmd], cwd=cwd, check=True, timeout=timeout)


def patch_android_glibc_startup(source):
    """V1.8 trial: expose BOTH bionic __libc_init and Box64's glibc CRT hook.

    Box64 v0.4.4 src/emu/entrypoint.c currently has these functions in
    mutually-exclusive ANDROID/#else branches. Its wrappedlibc_private.h
    nevertheless advertises __libc_start_main for Android, producing a missing
    my___libc_start_main at runtime. This tightly-pinned experiment leaves
    the upstream implementations intact; it does not emulate a Linux loader.
    """
    target = Path(source) / 'src/emu/entrypoint.c'
    before = target.read_text(encoding='utf-8')
    needle = '\n#else\nEXPORT int32_t my___libc_start_main('
    replacement = ('\n#endif\n#if 1 /* RM11-V1.8: include glibc startup on Android alongside bionic startup */\n'
                   'EXPORT int32_t my___libc_start_main(')
    if before.count(needle) != 1 or 'RM11-V1.8' in before:
        raise RuntimeError('Pinned Box64 startup source no longer matches expected v0.4.4 layout')
    if 'GOM(__libc_start_main, iFEpippppp)' not in (Path(source)/'src/wrapped/wrappedlibc_private.h').read_text(encoding='utf-8'):
        raise RuntimeError('Upstream libc wrapper contract changed: refuse unsafe patch')
    if '#ifdef ANDROID' not in before or 'my___libc_init' not in before:
        raise RuntimeError('Expected Android libc entrypoint missing')
    target.write_text(before.replace(needle, replacement, 1), encoding='utf-8')
    print('RM11 V1.8: Android bionic startup retained; Box64 glibc CRT bridge additionally compiled')



def patch_android_errno_bridge(source):
    """V2.1.3 EXPERIMENTAL: bridge glibc errno pointer to Android Bionic TLS.

    Upstream Box64 v0.4.4 libc wrapper registers __errno_location as a
    direct native symbol. Android's Bionic libc exports __errno() instead,
    leaving glibc x86-64 guests with an unresolved __errno_location.
    Only change this exact pinned signature, and generate a Box64 wrapped
    callback returning the caller thread's &errno, never a global integer.
    """
    source = Path(source)
    priv = source / 'src/wrapped/wrappedlibc_private.h'
    impl = source / 'src/wrapped/wrappedlibc.c'
    prev_private = priv.read_text(encoding='utf-8')
    prev_impl = impl.read_text(encoding='utf-8')
    old = 'GO(__errno_location, pFv)'
    new = 'GOM(__errno_location, pFEv)'
    if prev_private.count(old) != 1 or new in prev_private:
        raise RuntimeError('Pinned Box64 libc errno wrapper contract changed; refusing patch')
    anchor = '#include "generated/wrappedlibctypes.h"'
    if prev_impl.count(anchor) != 1 or 'RM11-V2.1.3-ERRNO' in prev_impl:
        raise RuntimeError('Pinned Box64 wrappedlibc.c insertion point changed; refusing patch')
    bridge = '''
/* RM11-V2.1.3-ERRNO: return the thread-local host errno pointer.
 * On Bionic, errno is a macro resolving through __errno(), unlike glibc's
 * __errno_location(). This is a small ABI experiment, NOT full glibc. */
EXPORT void* my___errno_location(x64emu_t* emu)
{
    (void)emu;
    return (void*)&errno;
}

'''
    priv.write_text(prev_private.replace(old, new, 1), encoding='utf-8')
    impl.write_text(prev_impl.replace(anchor, anchor + '\n' + bridge, 1), encoding='utf-8')
    print('RM11 V2.1.3: Android libc __errno_location guest wrapper now bridges to per-thread Bionic errno')

def patch_android_glibc_misc_bridges(source):
    """V2.1.4 experiment: resolve two GLIBC symbols absent from Android Bionic.

    Bionic exposes getdelim, but not the GNU-prefixed __getdelim alias.
    Its assert interface differs from glibc's __assert_fail. Keep the
    argument ordering, use Box64's FILE stream wrapper type S, and preserve
    normal glibc abort semantics. Does not imply Wine or full glibc support.
    """
    source = Path(source)
    priv = source / 'src/wrapped/wrappedlibc_private.h'
    impl = source / 'src/wrapped/wrappedlibc.c'
    old_private = priv.read_text(encoding='utf-8')
    old_impl = impl.read_text(encoding='utf-8')
    changes = {
        'GO(__assert_fail, vFppup)': 'GOM(__assert_fail, vFEppup)',
        'GOW(__getdelim, lFppiS)': 'GOM(__getdelim, lFEppiS)',
    }
    anchor = '#include "generated/wrappedlibctypes.h"'
    for old, new in changes.items():
        if old_private.count(old) != 1 or new in old_private:
            raise RuntimeError('Pinned Box64 missing exact glibc symbol definition: ' + old)
    if old_impl.count(anchor) != 1 or 'RM11-V2.1.4-GLIBC' in old_impl:
        raise RuntimeError('Pinned Box64 wrappedlibc.c insertion point changed; refusing patch')
    bridge = r'''
/* RM11-V2.1.4-GLIBC: Android Bionic compatibility experiment.
 * The GNU assert handler is absent as a native bionic libc export.
 * This is a noreturn handler; never claim that a failed assert succeeded. */
EXPORT void my___assert_fail(x64emu_t* emu, const char* expression,
                             const char* file, unsigned int line,
                             const char* function)
{
    (void)emu;
    fprintf(stderr, "Box64 guest assertion failed: %s (%s:%u, %s)\n",
            expression ? expression : "?", file ? file : "?", line,
            function ? function : "?");
    abort();
}

/* Android Bionic has getdelim() but not the glibc __getdelim alias.
 * Box64 wrapper signature uses S for the translated FILE* stream. */
EXPORT ssize_t my___getdelim(x64emu_t* emu, char** lineptr,
                              size_t* n, int delimiter, FILE* stream)
{
    (void)emu;
    return getdelim(lineptr, n, delimiter, stream);
}
'''
    updated_private = old_private
    for old, new in changes.items():
        updated_private = updated_private.replace(old, new, 1)
    priv.write_text(updated_private, encoding='utf-8')
    impl.write_text(old_impl.replace(anchor, anchor + '\n' + bridge, 1), encoding='utf-8')
    print('RM11 V2.1.4: GNU __assert_fail and __getdelim wrapped with Android Bionic-compatible functions')


def build(compiler):
    with tempfile.TemporaryDirectory(prefix='rm11-upstream-box64-') as tmp:
        source = Path(tmp) / 'box64'
        builddir = Path(tmp) / 'build'
        run(['git', 'clone', '--depth', '1', '--branch', TAG, UPSTREAM, source], timeout=180)
        sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
        if sha != COMMIT:
            raise RuntimeError('Upstream tag moved! Actual commit: ' + sha)
        patch_android_glibc_startup(source)
        patch_android_errno_bridge(source)
        patch_android_glibc_misc_bridges(source)
        run(['cmake', '-S', source, '-B', builddir,
             f'-DCMAKE_C_COMPILER={compiler}', '-DARM64=ON', '-DANDROID=ON',
             '-DARM_DYNAREC=ON', '-DBAD_SIGNAL=ON', '-DTERMUX=OFF',
             '-DHAVE_TRACE=OFF', '-DNOBOX64=OFF', '-DNOGIT=ON',
             '-DCMAKE_BUILD_TYPE=Release'], timeout=180)
        run(['cmake', '--build', builddir, '--target', 'box64', '--parallel', '2'], timeout=960)
        binary = builddir / 'box64'
        verify_android_pie(binary)
        if binary.stat().st_size > 80 * 1024 * 1024:
            raise RuntimeError('Unexpected huge Box64 executable')
        source_license = source / 'LICENSE'
        if 'MIT License' not in source_license.read_text(encoding='utf-8'):
            raise RuntimeError('Expected upstream MIT license missing')
        TARGET.parent.mkdir(parents=True, exist_ok=True)
        LICENSE.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(binary, TARGET)
        shutil.copy2(source_license, LICENSE)
        PATCH_RECEIPT.write_text('RM11 V1.8 trial: Box64 v0.4.4 pinned startup dual-entry patch applied at build.\n'
                                 'Source: src/emu/entrypoint.c; Android __libc_init retained; glibc __libc_start_main included.\n'
                                 'RM11 V2.1.3: libc errno wrapper patched via my___errno_location to Android TLS &errno.\n'
                                 'RM11 V2.1.4: glibc __assert_fail and __getdelim wrapper bridges added for Bionic.\n'
                                 'Build-time patch only; successful runtime behavior NOT guaranteed.\n', encoding='utf-8')
        print(f'PASS: genuine upstream Box64 {TAG} Android PIE packaged: {TARGET.stat().st_size} bytes')
        print('LIMIT: version probe ONLY, no Linux rootfs/Wine/x86 executable support guaranteed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--required', action='store_true',
                        help='Fail CI if experimental compilation fails')
    args = parser.parse_args()
    # Never leave an old binary from prior builds on disk on a failed experiment.
    TARGET.unlink(missing_ok=True)
    LICENSE.unlink(missing_ok=True)
    PATCH_RECEIPT.unlink(missing_ok=True)
    compiler = find_compiler()
    if compiler is None:
        print('SKIP: Android NDK unavailable. No upstream Box64 in this APK.')
        if args.required:
            raise SystemExit(2)
        return
    try:
        build(compiler)
    except (OSError, RuntimeError, subprocess.SubprocessError) as ex:
        TARGET.unlink(missing_ok=True)
        LICENSE.unlink(missing_ok=True)
        PATCH_RECEIPT.unlink(missing_ok=True)
        print('WARN: upstream Box64 Android experimental build failed:', ex, file=sys.stderr)
        print('The RM11 APK will still build, without Box64. Do NOT claim it was integrated.', file=sys.stderr)
        if args.required:
            raise


if __name__ == '__main__':
    main()
