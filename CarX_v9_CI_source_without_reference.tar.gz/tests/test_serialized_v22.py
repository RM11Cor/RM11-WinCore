"""Synthetic test assets ONLY. No actual CarX game assets distributed."""
import json, pathlib, struct, subprocess, tempfile, unittest, random
from test_unityfs_native import make_bundle
BASE=pathlib.Path(__file__).resolve().parents[1]


def le32(v):return struct.pack('<I',v)
def le64(v):return struct.pack('<Q',v)
def be32(v):return struct.pack('>I',v)
def be64(v):return struct.pack('>Q',v)

def build_v22(*,target=19,classes=(33,43), nobjects=3, data_size=128, typetree=True, bad_index=False, bad_bounds=False, tamper=None):
    # SerializedFile format 22, little-endian metadata, minimal valid inline TypeTrees.
    meta=bytearray(b'0.0.0\0'+le32(target)+bytes([int(typetree)])+le32(len(classes)))
    for cls in classes:
        meta+=le32(cls)+b'\0'+b'\xff\xff' + b'\xA5'*16
        if typetree:
            # One real-format v22 TypeTree node (32 bytes), and 10-byte string buffer.
            meta+=le32(1)+le32(10)
            meta+=(b'\x01\x00'+b'\0'*2+le32(0)+le32(1)+le32(0)+le32(0)+le32(0)+b'\0'*8)
            meta+=b'Mesh\x00Name\x00'
        meta+=le32(0) # 21+ type dependency count
    meta+=le32(nobjects)
    for i in range(nobjects):
        while (48+len(meta))%4:meta.append(0)
        start=0 if i==0 else i*8
        size=8 if not bad_bounds else data_size*4
        idx=len(classes)+9 if bad_index else (i%len(classes))
        meta+=le64(i+1)+le64(start)+le32(size)+le32(idx)
    meta+=le32(0)+le32(0)+le32(0)+b'\0' # scripts, externals, refs, userinfo
    data_offset=(48+len(meta)+15)&~15
    file_size=data_offset+data_size
    hdr=be32(0)+be32(0)+be32(22)+be32(0)+b'\0'*4+be32(len(meta))+be64(file_size)+be64(data_offset)+be64(0)
    blob=bytearray(hdr+meta+b'\0'*(data_offset-(48+len(meta)))+bytes((i*7)%256 for i in range(data_size)))
    if tamper is not None:tamper(blob)
    return bytes(blob)

class SerializedV22Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='carx_v9_synthetic_')
        cls.exe=pathlib.Path(cls.temp.name)/'probe'
        subprocess.run(['cc','-O1','-std=c11','-Wall','-Wextra','-Werror',
            str(BASE/'tests/unityfs_cli.c'),str(BASE/'app/src/main/cpp/unityfs_directory.c'),
            '-o',str(cls.exe)],check=True)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def inspect(self,content,split=None,lz4=0,at_end=False):
        b=make_bundle(content=content,split_at=split,data_kind=lz4,at_end=at_end)
        f=pathlib.Path(self.temp.name)/'t.bundle';f.write_bytes(b)
        r=subprocess.run([str(self.exe),str(f)],capture_output=True,text=True,check=True)
        return json.loads(r.stdout)['serialized_metadata_v22']
    def test_two_types_object_index(self):
        x=self.inspect(build_v22());self.assertEqual(x['status'],'PASS_V22_METADATA_OBJECT_INDEX')
        self.assertEqual(x['build_target'],19)
        self.assertEqual(x['build_target_name'],'StandaloneWindows64')
        self.assertEqual(x['type_count'],2)
        self.assertEqual(x['class_id_sample'],[33,43])
        self.assertEqual(x['object_count'],3)
        self.assertEqual(x['object_class_id_sample'],[33,43,33])
        self.assertTrue(x['type_tree_enabled'])
        self.assertFalse(x['android_asset_compatibility_proven'])
    def test_cross_block_lz4(self):
        a=build_v22();x=self.inspect(a,split=31,lz4=3)
        self.assertEqual(x['object_count'],3)
    def test_at_end_lz4(self):
        x=self.inspect(build_v22(),lz4=2,at_end=True)
        self.assertEqual(x['status'],'PASS_V22_METADATA_OBJECT_INDEX')
    def test_no_typetree(self):
        x=self.inspect(build_v22(typetree=False,classes=(43,),nobjects=1))
        self.assertEqual(x['type_count'],1);self.assertFalse(x['type_tree_enabled'])
    def test_android_platform_detects_but_not_proven(self):
        x=self.inspect(build_v22(target=13))
        self.assertEqual(x['build_target_name'],'OTHER_OR_UNKNOWN')
        self.assertFalse(x['android_asset_compatibility_proven'])
    def test_wrong_object_index(self):
        x=self.inspect(build_v22(bad_index=True))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_bad_bounds(self):
        x=self.inspect(build_v22(bad_bounds=True))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_declared_metadata_over_limit(self):
        def tamper(a): a[20:24]=be32(500000)
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_unsupported_v23(self):
        def tamper(a): a[8:12]=be32(23)
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'UNSUPPORTED_SERIALIZED_VERSION')
    def test_invalid_platform_header_endianness(self):
        def tamper(a):a[16]=3
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_fuzz_50(self):
        rnd=random.Random(81);original=bytearray(build_v22())
        for _ in range(50):
            a=original[:]
            idx=rnd.randrange(len(a));a[idx]^=rnd.randrange(1,256)
            x=self.inspect(bytes(a),lz4=3)
            self.assertIn(x['status'],{'PASS_V22_METADATA_OBJECT_INDEX','METADATA_PARSE_INCOMPLETE','UNSUPPORTED_SERIALIZED_VERSION'})
if __name__=='__main__':unittest.main(verbosity=2)
