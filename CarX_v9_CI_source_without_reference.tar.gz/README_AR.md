# CarX Native Foundation v9 — SerializedFile v22 Object Index (ARM64)

هذه حزمة اختبار تقني أصلية لأندرويد وليست لعبة CarX Street. لا تستعمل Wine أو FEX أو أي محاكي. الهدف هو قراءة بنية كائنات CAB من حزم Windows الخاصة باللعبة قراءةً فقط، وإظهار عدد الأنواع والكائنات وأصنافها من جداول Unity SerializedFile v22.

## ما أُنجز
- برنامج ARM64 + JNI + Vulkan Surface + AOT جزئي مقارنة 1024 سجل.
- قارئ UnityFS بحدود ذاكرة مع LZ4/LZ4HC وقراءة بيانات CAB عبر كتل افتراضية.
- تحليل بيانات v22: نوع المحتوى، BuildTarget، TypeTree، أنواع الكائنات، جدول الكائنات، والتحقق من حدود البيانات، مع رفض الميتاداتا المعيبة وتسجيل سبب الرفض.
- 46 اختباراً آلياً، و150 ملفاً معدلاً اصطناعياً عبر ASAN+UBSAN؛ كلّها محلية فقط. لم يثبت تحميل أي مشهد Unity أو تنفيذ اللعبة.

## التثبيت
اسم الحزمة الثابت `com.carx.nativefoundation.test.updates`. رقم البناء `900` أعلى من 801/800، ويتطلب نفس توقيع قناة v7/v8، وإلا لن يحدث فوقها. لا تحمل APK Debug المُخرج مباشرة من GitHub Actions؛ استخدم الإصدار الموقّع من GitHub Releases فقط.

افتح التطبيق على REDMAGIC واختر مجلد CarX الأصلي ثم `Run AOT + Vulkan GPU + file checks`، وبعدها صدّر `CarX_NativeFoundation_v9_Report.json` وارفعه.

## الحدود
تعرّف النظام على Windows BuildTarget من الترويسة، لكن لا يوجد Android Unity Player ولا IL2CPP runtime متكامل ولا تحويل للشيدرات أو أصل لعبة محمول مثبت. هذه حزمة فحص فقط وليست بورتاً قابلاً للعب.
