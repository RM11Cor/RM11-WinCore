# CarX Native Foundation v4 — Android native CPU / GPU proof

**هذا APK اختبار تقني وليس بورت CarX Street أو تشغيل لعبة.** لا يحتوي Wine، FEX، Windows loader أو أي EXE. مبني لأندرويد arm64-v8a.

## ما تحقق
- `CarX_NativeFoundation_v3_Termux.json` المرفوع من الهاتف أعطى `PASS_NATIVE_AOT_ONLY` (1024/1024 حالة)، ولكنه لم يبن APK ولم يقلع اللعبة.
- v4 يربط كود AArch64 الأصلّي الذي اختبرناه في v2.10 بجسر JNI داخل تطبيق Android ويقارنه بمرجع x86-64 أصلي من تعليمات GameAssembly.dll؛ يوقف قبل CALL/Jcc غير المترجمة.
- v4 يضيف **Android Vulkan device bring-up**: `vkCreateInstance`، تعداد GPUs، طابور رسوميات، فحص `VK_KHR_swapchain`، إنشاء `VkDevice` ثم إتلافه. هذا اختبار Vulkan حقيقي على الجهاز بعد بناء وتشغيل APK، وليس إنشاء نافذة أو swapchain أو رسم CarX.
- من خلال Storage Access Framework يختار المستخدم مجلد اللعبة الأصلي ويقرأ SHA256 الخاص بـGameAssembly.dll، رؤوس PE وUnityFS، ويعد ملفات `.bundle` تحت `StandaloneWindows64` ويحدد عدد UnityFS غير المطابق دون تعديل اللعبة.
- لا تسجل النتائج `game_boot_proven=true` إطلاقاً؛ غياب GPU أو عدم اختيار مجلد اللعبة يُعرض بوضوح.

## البناء على GitHub Actions
ارفع الملفات كمحتويات مشروع في جذر مستودع GitHub مخصص ثم شغّل `.github/workflows/build-native-foundation.yml`. البناء يولد مرجع x86 محلياً من **بايتات التعليمات الأصلية الموثّقة** في `tests/source_fixture/` على مشغّل x86-64، يحدّث بصمة مرجع Java ويختبر C، ثم يركب APK تجريبياً بـAndroid SDK 35/NDK 27/Gradle 8.10.2.

إخراج البناء هو `CarX-NativeFoundation-v4-CPU-Vulkan-TEST-NOT-GAME` وفيه `app-debug.apk` (إن نجحت CI). **لم تنفذ GitHub Actions هنا بعد، ولم ينتج APK في هذه البيئة** بسبب غياب Android SDK؛ لا تعتبر وجود workflow دليلاً على نجاح البناء.

## اختبار AOT الحالي مباشرة في Termux
```
unzip -o /sdcard/Download/CarX_NativeFoundation_v4.zip -d ~/carx_native_v4
bash ~/carx_native_v4/run_termux.sh
```
هذا **يعيد اختبار CPU فقط** وليس Vulkan GPU؛ Vulkan device proof يتطلب APK على الهاتف.

## اختبار APK بعد بناء ناجح
ثبّت `app-debug.apk`، افتح CarX Native Foundation v4، اختر المجلد الداخلي الذي يحتوي `GameAssembly.dll`، ثم شغّل `Run AOT + Vulkan GPU + file checks`. صدّر تقرير JSON وأرسله. نتائج `native_gpu_device_proven` و`platform_bundle_inventory` وحدها لا تثبت إمكان تحميل موارد Windows في Unity Android أو إقلاع اللعبة.

## العوائق الأساسية
لم يثبت وجود Android Unity Player/IL2CPP runtime متوافق مع البناء الأصلي، ولا تم نقل كود GameAssembly بالكامل أو إعادة بناء موارد Android/Shaders، ولا تم تنفيذ مشهد قيادة. لا يمكن منطقياً استبدال هذه الخطوات بتجارب CPU/GPU منفصلة. هذه المرحلة تدعم التشخيص الهندسي ولا تحقق شرط التحدي.
