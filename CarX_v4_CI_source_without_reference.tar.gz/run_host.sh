#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
sha_expected="${CARX_REFERENCE_SHA:-7d4eb4eb338d4fe3d7d5a29146b4dd248bb893b42a33b4a7461f9fdf0b6125ad}"
sha_actual="$(sha256sum app/src/main/assets/x86_reference_v2100.txt | cut -d' ' -f1)"
[ "$sha_actual" = "$sha_expected" ] || { echo 'FAIL: original source reference mismatch';exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cc -O2 -std=c11 -Wall -Wextra -Werror -Iapp/src/main/cpp \
 app/src/main/cpp/carx_core.c tests/host_fallback.c tests/host_cli.c -o "$TMP/carx_host"
"$TMP/carx_host" app/src/main/assets/x86_reference_v2100.txt
python3 tests/test_project.py
