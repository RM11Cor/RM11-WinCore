# CarX Native Foundation v8 — CAB serialized-header evidence

نسخة اختبار أصلية ARM64 فقط، وليست بورت اللعبة الكامل. تستعمل اسم الحزمة الثابت لقناة v7: `com.carx.nativefoundation.test.updates` مع `versionCode=800`، ويجب توقيعها **بنفس شهادة v7/v7.1** لتمكين التحديث فوق النسخة السابقة.

الجديد: فك بنية UnityFS وقراءة أول 64 بايت من أول CAB فعلي عبر خريطة الكتل الافتراضية، حتى لو بدأ داخل كتلة. يختبر المرشح القياسي لرأس Unity SerializedFile دون افتراض أن Windows AssetBundles تصلح لأندرويد. إذا لم يتطابق الرأس، يسجل bytes خاماً للاختبار دون تجاوز الحماية أو تعديل الملفات. يحتفظ باختبار AOT الجزئي (1024 مقارنة) وVulkan native.

تشغيل الاختبارات المحلية: `python3 -m unittest discover -s tests -v` ثم `bash run_host.sh`.

على الجهاز: تثبيت APK الموقّع من GitHub Release بعد التحقق من شهادته، اختيار مجلد CarX، Run AOT + Vulkan GPU + file checks ثم Export JSON باسم `CarX_NativeFoundation_v8_Report.json`. لا تحذف v7.1.

**حدود الإثبات:** APK لا يشغّل CarX ولا Unity Player، ولا يكفي قارئ CAB لتجهيز أصول Android.
