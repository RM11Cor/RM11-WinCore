# CarX Native AOT + Asset Path v6 — نطاق الترجمة

- ترجمات x86→AArch64: لم تزد تغطيتها في v6. ما زال الاختبار 1,024 مدخلاً عبر مقطعين جزئيين، ولا يوجد Unity IL2CPP runtime أو GameAssembly.dll مترجم كاملاً.
- عرض Vulkan: v5 مثبت على الهاتف عند VkQueuePresentKHR بإطار لون تجريبي، وليس مشهد لعبة.
- الجديد: مسار بيانات UnityFS PC→JNI→native C مع قارئ متدرج (header→block info→node records→sample first chunk).
- قوائم CAB ليست مشاهد Unity مفكوكة ولا Texture/Mesh؛ ملفات Windows قد تتطلب إعادة بناء للـAndroid.
- حدود الحماية: 2MiB للجدول المضغوط، 8MiB للجدول المفكوك، مليون بايت لأول بلوك، 131072 كتلة، 8192 عقدة، 3 ملفات عينة فقط، ولا أي كتابة لملفات اللعبة.
- دعم المعلومات: format 6–8؛ طرق 0 و2 و3 للضغط؛ بخلاف ذلك فشل معلّل، بلا تخمين لطريقة التشفير.
- اختبارات محلية: ملفات اصطناعية مستقلة لا تعد بديلاً عن اختبار الملفات الفعلية على REDMAGIC.
- الهدف القادم بعد تقرير الهاتف: استخراج أول بيانات متوافقة وتحليل SerializedFile metadata ومراجع Mesh/Texture، والتثبت من دعم Android قبل رسم أي مشهد.


## v8: Unity CAB prefix probe
- Bounded and read-only virtual stream mapping through UnityFS uncompressed/LZ4/LZ4HC chunks.
- First CAB node: up to 64 bytes across chunk boundaries, with BE SerializedFile header candidate classification.
- Does not deserialize Unity objects, handle all protection mechanisms, or make Windows shaders work on Android.
- Input: 3 authentic Windows bundles via Android SAF. Output: raw header hex and classification for next source investigation.
- Android appId stable update track, versionCode 800; signing key must match v7/7.1.
