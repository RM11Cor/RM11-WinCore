# RM11 AutoCore v2.4.4 — structural game and executable inspection

This package continues the installable Android 16 diagnostic app project. It is NOT yet
an EXE runtime/emulator and does not ship Wine, Proton, FEX, Vulkan drivers or launchers.

**Features**
- Select one user-approved game folder using Android's system folder picker (SAF).
- Recursively enumerate up to 8,000 items with a depth cap of ten, explicitly reporting
  partial scans. Does not scan outside the selected tree.
- Infer an unknown game's name by PE metadata, then filenames/folder names. **No title list**.
- Inspect Win32 PE header architecture and bounded import DLL names (read-only and
  seek-based); identify likely DX9/DX11/DX12/Vulkan/OpenGL imports.
- Infer Unity, Unreal, Godot or Ren'Py from generic file-layout markers; no exhaustive
  verification, no automatic mapping from graphics hints to compatibility versions.
- Label Steam/Ubisoft/EA/Rockstar/EOS presence as circumstantial; this does NOT prove
  a license, game entitlement or a requirement to run a specific launcher.
- Save diagnostic JSON in app-private storage; never execute/edit/copy a game's files.

**Known limits**
- PE direct-import evidence misses dynamically-loaded and delay-loaded libraries.
- Unity can advertise a generic Unity executable version; it is NOT game version.
- SAF providers may reject seekable file access; then only folder/name inference works.
- Identifying an engine or DirectX is not proof the game can run on Adreno/Android.
- Scans are depth/item-limited; detection can be wrong for multi-EXE installers.
- Launcher detection is heuristic, and installing/running official launchers is future work.

**Build and stable updates**
- Android `applicationId` stays `com.rm11.autocore`.
- Android `versionCode` is **5**, `versionName` is `2.4.4-alpha`.
- For **updates without uninstall**, every shipped APK must have exactly the SAME
  **release signing certificate**, plus a higher `versionCode` than the installed APK.
- Use `assembleRelease` with `RM11_RELEASE_KEYSTORE` pointing to a persistent keystore,
  and `RM11_RELEASE_PASSWORD` from a GitHub Actions encrypted secret.
- In GitHub Actions set secrets `RM11_RELEASE_KEYSTORE_B64` (base64 of full PKCS12 file)
  and `RM11_RELEASE_PASSWORD` (the PKCS12 password). The signing key is NOT in this ZIP.
- Install this stable-signed release as a fresh install ONCE if existing installation
  was signed by an ephemeral debug key; a differently signed APK cannot upgrade it.
- Never uninstall/update based on an APK build merely marked "green": verify that
  the output artifact is `app-release.apk` and that signing secrets were used.
- Retain private backup of the key and password! Losing them breaks same-signature
  updates; do not upload a keystore or secret file to the public repository.
- This APK remains a read-only game inspector: no Windows runtime yet.
