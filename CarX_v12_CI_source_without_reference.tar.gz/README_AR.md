# CarX Native Foundation v12 — Unity Mesh SubMesh Geometry Headers

يقرأ هذا الإصدار رؤوس أول `SubMesh` الأصلية (48 بايت) من كائن `Mesh` داخل ملفات CarX الأصلية، مع تحقق الحقول من `TypeTree` عندما تكون موجودة.

يعرض `index_count`, `vertex_count`, `topology`, `base_vertex`, `first_vertex`, `first_byte` وعدد المثلثات *المرشح* عندما تكون الفهارس ثلاثية ومتوافقة مع `topology=0`.

**الحدود:** لا نستخرج حزم الرؤوس أو الفهارس نفسها حتى الآن، ولا نثبت توافق موارد Windows مع Android، ولم نشغّل اللعبة. لا Wine ولا FEX ولا محاكاة.

تحديث Android بنفس `applicationId=com.carx.nativefoundation.test.updates`, `versionCode=1200` ويجب إعادة توقيعه بالمفتاح الموحّد الأصلي لـv7-v11 بعد البناء في GitHub (مفتاح Debug العشوائي لا يصلح للتحديث).

## تفسير تقرير v11
البيانات الأولية للعينات الموثقة: spokes: vertex=1045/index=2580؛ rim: vertex=975/index=4440؛ cap: vertex=432/index=2340؛ spokes الثانية: vertex=1434/index=5943. هذه قيم رأس SubMesh وليست استخراجاً لمخازن الهندسة الكاملة.
