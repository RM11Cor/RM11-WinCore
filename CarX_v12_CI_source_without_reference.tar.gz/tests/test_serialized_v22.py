"""Synthetic test assets ONLY. No actual CarX game assets distributed."""
import json, pathlib, struct, subprocess, tempfile, unittest, random
from test_unityfs_native import make_bundle
BASE=pathlib.Path(__file__).resolve().parents[1]


def le32(v):return struct.pack('<I',v)
def le64(v):return struct.pack('<Q',v)
def be32(v):return struct.pack('>I',v)
def be64(v):return struct.pack('>Q',v)

def build_v22(*,target=19,classes=(33,43), nobjects=3, data_size=128, typetree=True, bad_index=False, bad_bounds=False, common_field=False, high_pathid=False, tamper=None, object_size=8):
    # SerializedFile format 22, little-endian metadata, minimal valid inline TypeTrees.
    meta=bytearray(b'0.0.0\0'+le32(target)+bytes([int(typetree)])+le32(len(classes)))
    for cls in classes:
        meta+=le32(cls)+b'\0'+b'\xff\xff' + b'\xA5'*16
        if typetree:
            # One real-format v22 TypeTree node (32 bytes), and 10-byte string buffer.
            meta+=le32(1)+le32(10)
            meta+=(b'\x01\x00'+b'\0'*2+le32(0)+le32(0x80000020 if common_field else 5)+le32(0)+le32(0)+le32(0)+b'\0'*8)
            meta+=b'Mesh\x00Name\x00'
        meta+=le32(0) # 21+ type dependency count
    meta+=le32(nobjects)
    for i in range(nobjects):
        while (48+len(meta))%4:meta.append(0)
        start=0 if i==0 else i*8
        size=object_size if not bad_bounds else data_size*4
        idx=len(classes)+9 if bad_index else (i%len(classes))
        meta+=le64((0xfedcba9876543200+i) if high_pathid else (i+1))+le64(start)+le32(size)+le32(idx)
    meta+=le32(0)+le32(0)+le32(0)+b'\0' # scripts, externals, refs, userinfo
    data_offset=(48+len(meta)+15)&~15
    file_size=data_offset+data_size
    hdr=be32(0)+be32(0)+be32(22)+be32(0)+b'\0'*4+be32(len(meta))+be64(file_size)+be64(data_offset)+be64(0)
    blob=bytearray(hdr+meta+b'\0'*(data_offset-(48+len(meta)))+bytes((i*7)%256 for i in range(data_size)))
    if tamper is not None:tamper(blob)
    return bytes(blob)

class SerializedV22Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='carx_v9_synthetic_')
        cls.exe=pathlib.Path(cls.temp.name)/'probe'
        subprocess.run(['cc','-O1','-std=c11','-Wall','-Wextra','-Werror',
            str(BASE/'tests/unityfs_cli.c'),str(BASE/'app/src/main/cpp/unityfs_directory.c'),
            '-o',str(cls.exe)],check=True)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def inspect(self,content,split=None,lz4=0,at_end=False):
        b=make_bundle(content=content,split_at=split,data_kind=lz4,at_end=at_end)
        f=pathlib.Path(self.temp.name)/'t.bundle';f.write_bytes(b)
        r=subprocess.run([str(self.exe),str(f)],capture_output=True,text=True,check=True)
        return json.loads(r.stdout)['serialized_metadata_v22']
    def test_two_types_object_index(self):
        x=self.inspect(build_v22());self.assertEqual(x['status'],'PASS_V22_METADATA_OBJECT_INDEX')
        self.assertEqual(x['build_target'],19)
        self.assertEqual(x['build_target_name'],'StandaloneWindows64')
        self.assertEqual(x['type_count'],2)
        self.assertEqual(x['class_id_sample'],[33,43])
        self.assertEqual(x['object_count'],3)
        self.assertEqual(x['object_class_id_sample'],[33,43,33])
        self.assertTrue(x['type_tree_enabled'])
        self.assertFalse(x['android_asset_compatibility_proven'])
    def test_native_typetree_local_nodes(self):
        t=self.inspect(build_v22(classes=(43,),nobjects=1))['type_tree_inspection']
        self.assertEqual(t['status'],'PASS_BOUNDED_TYPETREE_NODES')
        self.assertEqual(t['common_strings'],'UNRESOLVED_EXTERNAL_TABLE_OFFSETS')
        node=t['types'][0]['sample_nodes'][0]
        self.assertEqual(node['type'],'Mesh')
        self.assertEqual(node['field'],'Name')
        self.assertEqual(node['level'],0)
        self.assertEqual(t['types'][0]['class_id'],43)
        self.assertEqual(len(t['types'][0]['structural_fingerprint_fnv64']),16)
    def test_shared_common_string_offset_not_guessed(self):
        t=self.inspect(build_v22(classes=(43,),nobjects=1,common_field=True))['type_tree_inspection']
        node=t['types'][0]['sample_nodes'][0]
        self.assertIsNone(node['field'])
        self.assertEqual(node['field_common_offset'],32)
        self.assertEqual(node['type'],'Mesh')
        self.assertIsNone(node['type_common_offset'])
    def test_exact_uint64_path_id_survives_json(self):
        x=self.inspect(build_v22(classes=(43,),nobjects=1,high_pathid=True))
        self.assertEqual(x['actual_object_data_samples'][0]['path_id'],str(0xfedcba9876543200))
        self.assertIsInstance(x['actual_object_data_samples'][0]['path_id'],str)
    def test_structural_fingerprint_changes_on_node_change(self):
        a=self.inspect(build_v22(classes=(43,),nobjects=1))
        b=self.inspect(build_v22(classes=(43,),nobjects=1,common_field=True))
        self.assertNotEqual(a['type_tree_inspection']['types'][0]['structural_fingerprint_fnv64'],
                            b['type_tree_inspection']['types'][0]['structural_fingerprint_fnv64'])
    def test_cross_block_lz4(self):
        a=build_v22();x=self.inspect(a,split=31,lz4=3)
        self.assertEqual(x['object_count'],3)
    def test_at_end_lz4(self):
        x=self.inspect(build_v22(),lz4=2,at_end=True)
        self.assertEqual(x['status'],'PASS_V22_METADATA_OBJECT_INDEX')
    def test_no_typetree(self):
        x=self.inspect(build_v22(typetree=False,classes=(43,),nobjects=1))
        self.assertEqual(x['type_count'],1);self.assertFalse(x['type_tree_enabled'])
    def test_android_platform_detects_but_not_proven(self):
        x=self.inspect(build_v22(target=13))
        self.assertEqual(x['build_target_name'],'OTHER_OR_UNKNOWN')
        self.assertFalse(x['android_asset_compatibility_proven'])
    def test_wrong_object_index(self):
        x=self.inspect(build_v22(bad_index=True))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_bad_bounds(self):
        x=self.inspect(build_v22(bad_bounds=True))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_declared_metadata_over_limit(self):
        def tamper(a): a[20:24]=be32(500000)
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_unsupported_v23(self):
        def tamper(a): a[8:12]=be32(23)
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'UNSUPPORTED_SERIALIZED_VERSION')
    def test_invalid_platform_header_endianness(self):
        def tamper(a):a[16]=3
        x=self.inspect(build_v22(tamper=tamper))
        self.assertEqual(x['status'],'METADATA_PARSE_INCOMPLETE')
    def test_real_object_prefix_reads_from_serialized_data(self):
        x=self.inspect(build_v22(classes=(43,21),nobjects=3),lz4=3)
        objects=x['actual_object_data_samples']
        self.assertEqual(len(objects),3)
        self.assertEqual(x['object_type_histogram'],[{'class_id':43,'count':2},{'class_id':21,'count':1}])
        self.assertEqual([r['class_id'] for r in objects],[43,21,43])
        self.assertEqual(objects[0]['hex_prefix'],'00070e151c232a31')
        self.assertEqual(objects[1]['hex_prefix'],'383f464d545b6269')
        self.assertTrue(all(r['read_ok'] for r in objects))
        self.assertTrue(x['object_payloads_read_only'])
    def test_object_payload_crosses_lz4_blocks(self):
        data=build_v22(classes=(43,),nobjects=1)
        dataoffset=struct.unpack_from('>Q',data,32)[0]
        for kind in (2,3):
            x=self.inspect(data,split=dataoffset+3,lz4=kind,at_end=kind==2)
            obj=x['actual_object_data_samples'][0]
            self.assertTrue(obj['read_ok'])
            self.assertEqual(obj['hex_prefix'],'00070e151c232a31')
    def test_mesh_candidate_name_only_from_object_bytes(self):
        data=bytearray(build_v22(classes=(43,),nobjects=1))
        offset=struct.unpack_from('>Q',data,32)[0]
        data[offset:offset+8]=le32(4)+b'Mesh'
        x=self.inspect(bytes(data),lz4=3)
        obj=x['actual_object_data_samples'][0]
        self.assertTrue(obj['read_ok'])
        self.assertEqual(obj['candidate_name'],'Mesh')
        self.assertEqual(obj['class_id'],43)
    def mesh_payload(self, *, topology=0, index_count=4440, vertex_count=975, submesh_count=1, name_len=3, object_size=128):
        data=bytearray(build_v22(classes=(43,),nobjects=1,data_size=128,object_size=object_size))
        offset=struct.unpack_from('>Q',data,32)[0]
        body=bytearray(128)
        struct.pack_into('<I',body,0,name_len)
        body[4:7]=b'rim'
        struct.pack_into('<I',body,8,submesh_count)
        struct.pack_into('<6I',body,12,0,index_count,topology,0,0,vertex_count)
        data[offset:offset+128]=body
        return bytes(data)
    def test_mesh_submesh_header_real_layout(self):
        x=self.inspect(self.mesh_payload(),lz4=3)
        ob=x['actual_object_data_samples'][0]
        mesh=ob['submesh_probe']
        self.assertEqual(ob['candidate_name'],'rim')
        self.assertEqual(mesh['status'],'FIRST_SUBMESH_HEADER_READ')
        self.assertEqual(mesh['submesh_count'],1)
        self.assertEqual(mesh['first_byte'],0)
        self.assertEqual(mesh['index_count'],4440)
        self.assertEqual(mesh['vertex_count'],975)
        self.assertEqual(mesh['topology'],0)
        self.assertEqual(mesh['triangle_count_candidate'],1480)
        self.assertFalse(mesh['typetree_48_byte_layout_confirmed'])
        self.assertFalse(mesh['vertex_buffer_extracted'])
        self.assertFalse(mesh['index_buffer_extracted'])
    def test_mesh_submesh_invalid_topology_cannot_claim_triangles(self):
        m=self.inspect(self.mesh_payload(topology=1,index_count=4440),lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['topology'],1)
        self.assertIsNone(m['triangle_count_candidate'])
    def test_mesh_submesh_non_divisible_index_count(self):
        m=self.inspect(self.mesh_payload(index_count=4441),lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['index_count'],4441)
        self.assertIsNone(m['triangle_count_candidate'])
    def test_mesh_submesh_name_layout_rejected(self):
        m=self.inspect(self.mesh_payload(name_len=0xfffe),lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['status'],'NAME_LAYOUT_UNSUPPORTED')
    def test_mesh_submesh_count_cap_enforced(self):
        m=self.inspect(self.mesh_payload(submesh_count=257),lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['status'],'SUBMESH_COUNT_UNSUPPORTED')
    def test_mesh_submesh_not_claimed_if_object_too_short(self):
        m=self.inspect(self.mesh_payload(object_size=32),lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['status'],'FIRST_SUBMESH_NOT_IN_PREFIX')
    def test_mesh_submesh_across_block_boundary(self):
        data=self.mesh_payload(index_count=2580,vertex_count=1045)
        offset=struct.unpack_from('>Q',data,32)[0]
        m=self.inspect(data,split=offset+23,lz4=3)['actual_object_data_samples'][0]['submesh_probe']
        self.assertEqual(m['triangle_count_candidate'],860)
    def test_fuzz_50(self):
        rnd=random.Random(81);original=bytearray(build_v22())
        for _ in range(50):
            a=original[:]
            idx=rnd.randrange(len(a));a[idx]^=rnd.randrange(1,256)
            x=self.inspect(bytes(a),lz4=3)
            self.assertIn(x['status'],{'PASS_V22_METADATA_OBJECT_INDEX','METADATA_PARSE_INCOMPLETE','UNSUPPORTED_SERIALIZED_VERSION'})
if __name__=='__main__':unittest.main(verbosity=2)
