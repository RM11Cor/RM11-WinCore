# RM11 AutoCore v2.4.6 — game identity vs launcher identity

A surgical fix for an observed bug: game folder CarX Street was displayed as Easy Anti-Cheat Bootstrapper (EOS), because PE ProductName on an auxiliary program overrode game identity recovered from local Unity `app.info`.

## Changes
- Prefer verified local game manifests and engine metadata to PE ProductName if they conflict; auxiliary product labels never become game names.
- Extract the actual game title from local Unity/Steam/Epic/GOG/Unreal metadata, without hard-coding game names.
- Parse metadata **before** probing candidate executables, and prioritize EXEs matching the detected title.
- Treat EAC labels as a possible protection/runtime dependency, **not the game's title or its version**.
- Show EAC bootstrapper version as auxiliary software version only. Anti-cheat on Linux/Proton requires publisher support and remains untested.
- Keep Windows/CPU/RAM requirements and graphics API unverified unless separately supported; no fabricated Proton/Turnip compatibility.
- Preserve applicationId `com.rm11.autocore`, stable release signing secret mechanism, and bump to versionCode 7.

## Build
Upload the ZIP unchanged as `RM11-WinCore-v2.4.6-source.zip` to https://github.com/RM11Cor/RM11-WinCore/upload/main. GitHub Actions uses the latest `RM11-WinCore-v*-source.zip` and stable release signing. Verify the certificate and install as an update over the last stable-signed build.

This is a *game analyzer*, not an Android Windows runtime or tested CarX Street emulation solution.
