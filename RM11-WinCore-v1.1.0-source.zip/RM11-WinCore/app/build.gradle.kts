plugins {
    id("com.android.application")
}

android {
    namespace = "com.rm11.wincore"
    compileSdk = 36
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.rm11.wincore"
        minSdk = 30
        targetSdk = 35
        versionCode = 11
        versionName = "1.1.0"
        externalNativeBuild {
            cmake { cppFlags += "-std=c++17" }
        }
        ndk { abiFilters += "arm64-v8a" }
    }

    // Extract native ELF entries to nativeLibraryDir; Android 10+ rejects exec from writable app files.
    packaging {
        jniLibs { useLegacyPackaging = true }
    }

    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
}
