# v13 technical notes

- Independent native C code for metadata inspection, not Unity Android runtime.
- Survey of *all* TypeTree node entries for selected Mesh classes, instead of first 22 nodes only.
- Decode and compare locally encoded field names; retain external common string refs as unresolved.
- No parsed vertex/index buffer and no file patches.
- Native ARM64 build, JNI and Vulkan test frame available from prior stages. Unity gameplay not integrated.
