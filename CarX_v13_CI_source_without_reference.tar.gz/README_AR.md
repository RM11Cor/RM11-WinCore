# CarX Native Foundation v13 — Mesh Geometry Field Inventory

يفحص جميع عقد TypeTree الموجودة داخل ملف SerializedFile v22 لكائن Mesh (قد تصل إلى 254 عقدة)، بحثاً عن حقول m_IndexBuffer وm_VertexData وm_IndexFormat وأسماء الحقول الهندسية الأخرى الفعلية داخل جدول النصوص المحلي. 

يظهر كل حقل مطابق مع رقم عقدته والأب والعمق والحجم. إذا كان الاسم موجوداً في Unity Common Strings الخارجية فلا يخترع اسماً ولا يزعم تحديده. **رقم عقدة TypeTree ليس إزاحة ملف أو مخزن**.

لم نستخرج حتى الآن Index Buffer أو Vertex Buffer؛ النتائج في APK تحتاج الاختبار على ملف PC الأصلي من هاتف المستخدم. ملفات PC مستهدفة Windows، واللعبة نفسها لم تقلع على Android.

التحديث: نفس package ID وتوقيع v7-v12 مع versionCode=1300.
