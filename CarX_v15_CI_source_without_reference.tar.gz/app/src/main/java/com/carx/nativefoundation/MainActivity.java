package com.carx.nativefoundation;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** Only an Android-native AOT test harness, NOT a game/Unity Player. */
public final class MainActivity extends Activity {
    private static final int PICK_TREE = 100;
    private static final int EXPORT_JSON = 101;
    private static final String ORIGINAL_DLL_HASH = "3ae06c2e783f8e9aeabfe991b820df6b2eb3f760f2789710471dba6e477d4a8c";
    private static final String REFERENCE_HASH = "7d4eb4eb338d4fe3d7d5a29146b4dd248bb893b42a33b4a7461f9fdf0b6125ad";
    static { System.loadLibrary("carx_native"); }
    private static native String nativeRunDifferential(byte[] reference);
    private static native String nativeProbeUnityFS(byte[] header);
    private static native String nativeProbePE(byte[] header);
    private static native String nativeProbeVulkan();
    private static native String nativeProbeGpu();
    private static native String nativeRenderVulkanSurface(Surface surface);
    private static native String nativeInspectBundleFd(int fd, long fileBytes);

    private TextView status;
    private Uri selectedTree;
    private String latestJson;
    private Button export;
    private Button renderButton;
    private SurfaceView renderSurface;
    private volatile boolean surfaceReady=false;
    private volatile boolean frameBusy=false;
    private volatile String lastFrameReport="{\"stage\":\"NOT_TESTED\",\"frame_presented\":false,\"game_rendered\":false}";

    private void show(String value) { runOnUiThread(() -> status.setText(value)); }
    private Button addButton(LinearLayout parent, String title, View.OnClickListener handler) {
        Button button = new Button(this);
        button.setText(title);
        button.setOnClickListener(handler);
        parent.addView(button);
        return button;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        pane.setPadding(pad,pad,pad,pad);
        scroll.addView(pane);
        TextView header = new TextView(this);
        header.setText("CarX Native Foundation v15\nARM64 · Vulkan + Unity v22 compressed/packed Mesh vertex probe · NOT game boot");
        header.setTextSize(21);
        pane.addView(header);
        addButton(pane,"1. Choose CarX Street PC folder", v -> pickFolder());
        addButton(pane,"2. Run AOT + Vulkan GPU + file checks",v -> runChecks());
        TextView surfaceLabel=new TextView(this);
        surfaceLabel.setText("Vulkan window test — teal frame (NOT CarX gameplay)");
        pane.addView(surfaceLabel);
        renderSurface=new SurfaceView(this);
        LinearLayout.LayoutParams surfaceParams=new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (int)(220*getResources().getDisplayMetrics().density));
        pane.addView(renderSurface,surfaceParams);
        renderSurface.getHolder().addCallback(new SurfaceHolder.Callback(){
            @Override public void surfaceCreated(SurfaceHolder h){surfaceReady=true;}
            @Override public void surfaceChanged(SurfaceHolder h,int format,int w,int hgt){surfaceReady=(w>0 && hgt>0);}
            @Override public void surfaceDestroyed(SurfaceHolder h){surfaceReady=false;}
        });
        renderButton=addButton(pane,"3. Present Vulkan color frame",v -> presentFrame());
        export=addButton(pane,"4. Export JSON report",v -> exportReport());
        export.setEnabled(false);
        status = new TextView(this);
        status.setTextSize(14);
        status.setText("Choose CarX Street folder and run AOT/GPU checks. The app will also decode bounded UnityFS CAB headers and block tables from three original PC bundles; it does NOT open a CarX scene. No files are modified.");
        status.setTextIsSelectable(true);
        pane.addView(status);
        setContentView(scroll);
        String saved = getPreferences(MODE_PRIVATE).getString("tree",null);
        if(saved!=null)selectedTree=Uri.parse(saved);
    }
    private void pickFolder(){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_TREE);
    }
    private void exportReport(){
        if(latestJson==null)return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE,"CarX_NativeFoundation_v15_Report.json");
        startActivityForResult(i,EXPORT_JSON);
    }
    @Override protected void onActivityResult(int request, int result, Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==PICK_TREE){
            try{
                getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                selectedTree=uri;
                getPreferences(MODE_PRIVATE).edit().putString("tree",uri.toString()).apply();
                show("Folder selected. Tap Run native checks.\n"+uri.toString());
            }catch(Exception e){show("Unable to obtain folder access: "+e.getMessage());}
        }else if(request==EXPORT_JSON&&latestJson!=null){
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new Exception("No output stream");
                out.write(latestJson.getBytes("UTF-8"));
                show("Report exported successfully.\n\n"+latestJson);
            }catch(Exception e){show("Export failed: "+e.getMessage());}
        }
    }
    private static final class Entry {
        final String docId, name, mime;
        final long size;
        Entry(String id,String name,String mime,long size){this.docId=id;this.name=name;this.mime=mime;this.size=size;}
    }
    private Entry findChild(Uri tree,String dirId,String wanted) throws Exception{
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,dirId);
        String[] fields={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE};
        try(Cursor c=getContentResolver().query(children,fields,null,null,null)){
            if(c==null)throw new Exception("Cannot enumerate selected folder");
            while(c.moveToNext()){
                String name=c.getString(1);
                if(wanted.equals(name))return new Entry(c.getString(0),name,c.getString(2),c.isNull(3)?-1:c.getLong(3));
            }
        }
        return null;
    }
    private Entry firstBundle(Uri tree,String dirId) throws Exception {
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,dirId);
        String[] fields={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE};
        try(Cursor c=getContentResolver().query(children,fields,null,null,null)){
            if(c==null)return null;
            while(c.moveToNext()){
                String name=c.getString(1);
                if(name!=null&&name.endsWith(".bundle")&&!name.equals("player_layout.bundle"))
                    return new Entry(c.getString(0),name,c.getString(2),c.isNull(3)?-1:c.getLong(3));
            }
        }
        return null;
    }
    /** Bounded, read-only native UnityFS node inventory: first 3 lexicographic PC bundles only. */
    private JSONArray inspectBundleDirectories(Uri tree,String windowsId) throws Exception {
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,windowsId);
        String[] fields={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE};
        ArrayList<Entry> matches=new ArrayList<>();
        try(Cursor c=getContentResolver().query(children,fields,null,null,null)){
            if(c==null)throw new Exception("Cannot enumerate UnityFS bundles");
            while(c.moveToNext()){
                String name=c.getString(1);
                if(name==null || !name.endsWith(".bundle") || name.equals("player_layout.bundle"))continue;
                matches.add(new Entry(c.getString(0),name,c.getString(2),c.isNull(3)?-1:c.getLong(3)));
            }
        }
        Collections.sort(matches,new Comparator<Entry>(){
            @Override public int compare(Entry a,Entry b){return a.name.compareTo(b.name);}
        });
        JSONArray reports=new JSONArray();
        for(int i=0;i<Math.min(3,matches.size());i++){
            Entry e=matches.get(i);
            JSONObject inspected;
            try(ParcelFileDescriptor pfd=getContentResolver().openFileDescriptor(fileUri(tree,e),"r")){
                if(pfd==null)throw new Exception("No file descriptor from Android document provider");
                long length=pfd.getStatSize();
                if(length<0)length=e.size;
                inspected=new JSONObject(nativeInspectBundleFd(pfd.getFd(),length));
            }catch(Exception ex){
                inspected=new JSONObject();
                inspected.put("schema","carx.unityfs.bounded-directory.v6");
                inspected.put("status","UNAVAILABLE_FILE_DESCRIPTOR");
                inspected.put("reason",ex.toString());
                inspected.put("game_rendered",false);
                inspected.put("android_asset_compatibility_proven",false);
            }
            inspected.put("source_bundle",e.name);
            inspected.put("source_platform_directory","StandaloneWindows64");
            reports.put(inspected);
        }
        return reports;
    }
    /** Read-only; no asset bytes copied, decrypted, modified, or interpreted as Android-compatible. */
    private JSONObject scanPlatformBundles(Uri tree,String windowsId) throws Exception {
        JSONObject result=new JSONObject();
        int total=0,unityfs=0,other=0,shortReads=0;
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,windowsId);
        String[] fields={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE};
        try(Cursor c=getContentResolver().query(children,fields,null,null,null)){
            if(c==null)throw new Exception("Cannot enumerate platform bundle directory");
            while(c.moveToNext()){
                String name=c.getString(1);
                if(name==null || !name.endsWith(".bundle"))continue;
                if(total>=1200)throw new Exception("Bundle inventory exceeds 1200; refuse partial count");
                Entry entry=new Entry(c.getString(0),name,c.getString(2),c.isNull(3)?-1:c.getLong(3));
                byte[] header=readPrefix(fileUri(tree,entry),16);
                total++;
                if(header.length<8)shortReads++;
                if(header.length>=8 && header[0]=='U' && header[1]=='n' && header[2]=='i' &&
                   header[3]=='t' && header[4]=='y' && header[5]=='F' && header[6]=='S' && header[7]==0)unityfs++;
                else other++;
            }
        }
        result.put("platform_dir","StandaloneWindows64");
        result.put("assetbundle_count",total);
        result.put("unityfs_signatures",unityfs);
        result.put("other_or_invalid_signatures",other);
        result.put("short_header_reads",shortReads);
        result.put("android_target_assets_proven",false);
        result.put("per_bundle_android_compatibility_proven",false);
        return result;
    }
    private Uri fileUri(Uri tree,Entry entry){return DocumentsContract.buildDocumentUriUsingTree(tree,entry.docId);}
    private byte[] readPrefix(Uri uri,int max) throws Exception {
        try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)throw new Exception("File unavailable");
            byte[] buf=new byte[max];int pos=0;
            while(pos<max){int n=in.read(buf,pos,max-pos);if(n<0)break;if(n==0)break;pos+=n;}
            byte[] sliced=new byte[pos];System.arraycopy(buf,0,sliced,0,pos);return sliced;
        }
    }
    private byte[] readAsset(String name) throws Exception{
        try(InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[16384];int n;
            while((n=in.read(buf))!=-1)out.write(buf,0,n);
            return out.toByteArray();
        }
    }
    private static String hex(byte[] bytes){
        StringBuilder sb=new StringBuilder(bytes.length*2);
        for(byte b:bytes)sb.append(String.format(Locale.US,"%02x",b&255));
        return sb.toString();
    }
    private static String sha256(byte[] bytes) throws Exception{
        return hex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private String hashUri(Uri uri) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)throw new Exception("GameAssembly read denied");
            byte[] buf=new byte[1024*1024];int n;
            while((n=in.read(buf))!=-1){if(n>0)md.update(buf,0,n);}
        }
        return hex(md.digest());
    }
    private void presentFrame(){
        if(frameBusy || !surfaceReady || renderSurface==null ||
            !renderSurface.getHolder().getSurface().isValid()){
            show("Vulkan test surface is not ready or a frame is already running.\nThis is NOT CarX rendering.");
            return;
        }
        frameBusy=true;
        renderButton.setEnabled(false);
        show("Creating Android Vulkan surface, swapchain and one teal test frame…\nNot game rendering.");
        final Surface surface=renderSurface.getHolder().getSurface();
        new Thread(() -> {
            String json;
            try { json=nativeRenderVulkanSurface(surface); }
            catch(Throwable t){
                JSONObject err=new JSONObject();
                try{
                    err.put("stage","JNI_EXCEPTION");
                    err.put("reason",t.toString());
                    err.put("frame_presented",false);
                    err.put("game_rendered",false);
                }catch(Exception ignored){}
                json=err.toString();
            }
            try{
                JSONObject frame=new JSONObject(json);
                lastFrameReport=frame.toString();
                if(latestJson!=null){
                    JSONObject all=new JSONObject(latestJson);
                    all.put("vulkan_surface_frame",frame);
                    all.put("game_boot_proven",false);
                    latestJson=all.toString(2);
                }else{
                    JSONObject all=new JSONObject();
                    all.put("schema","carx.native-foundation.v15");
                    all.put("game_boot_proven",false);
                    all.put("vulkan_surface_frame",frame);
                    all.put("status","VULKAN_SURFACE_ONLY_RUN_FULL_CHECKS_FOR_SOURCE_AUDIT");
                    latestJson=all.toString(2);
                }
                final String output=latestJson;
                runOnUiThread(() -> {
                    frameBusy=false;
                    renderButton.setEnabled(true);
                    export.setEnabled(true);
                    status.setText(output);
                });
            }catch(Exception e){
                final String error="Vulkan surface result invalid: "+e.toString();
                runOnUiThread(() -> {
                    frameBusy=false;
                    renderButton.setEnabled(true);
                    show(error);
                });
            }
        },"CarX-vulkan-frame").start();
    }
    private void runChecks(){
        export.setEnabled(false);
        show("Running native AOT, Vulkan and real UnityFS CAB-prefix inspection…\nPC game boot is NOT implemented.");
        final Uri tree=selectedTree;
        new Thread(() -> {
            try{
                JSONObject report=new JSONObject();
                report.put("schema","carx.native-foundation.v15");
                report.put("build_type","ANDROID_NATIVE_TEST_HARNESS_NOT_GAME_PORT");
                report.put("game_boot_proven",false);
                report.put("unity_android_player_integrated",false);
                report.put("android_abi",Build.SUPPORTED_ABIS.length==0?"unknown":Build.SUPPORTED_ABIS[0]);
                byte[] reference=readAsset("x86_reference_v2100.txt");
                String refHash=sha256(reference);
                report.put("x86_reference_sha256",refHash);
                if(!REFERENCE_HASH.equals(refHash))throw new Exception("Original x86 reference was modified");
                String aot=nativeRunDifferential(reference);
                report.put("native_aot_comparison",aot);
                if(!aot.startsWith("PASS_NATIVE_AOT_IN_APP_V3 "))throw new Exception("Native AOT check failed: "+aot);
                report.put("vulkan_probe",new JSONObject(nativeProbeVulkan()));
                JSONObject gpu=new JSONObject(nativeProbeGpu());
                report.put("vulkan_gpu_bringup",gpu);
                report.put("native_gpu_device_proven",gpu.optBoolean("device_created",false));
                report.put("vulkan_surface_frame",new JSONObject(lastFrameReport));
                if(tree!=null){
                    String root=DocumentsContract.getTreeDocumentId(tree);
                    Entry dll=findChild(tree,root,"GameAssembly.dll");
                    Entry player=findChild(tree,root,"UnityPlayer.dll");
                    if(dll==null)throw new Exception("Choose the inner CarX Street folder containing GameAssembly.dll");
                    String digest=hashUri(fileUri(tree,dll));
                    JSONObject src=new JSONObject();
                    src.put("gameassembly_sha256",digest);
                    src.put("matches_translated_source",ORIGINAL_DLL_HASH.equals(digest));
                    src.put("gameassembly_bytes",dll.size);
                    src.put("gameassembly_pe",new JSONObject(nativeProbePE(readPrefix(fileUri(tree,dll),1024))));
                    if(player!=null)src.put("unityplayer_pe",new JSONObject(nativeProbePE(readPrefix(fileUri(tree,player),1024))));
                    report.put("source",src);
                    if(!ORIGINAL_DLL_HASH.equals(digest))throw new Exception("GameAssembly SHA mismatch; AOT code from a different build");
                    Entry data=findChild(tree,root,"CarX Street_Data");
                    if(data!=null){
                        Entry streaming=findChild(tree,data.docId,"StreamingAssets");
                        Entry aa=streaming==null?null:findChild(tree,streaming.docId,"aa");
                        Entry windows=aa==null?null:findChild(tree,aa.docId,"StandaloneWindows64");
                        if(windows!=null){
                            report.put("platform_bundle_inventory",scanPlatformBundles(tree,windows.docId));
                            report.put("unityfs_directory_probes",inspectBundleDirectories(tree,windows.docId));
                            Entry bundle=firstBundle(tree,windows.docId);
                            if(bundle!=null){
                                JSONObject bund=new JSONObject(nativeProbeUnityFS(readPrefix(fileUri(tree,bundle),512)));
                                bund.put("sample_file",bundle.name);
                                report.put("unity_bundle_sample",bund);
                            }
                        }
                    }
                }else report.put("source_check","FOLDER_NOT_SELECTED");
                report.put("status", !gpu.optBoolean("device_created",false)
                    ? "AOT_PASS_GPU_DEVICE_NOT_PROVEN_NO_GAME_BOOT"
                    : tree==null ? "AOT_AND_GPU_PASS_SOURCE_NOT_SELECTED_NO_GAME_BOOT"
                    : "AOT_GPU_UNITYFS_COMPRESSED_MESH_PROBED_NO_GAME_BOOT");
                latestJson=report.toString(2);
                runOnUiThread(() -> { export.setEnabled(true);status.setText(latestJson); });
            }catch(Exception ex){
                try {
                    JSONObject failure = new JSONObject();
                    failure.put("schema", "carx.native-foundation.v15");
                    failure.put("status", "FAIL_CLOSED");
                    failure.put("reason", ex.toString());
                    failure.put("game_boot_proven", false);
                    latestJson = failure.toString(2);
                    runOnUiThread(() -> { export.setEnabled(true);status.setText(latestJson); });
                } catch(Exception ignored) { show("CHECK FAILED (no game boot claimed): "+ex.getMessage()); }
            }
        },"CarX-native-check").start();
    }
}
