"""Independent synthetic Unity v22 Mesh serialized-object byte-walk tests.
Never ships game assets; tests index/vertex buffer extraction and safety gates.
"""
import json, pathlib, struct, subprocess, tempfile, unittest
from test_unityfs_native import make_bundle
ROOT=pathlib.Path(__file__).resolve().parents[1]
L=lambda n:struct.pack('<I',n)
Q=lambda n:struct.pack('<Q',n)
B=lambda n:struct.pack('>I',n)
BQ=lambda n:struct.pack('>Q',n)

# name/type/common offsets map encoded directly in a real 32-byte TypeTree node.
def build_mesh(*, bad_count=False, bad_index=False, target_size=0, second_channel=False, packed=False, packed_bad_bits=False):
    nodes=[]; strings=bytearray()
    def strid(s):
        if s=='Array':return 0x80000031 # documented built-in common string table offset
        v=len(strings);strings.extend(s.encode()+b'\0');return v
    def add(level,typ,name,size=-1,flags=0,align=False):
        nodes.append((level,strid(typ),strid(name),size,flags,0x4000 if align else 0))
    add(0,'Mesh','Base')
    add(1,'string','m_Name',align=True)
    add(2,'Array','Array')
    add(3,'int','size',4)
    add(3,'char','data',1)
    add(1,'vector','m_SubMeshes')
    add(2,'Array','Array')
    add(3,'int','size',4)
    add(3,'SubMesh','data',48)
    add(1,'BlendShapeData','m_Shapes')
    add(2,'vector','m_ShapeVertices')
    add(3,'Array','Array')
    add(4,'int','size',4)
    add(4,'ShapeVertex','data',24)
    add(1,'int','m_IndexFormat',4)
    add(1,'vector','m_IndexBuffer',align=True)
    add(2,'Array','Array')
    add(3,'int','size',4)
    add(3,'unsigned char','data',1)
    add(1,'VertexData','m_VertexData')
    add(2,'int','m_VertexCount',4)
    add(2,'vector','m_Channels')
    add(3,'Array','Array')
    add(4,'int','size',4)
    add(4,'ChannelInfo','data',4)
    add(2,'vector','m_DataSize',align=True)
    add(3,'Array','Array')
    add(4,'int','size',4)
    add(4,'unsigned char','data',1)
    if packed:
        add(1,'CompressedMesh','m_CompressedMesh')
        add(2,'PackedFloatVector','m_Vertices')
        add(3,'unsigned int','m_NumItems',4)
        add(3,'float','m_Range',4)
        add(3,'float','m_Start',4)
        add(3,'vector','m_Data',align=True)
        add(4,'Array','Array')
        add(5,'int','size',4)
        add(5,'unsigned char','data',1)
        add(3,'unsigned char','m_BitSize',1)
    ids=[0,1,2,0,2,1] # 2 triangles, 3 vertices
    if bad_index: ids[-1]=255
    indices=b''.join(struct.pack('<H',i) for i in ids)
    positions=struct.pack('<9f',0,0,0,1,0,0,0,1,0)
    raw=(L(3)+b'rim\0'+L(1) + # name len, align, one submesh
         struct.pack('<6I',0,len(ids),0,0,0,3) + bytes(24)+ # 48-byte SubMesh
         L(0)+ # no blendshape vertices
         L(0)+ # 16bit index format
         L((len(indices)+900000) if bad_count else len(indices)) + indices +
         L(3)+L(1 if second_channel else 0) + (bytes(4) if second_channel else b'')+
         L(0 if packed else len(positions))+(b'' if packed else positions))
    if packed:
        # 9 quantized float samples at 8 bits each, 3 XYZ positions.
        raw+=L(9)+struct.pack('<f',1.0)+struct.pack('<f',0.0)
        raw+=L(9)+bytes((0,0,0,255,0,0,0,255,0))+bytes(3)
        raw+=bytes((40 if packed_bad_bits else 8,))
    # v22 metadata
    meta=bytearray(b'0.0.0\0'+L(19)+b'\1'+L(1))
    meta+=L(43)+b'\0'+b'\xff\xff'+bytes(16)
    meta+=L(len(nodes))+L(len(strings))
    for level,t,n,size,flags,mflag in nodes:
        meta+=struct.pack('<HBBIIiIIQ',1,level,flags,t,n,size,0,mflag,0)
    meta+=strings+L(0) # type dependencies
    meta+=L(1) # one object
    while (48+len(meta))%4:meta.append(0)
    meta+=Q(991231)+Q(0)+L(len(raw))+L(0)
    meta+=L(0)+L(0)+L(0)+b'\0'
    data_start=(48+len(meta)+15)&~15
    hdr=B(0)+B(0)+B(22)+B(0)+bytes(4)+B(len(meta))+BQ(data_start+len(raw))+BQ(data_start)+BQ(0)
    return bytes(hdr+meta+b'\0'*(data_start-48-len(meta))+raw)

class MeshBufferTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='carx_v15_')
        cls.exe=pathlib.Path(cls.tmp.name)/'probe'
        subprocess.run(['cc','-std=c11','-O1','-Wall','-Wextra','-Werror',
            str(ROOT/'tests/unityfs_cli.c'),str(ROOT/'app/src/main/cpp/unityfs_directory.c'),'-o',str(cls.exe)],check=True)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def inspect(self,content,*,lz4=3,split_at=None):
        path=pathlib.Path(self.tmp.name)/'mesh.bundle'
        path.write_bytes(make_bundle(content=content,split_at=split_at,data_kind=lz4))
        result=subprocess.run([str(self.exe),str(path)],capture_output=True,text=True,check=True)
        obj=json.loads(result.stdout)
        return obj['serialized_metadata_v22']['actual_object_data_samples'][0]
    def test_bytes_found_and_indexes_checked(self):
        x=self.inspect(build_mesh())
        g=x['geometry_buffer_probe']
        self.assertEqual(x['candidate_name'],'rim')
        self.assertEqual(g['status'],'RAW_GEOMETRY_BUFFER_BYTES_READ')
        self.assertTrue(g['index_buffer_extracted']);self.assertTrue(g['vertex_buffer_extracted'])
        self.assertEqual(g['index_format'],0);self.assertEqual(g['vertex_count'],3)
        self.assertEqual(g['index_bytes'],12);self.assertEqual(g['vertex_raw_bytes'],36)
        self.assertEqual(g['checked_indices'],6);self.assertEqual(g['max_index'],2)
        self.assertTrue(g['indices_range_validated']);self.assertFalse(g['vertex_positions_decoded'])
        self.assertEqual(len(g['index_hash_fnv64']),16)
    def test_cross_block_lz4(self):
        data=build_mesh();h=int.from_bytes(data[32:40],'big')
        x=self.inspect(data,split_at=h+63)
        self.assertTrue(x['geometry_buffer_probe']['indices_range_validated'])
    def test_invalid_index_denied(self):
        g=self.inspect(build_mesh(bad_index=True))['geometry_buffer_probe']
        self.assertTrue(g['index_buffer_extracted'])
        self.assertFalse(g['indices_range_validated'])
    def test_index_length_tampering_rejected(self):
        g=self.inspect(build_mesh(bad_count=True))['geometry_buffer_probe']
        self.assertFalse(g['indices_range_validated'])
        self.assertFalse(g['vertex_buffer_extracted'])
    def test_variable_vertex_channel_array(self):
        g=self.inspect(build_mesh(second_channel=True))['geometry_buffer_probe']
        self.assertTrue(g['vertex_buffer_extracted'])
        self.assertEqual(g['vertex_raw_bytes'],36)
    def test_non_lz4_bundle(self):
        g=self.inspect(build_mesh(),lz4=0)['geometry_buffer_probe']
        self.assertTrue(g['indices_range_validated'])
    def test_compressed_vertex_payload_when_raw_vertex_array_empty(self):
        x=self.inspect(build_mesh(packed=True))
        g=x['geometry_buffer_probe']
        self.assertEqual(g['status'],'COMPRESSED_VERTEX_BYTES_READ')
        self.assertTrue(g['index_buffer_extracted'])
        self.assertTrue(g['indices_range_validated'])
        self.assertFalse(g['vertex_buffer_extracted'])
        self.assertTrue(g['vertex_raw_array_seen'])
        self.assertTrue(g['vertex_raw_array_empty'])
        self.assertTrue(g['packed_vertex_data_extracted'])
        self.assertEqual(g['packed_num_items'],9)
        self.assertEqual(g['packed_bit_size'],8)
        self.assertEqual(g['packed_bytes'],9)
        self.assertFalse(g['vertex_positions_decoded'])
    def test_invalid_packed_bits_are_not_claimed(self):
        g=self.inspect(build_mesh(packed=True,packed_bad_bits=True))['geometry_buffer_probe']
        self.assertTrue(g['index_buffer_extracted'])
        self.assertFalse(g['packed_vertex_data_extracted'])
    def test_lz4_cross_block_packed_vertex_data(self):
        data=build_mesh(packed=True);header=int.from_bytes(data[32:40],'big')
        g=self.inspect(data,split_at=header+61)['geometry_buffer_probe']
        self.assertTrue(g['packed_vertex_data_extracted'])
        self.assertEqual(g['packed_bytes'],9)
    def test_unknown_mesh_type_not_falsely_proven(self):
        x=self.inspect(build_mesh(target_size=8))
        self.assertFalse(x['geometry_buffer_probe']['vertex_positions_decoded'])

if __name__=='__main__':unittest.main()
