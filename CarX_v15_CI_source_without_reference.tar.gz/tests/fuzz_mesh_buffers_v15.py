#!/usr/bin/env python3
"""Deterministic read-only mutation gate for v15 UnityFS compressed mesh parser.
Creates synthetic assets only; never reads/ships the proprietary game binary.
"""
import json, pathlib, random, subprocess, tempfile
from test_mesh_buffers_v15 import build_mesh
from test_unityfs_native import make_bundle
ROOT=pathlib.Path(__file__).resolve().parents[1]
CASES=160

def main():
  with tempfile.TemporaryDirectory(prefix='carx_v15_mutations_') as d:
    binary=pathlib.Path(d)/'probe'
    subprocess.run(['clang','-std=c11','-O1','-g','-Wall','-Wextra','-Werror',
                    '-fsanitize=address,undefined','-fno-omit-frame-pointer',
                    str(ROOT/'tests/unityfs_cli.c'),str(ROOT/'app/src/main/cpp/unityfs_directory.c'),
                    '-o',str(binary)],check=True,stdout=subprocess.DEVNULL)
    data=build_mesh(packed=True)
    rng=random.Random(150015)
    failures=[]
    for i in range(CASES):
      m=bytearray(data)
      # Real Unicode serialized files can contain malformed values anywhere:
      # vary header, tree data and compressed packed arrays.
      for _ in range(1+(i%4)):
        idx=rng.randrange(len(m))
        m[idx]=rng.randrange(256)
      if i%13==0:
        m=m[:rng.randrange(len(m))]
      if i%19==0:
        m+=bytes(rng.randrange(256) for _ in range(rng.randrange(25)))
      path=pathlib.Path(d)/'modified.bundle'
      path.write_bytes(make_bundle(content=bytes(m),data_kind=3))
      p=subprocess.run([str(binary),str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
      if p.returncode!=0 or 'AddressSanitizer' in p.stderr or 'runtime error:' in p.stderr:
        failures.append((i,p.returncode,p.stderr[:700]))
        if len(failures)>=3: break
      if p.returncode==0:
        try: json.loads(p.stdout)
        except json.JSONDecodeError:
          failures.append((i,0,'malformed JSON output '+p.stdout[:100]));break
    if failures: raise RuntimeError('Sanitizer mutated-input failures '+repr(failures))
    print(f'PASS_V15_MUTATED_PACKED_MESH cases={CASES} ASAN_UBSAN=clean')

if __name__=='__main__': main()
