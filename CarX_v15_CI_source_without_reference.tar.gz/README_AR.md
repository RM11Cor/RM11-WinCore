# CarX Native Foundation v15 — Packed/Compressed Mesh Geometry Probe (NOT A GAME PORT)

مرحلة تحليل ملفات Unity الحقيقية: v14 أثبت استخراج Index Buffer فعلي من أربعة Mesh وأثبت أن `m_VertexData.m_DataSize` غير مستخرج.

v15 يواصل TypeTree traversal بعد `m_VertexData` إلى `m_CompressedMesh`، ويرصد `PackedFloatVector.m_Vertices` من نفس الكائن، ويقرأ أعداد عناصر البيانات المضغوطة والبتات وحجمها والبصمة مع فحوص الحدود.

النتيجة المسموحة: `COMPRESSED_VERTEX_BYTES_READ` تعني بيانات رأس مضغوطة **وليس** Vertex Buffer مفكوكاً ولا إحداثيات مرسومة. لا يوجد Unity Android Player ولا إقلاع لعبة.

رقم البناء 1500. التوقيع النهائي يتم خارج GitHub بمفتاح تحديث v7-v14 نفسه، ومشغل CI لا ينشر APK Debug كتحديث مباشر.
